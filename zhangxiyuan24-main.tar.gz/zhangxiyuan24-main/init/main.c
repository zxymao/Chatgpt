#include <common.h>
#include <asm.h>
#include <os/kernel.h>
#include <os/task.h>
#include <os/string.h>
#include <os/loader.h>
#include <type.h>

#define VERSION_BUF 50
//#define TASK_NUM_LOC 0x502001fa
int version = 2; // version must between 0 and 9
char buf[VERSION_BUF];

// Task info array
task_info_t tasks[TASK_MAXNUM];
int task_num;
static int bss_check(void)
{
    for (int i = 0; i < VERSION_BUF; ++i)
    {
        if (buf[i] != 0)
        {
            return 0;
        }
    }
    return 1;
}

static void init_jmptab(void)
{
    volatile long (*(*jmptab))() = (volatile long (*(*))())KERNEL_JMPTAB_BASE;

    jmptab[CONSOLE_PUTSTR]  = (long (*)())port_write;
    jmptab[CONSOLE_PUTCHAR] = (long (*)())port_write_ch;
    jmptab[CONSOLE_GETCHAR] = (long (*)())port_read_ch;
    jmptab[SD_READ]         = (long (*)())sd_read;
}

static void init_task_info(int tasknum, uint32_t app_info_offset)
{
    // TODO: [p1-task4] Init 'tasks' array via reading app-info sector
    load_img_bytes(app_info_offset,tasknum * sizeof(task_info_t), tasks);
    // NOTE: You need to get some related arguments from bootblock first
}

/************************************************************/
/* Do not touch this comment. Reserved for future projects. */
/************************************************************/

int main(int tasknum, uint32_t app_info_offset)
{
    task_num=tasknum;
    // Check whether .bss section is set to zero
    int check = bss_check();

    // Init jump table provided by kernel and bios(ΦωΦ)
    init_jmptab();

    // Init task information (〃'▽'〃)
    init_task_info(tasknum,app_info_offset);
   // bios_putstr(tasks[0].task_name);
    //bios_putchar('\n');

    //bios_putstr(tasks[1].task_name);
    //bios_putchar('\n');

    // Output 'Hello OS!', bss check result and OS version
    char output_str[] = "bss check: _ version: _\n\r";
    char output_val[2] = {0};
    int i, output_val_pos = 0;

    output_val[0] = check ? 't' : 'f';
    output_val[1] = version + '0';
    for (i = 0; i < sizeof(output_str); ++i)
    {
        buf[i] = output_str[i];
        if (buf[i] == '_')
        {
            buf[i] = output_val[output_val_pos++];
        }
    }

    bios_putstr("Hello OS!\n\r");
    bios_putstr(buf);

    // TODO: Load tasks by either task id [p1-task3] or task name [p1-task4],
    //   and then execute them.
    //short tasknum=*(volatile short *)TASK_NUM_LOC;
    /*while(1){
        int ch;
        int taskid;
        ch=port_read_ch();
        while(ch==-1){
            ch=port_read_ch();
        }
        port_write_ch(ch);
        taskid=ch-'0';
        if(taskid<0||taskid>=tasknum){
            port_write("\n\rInvalid task id\n\r");
            continue;
        }
        uint64_t entry=load_task_img(taskid);
        ((void (*)())entry)();
        bios_putstr("\n\rTask finished, back to loader\n\r");
    }*/
    while(1){
        char taskname[TASK_NAME_LEN];
        int pos=0;
        int ch;
        bios_putstr("Please input task name:\n\r");
        while (1){
            ch=bios_getchar();
            if(ch==-1){
                continue;
            }
            if(ch=='\n'||ch=='\r'){
                taskname[pos]='\0';
                bios_putstr("\n\r");
                break;
            }
            if(pos<TASK_NAME_LEN-1){
                taskname[pos++]=(char)ch;
                bios_putchar((char)ch);
            }
        }
        if(pos==0){
            continue;
        }
        uint64_t entry=load_task_img(taskname);
        if(entry==0){
            bios_putstr("Task not found\n\r");
            continue;
        }
        ((void (*)(void))entry)();
        bios_putstr("\n\rTask finished, back to loader\n\r");
        // Infinite w
    }
    // hile loop, where CPU stays in a low-power state (QAQQQQQQQQQQQ)
    while (1)
    {
        asm volatile("wfi");
    }

    return 0;
}
