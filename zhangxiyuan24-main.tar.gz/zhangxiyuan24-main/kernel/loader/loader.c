#include <os/task.h>
#include <os/string.h>
#include <os/kernel.h>
#include <type.h>
#define TASK_SIZE_SECTORS 15
#define TASK_MEM_BASE     0x52000000
#define TASK_MEM_STRIDE   0x10000
#define SECTOR_SIZE 512
static unsigned char sector_buf[SECTOR_SIZE];
extern int task_num;
extern task_info_t tasks[TASK_MAXNUM];
void load_img_bytes(uint32_t offset,uint32_t size,void *dst)
{
    unsigned char *out = (unsigned char *)dst;
    while (size > 0)
    {
        uint32_t sector = offset / SECTOR_SIZE;
        uint32_t in_sector = offset % SECTOR_SIZE;
        uint32_t copy_size = SECTOR_SIZE - in_sector;
        if (copy_size > size)
        {
            copy_size = size;
        }
        sd_read((unsigned)sector_buf, 1, sector);

        for (uint32_t i = 0; i < copy_size; ++i)
        {
            out[i] = sector_buf[in_sector + i];
        }
        offset += copy_size;
        out += copy_size;
        size -= copy_size;
    }
}
uint64_t load_task_img(char *taskname)
{
    /**
     * TODO:
     * 1. [p1-task3] load task from image via task id, and return its entrypoint
     * 2. [p1-task4] load task via task name, thus the arg should be 'char *taskname'
     */
     for(int i=0;i<task_num;i++){
        if(strcmp(taskname,tasks[i].task_name)==0){
            load_img_bytes(tasks[i].offset,tasks[i].size,(void *)tasks[i].entrypoint);
            return tasks[i].entrypoint;
        }
     }
     return 0;
    /*uint64_t task_entry;
    uint32_t task_sector;
    task_sector=1+TASK_SIZE_SECTORS*taskid+TASK_SIZE_SECTORS;
    task_entry=TASK_MEM_BASE+TASK_MEM_STRIDE*taskid;
    sd_read(task_entry, TASK_SIZE_SECTORS, task_sector);*/
    //return task_entry;
}