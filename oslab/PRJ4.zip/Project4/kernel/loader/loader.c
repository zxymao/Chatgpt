#include <os/task.h>
#include <os/string.h>
#include <os/kernel.h>
#include <os/loader.h>
#include <assert.h>

static unsigned char sector_buf[SECTOR_SIZE] __attribute__((aligned(512)));
extern int task_num;

int load_img_bytes(uint32_t offset, uint32_t size, void *dst)
{
    unsigned char *out = dst;
    while (size) {
        uint32_t in_sector = offset % SECTOR_SIZE;
        uint32_t count = SECTOR_SIZE - in_sector;
        if (count > size) count = size;
        /* The BIOS data-transfer ABI takes a physical address. */
        if (sd_read((unsigned)vm_pa((ptr_t)sector_buf), 1, offset / SECTOR_SIZE) < 0)
            return -1;
        memcpy(out, sector_buf + in_sector, count);
        out += count;
        offset += count;
        size -= count;
    }
    return 0;
}

int load_task_image(int id, vm_space_t *space)
{
    if (id < 0 || id >= task_num) return -1;
    const task_info_t *task = &tasks[id];
    if (task->entrypoint != TASK_MEM_BASE || task->size > task->memsz ||
        task->memsz > TASK_SIZE || !(task->exec_pages & 1)) return -1;

    for (uint32_t off = 0; off < task->memsz; off += PAGE_SIZE) {
        unsigned bit = 1U << (off / PAGE_SIZE);
        unsigned flags = 0;
        if (task->read_pages & bit) flags |= VM_R;
        if (task->write_pages & bit) flags |= VM_W;
        if (task->exec_pages & bit) flags |= VM_X;
        if (!flags) continue;  /* Unmapped gap between ELF segments. */
        void *dst = vm_map_page(space, task->entrypoint + off, flags);
        if (!dst) return -1;
        if (off < task->size) {
            uint32_t count = task->size - off;
            if (count > PAGE_SIZE) count = PAGE_SIZE;
            if (load_img_bytes(task->offset + off, count, dst)) return -1;
        }
    }
    __asm__ volatile ("fence.i" ::: "memory");
    return 0;
}
