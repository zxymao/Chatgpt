#include <os/irq.h>
#include <os/time.h>
#include <os/mm.h>
#include <os/sched.h>
#include <os/string.h>
#include <os/kernel.h>
#include <printk.h>
#include <assert.h>
#include <screen.h>
#include <csr.h>
#include <os/config.h>

handler_t irq_table[IRQC_COUNT];
handler_t exc_table[EXCC_COUNT];

void interrupt_helper(regs_context_t *regs, uint64_t stval, uint64_t scause)
{
    uint64_t code = scause & ~SCAUSE_IRQ_FLAG;
    if (scause & SCAUSE_IRQ_FLAG) {
        if (code < IRQC_COUNT) irq_table[code](regs, stval, scause);
        else handle_other(regs, stval, scause);
    } else {
        if (code < EXCC_COUNT) exc_table[code](regs, stval, scause);
        else handle_other(regs, stval, scause);
    }
}

void handle_irq_timer(regs_context_t *regs, uint64_t stval, uint64_t scause)
{
    (void)regs; (void)stval; (void)scause;
    bios_set_timer(get_ticks() + TIMER_INTERVAL);
    screen_reflush();
    do_scheduler();
}

static void handle_page_fault(regs_context_t *regs, uint64_t stval, uint64_t cause)
{
    if (regs->sstatus & SR_SPP) {
        handle_other(regs, stval, cause);
        return;
    }
    if (vm_fault(current_running->vm, stval, (unsigned)cause) == 0)
        return; /* sret retries the faulting instruction. */
    printv("[VM] pid=%d fault=%lu va=0x%lx pc=0x%lx\n\r",
           current_running->pid, cause, stval, regs->sepc);
    do_exit();
}

void init_exception()
{
    for (int i = 0; i < EXCC_COUNT; ++i) exc_table[i] = handle_other;
    for (int i = 0; i < IRQC_COUNT; ++i) irq_table[i] = handle_other;
#if LAB_STAGE >= 3
    exc_table[EXCC_SYSCALL] = handle_syscall;
    exc_table[EXCC_INST_PAGE_FAULT] = handle_page_fault;
    exc_table[EXCC_LOAD_PAGE_FAULT] = handle_page_fault;
    exc_table[EXCC_STORE_PAGE_FAULT] = handle_page_fault;
#endif
#if LAB_STAGE >= 4
    irq_table[IRQC_S_TIMER] = handle_irq_timer;
#endif
    setup_exception();
}

void handle_other(regs_context_t *regs, uint64_t stval, uint64_t scause)
{
    char* reg_name[] = {
        "zero "," ra  "," sp  "," gp  "," tp  ",
        " t0  "," t1  "," t2  ","s0/fp"," s1  ",
        " a0  "," a1  "," a2  "," a3  "," a4  ",
        " a5  "," a6  "," a7  "," s2  "," s3  ",
        " s4  "," s5  "," s6  "," s7  "," s8  ",
        " s9  "," s10 "," s11 "," t3  "," t4  ",
        " t5  "," t6  "
    };
    for (int i = 0; i < 32; i += 3) {
        for (int j = 0; j < 3 && i + j < 32; ++j) {
            printk("%s : %016lx ",reg_name[i+j], regs->regs[i+j]);
        }
        printk("\n\r");
    }
    printk("sstatus: 0x%lx sbadaddr: 0x%lx scause: %lu\n\r",
           regs->sstatus, regs->sbadaddr, regs->scause);
    printk("sepc: 0x%lx\n\r", regs->sepc);
    printk("tval: 0x%lx cause: 0x%lx\n", stval, scause);
    assert(0);
}
