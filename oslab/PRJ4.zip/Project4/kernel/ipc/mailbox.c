#include <os/ipc.h>
#include <os/irq.h>
#include <os/list.h>
#include <os/sched.h>
#include <os/string.h>

/* The course mailbox is a byte stream. A complete send/receive of at most
 * CAPACITY bytes takes effect atomically. Threads share their process handles. */
enum { MAILBOXES = 16, CAPACITY = 64, NAME_LENGTH = 32 };

typedef struct {
    vm_space_t *space;
    unsigned count;
} reference_t;

typedef struct {
    int handle;
    char name[NAME_LENGTH];
    unsigned head, length;
    unsigned char bytes[CAPACITY];
    list_head senders, receivers;
    reference_t refs[NUM_MAX_TASK];
} mailbox_t;

static mailbox_t boxes[MAILBOXES];
static int next_handle = 1;

static void wake_all(list_head *queue)
{
    while (!list_empty(queue)) do_unblock(queue->next);
}

static reference_t *reference(mailbox_t *box, vm_space_t *space)
{
    for (int i = 0; i < NUM_MAX_TASK; ++i)
        if (box->refs[i].space == space) return &box->refs[i];
    return NULL;
}

static mailbox_t *lookup(int id)
{
    for (int i = 0; i < MAILBOXES; ++i)
        if (id > 0 && boxes[i].handle == id &&
            reference(&boxes[i], current_running->vm)) return &boxes[i];
    return NULL;
}

static int open_box(const char *name)
{
    mailbox_t *box = NULL, *available = NULL;
    for (int i = 0; i < MAILBOXES; ++i) {
        if (boxes[i].handle && !strcmp(boxes[i].name, name)) {
            box = &boxes[i];
            break;
        }
        if (!available && !boxes[i].handle) available = &boxes[i];
    }
    if (!box) {
        if (!available || next_handle == INT32_MAX) return -1;
        box = available;
        bzero(box, sizeof(*box));
        list_init(&box->senders);
        list_init(&box->receivers);
        strcpy(box->name, name);
        box->handle = next_handle++;
    }
    reference_t *ref = reference(box, current_running->vm);
    if (!ref) ref = reference(box, NULL);
    if (!ref || ref->count == UINT32_MAX) return -1;
    ref->space = current_running->vm;
    ++ref->count;
    return box->handle;
}

int do_mbox_open(ptr_t user_name)
{
    char name[NAME_LENGTH];
    uint64_t flags = irq_save();
    int result = -1;
    for (int i = 0; i < NAME_LENGTH; ++i) {
        if (vm_copyin(current_running->vm, name+i, user_name+i, 1) < 0) break;
        if (name[i] == 0) {
            if (i) result = open_box(name);
            break;
        }
    }
    irq_restore(flags);
    return result;
}

static void remove_reference(mailbox_t *box, reference_t *ref)
{
    ref->space = NULL;
    ref->count = 0;
    /* Sibling threads may be blocked using the handle being closed. */
    wake_all(&box->senders);
    wake_all(&box->receivers);
    for (int i = 0; i < NUM_MAX_TASK; ++i)
        if (box->refs[i].count) return;
    box->handle = 0;
}

int do_mbox_close(int id)
{
    uint64_t flags = irq_save();
    mailbox_t *box = lookup(id);
    if (box) {
        reference_t *ref = reference(box, current_running->vm);
        if (--ref->count == 0) remove_reference(box, ref);
    }
    irq_restore(flags);
    return box ? 0 : -1;
}

void ipc_drop_space(vm_space_t *space)
{
    uint64_t flags = irq_save();
    for (int i = 0; i < MAILBOXES; ++i) {
        reference_t *ref = reference(&boxes[i], space);
        if (ref && boxes[i].handle) remove_reference(&boxes[i], ref);
    }
    irq_restore(flags);
}

int do_mbox_send(int id, ptr_t user_data, int length)
{
    if (length < 0 || length > CAPACITY) return -1;
    unsigned char payload[CAPACITY];
    uint64_t flags = irq_save();
    int result = -1, blocks = 0;
    mailbox_t *box = lookup(id);
    if (!box || (length && vm_copyin(current_running->vm, payload, user_data, length) < 0))
        goto done;
    while ((unsigned)length > CAPACITY - box->length) {
        do_block(&current_running->list, &box->senders);
        ++blocks;
        if (!(box = lookup(id))) goto done;
    }
    for (int i = 0; i < length; ++i)
        box->bytes[(box->head + box->length + i) % CAPACITY] = payload[i];
    box->length += length;
    if (length) wake_all(&box->receivers);
    result = blocks;
done:
    irq_restore(flags);
    return result;
}

int do_mbox_recv(int id, ptr_t user_data, int length)
{
    if (length < 0 || length > CAPACITY) return -1;
    unsigned char payload[CAPACITY];
    uint64_t flags = irq_save();
    int blocks = 0, result = -1;
    mailbox_t *box = lookup(id);
    if (!box) goto done;
    while (box->length < (unsigned)length) {
        do_block(&current_running->list, &box->receivers);
        ++blocks;
        if (!(box = lookup(id))) goto done;
    }
    for (int i = 0; i < length; ++i)
        payload[i] = box->bytes[(box->head+i) % CAPACITY];
    if (length && vm_copyout(current_running->vm, user_data, payload, length) < 0)
        goto done;
    box->head = (box->head + length) % CAPACITY;
    box->length -= length;
    if (length) wake_all(&box->senders);
    result = blocks;
done:
    irq_restore(flags);
    return result;
}
