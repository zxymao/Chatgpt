/* Project 4. Single-hart Sv39: syscall and fault paths run with SIE clear.
 * Page-table pages, stacks, executable pages and shared pages stay resident.
 * Anonymous pages use a bounded FIFO cache with eight-sector backing slots. */
#include <os/mm.h>
#include <os/string.h>
#include <os/irq.h>
#include <common.h>
#include <assert.h>

#define USER_LIMIT (1UL << 38)
#define FRAME_BASE (RAM_BASE + 0x02001000UL)
#define FRAME_COUNT 4096
#define SHM_BASE 0x1000000000UL
#define SHM_KEYS 64
#define SHM_VAS 256
#define PTE_SHARED (1UL << 9)
#define PTE_SWAPPED (1UL << 8)
#define PTE_VALID _PAGE_PRESENT
#define USER_FLAGS (_PAGE_USER | _PAGE_ACCESSED | _PAGE_DIRTY | PTE_VALID)

struct vm_space {
    PTE *root;
    unsigned refs;
};
static vm_space_t spaces[NUM_MAX_TASK];
static unsigned char frame_used[FRAME_COUNT];
static unsigned frame_hint;

struct resident {
    vm_space_t *space;
    ptr_t va;
    ptr_t frame;          /* kernel direct-map address */
    uint64_t age;
};
static struct resident residents[VM_RESIDENT_LIMIT];
static uint64_t fifo_clock;
static unsigned char swap_used[VM_SWAP_SLOTS];
static unsigned swap_start;
static struct shared_page {
    int key;
    unsigned mappings;
    ptr_t frame;
} shared[SHM_KEYS];

static unsigned vpn(ptr_t va, int level)
{
    return (va >> (NORMAL_PAGE_SHIFT + 9 * level)) & 511;
}

static PTE make_pte(ptr_t pa, unsigned flags)
{
    return ((pa >> NORMAL_PAGE_SHIFT) << _PAGE_PFN_SHIFT) | flags;
}

ptr_t vm_boot_root(void)
{
    PTE *root = (PTE *)PGDIR_PA;
    PTE *middle = (PTE *)(PGDIR_PA + PAGE_SIZE);
    clear_pgdir((ptr_t)root);
    clear_pgdir((ptr_t)middle);
    PTE directory = make_pte((ptr_t)middle, PTE_VALID);
    root[vpn(RAM_BASE, 2)] = directory;
    root[vpn(pa2kva(RAM_BASE), 2)] = directory;
    for (ptr_t pa = RAM_BASE; pa < RAM_BASE + 0x10000000UL; pa += LARGE_PAGE_SIZE)
        middle[vpn(pa, 1)] = make_pte(pa, VM_R | VM_W | VM_X | PTE_VALID |
                                          _PAGE_ACCESSED | _PAGE_DIRTY);
    return (ptr_t)root;
}

ptr_t allocKernelPage(int pages)
{
    if (pages < 1 || pages > FRAME_COUNT) return 0;
    unsigned n = (unsigned)pages;
    uint64_t flags = irq_save();
    /* Reuse recently freed frames; search the whole arena after wrapping. */
    for (unsigned pass = 0; pass < 2; ++pass) {
        unsigned start = pass ? 0 : frame_hint;
        for (unsigned i = start; i <= FRAME_COUNT - n; ++i) {
            unsigned j = 0;
            while (j < n && !frame_used[i + j]) ++j;
            if (j == n) {
                memset(frame_used + i, 1, n);
                frame_hint = (i + n) % FRAME_COUNT;
                ptr_t page = pa2kva(FRAME_BASE + i * PAGE_SIZE);
                bzero((void *)page, n * PAGE_SIZE);
                irq_restore(flags);
                return page;
            }
            i += j;
        }
    }
    irq_restore(flags);
    return 0;
}

void freeKernelPage(ptr_t page)
{
    ptr_t pa = kva2pa(page);
    assert(pa >= FRAME_BASE && pa < FRAME_BASE + FRAME_COUNT * PAGE_SIZE);
    assert(!(pa & (PAGE_SIZE - 1)));
    unsigned i = (pa - FRAME_BASE) / PAGE_SIZE;
    uint64_t flags = irq_save();
    assert(frame_used[i]);
    frame_used[i] = 0;
    if (i < frame_hint) frame_hint = i;
    irq_restore(flags);
}

static PTE *kernel_root(void)
{
    return (PTE *)pa2kva(PGDIR_PA);
}

void vm_switch(vm_space_t *space)
{
    ptr_t root = space ? kva2pa((ptr_t)space->root) : PGDIR_PA;
    set_satp(SATP_MODE_SV39, 0, root >> NORMAL_PAGE_SHIFT);
}

vm_space_t *vm_create(void)
{
    for (unsigned i = 0; i < NUM_MAX_TASK; ++i) {
        if (spaces[i].refs) continue;
        PTE *root = (PTE *)allocKernelPage(1);
        if (!root) return NULL;
        /* The immutable supervisor subtrees are shared by every process. */
        memcpy((void *)root, (void *)kernel_root(), PAGE_SIZE);
        spaces[i].root = root;
        spaces[i].refs = 1;
        return &spaces[i];
    }
    return NULL;
}

void vm_get(vm_space_t *s)
{
    assert(s && s->refs);
    ++s->refs;
}

/* Return a user leaf slot. Never walk a supervisor leaf or write through a
 * shared kernel page table. A private copy of the low identity-map directory
 * permits user addresses in unused parts of the same 1 GiB range. */
static PTE *walk(vm_space_t *s, ptr_t va, int create)
{
    if (!s || va < PAGE_SIZE || va >= USER_LIMIT) return NULL;
    PTE *table = s->root;
    for (int level = 2; level; --level) {
        unsigned index = vpn(va, level);
        PTE *entry = &table[index];
        if (*entry & (VM_R | VM_W | VM_X)) return NULL;
        int shared_table = level == 2 && *entry && *entry == kernel_root()[index];
        if (shared_table) {
            PTE *middle = (PTE *)pa2kva(get_pa(*entry));
            if (middle[vpn(va, 1)] || !create) return NULL;
        }
        if (!*entry || shared_table) {
            if (!create) return NULL;
            ptr_t next = allocKernelPage(1);
            if (!next) return NULL;
            if (shared_table)
                memcpy((void *)next, (void *)pa2kva(get_pa(*entry)), PAGE_SIZE);
            *entry = make_pte(kva2pa(next), PTE_VALID);
        }
        table = (PTE *)pa2kva(get_pa(*entry));
    }
    return &table[vpn(va, 0)];
}

void *vm_map_page(vm_space_t *s, ptr_t va, unsigned perms)
{
    if ((va & (PAGE_SIZE - 1)) || !perms || perms & ~(VM_R | VM_W | VM_X)
        || ((perms & VM_W) && !(perms & VM_R))) return NULL;
    PTE *p = walk(s, va, 1);
    if (!p || *p) return NULL;
    ptr_t frame = allocKernelPage(1);
    if (!frame) return NULL;
    *p = make_pte(kva2pa(frame), perms | USER_FLAGS);
    local_flush_tlb_page(va);
    return (void *)frame;
}

void vm_set_swap_start(unsigned first_sector)
{
    swap_start = first_sector;
}

static unsigned swap_sector(unsigned slot)
{
    return swap_start + slot * (PAGE_SIZE / 512);
}

/* Reserve one free slot when adding a new anonymous page. A full working set
 * may then swap in an old page without overwriting its sole on-disk copy. */
static int pageout(struct resident *r, int refault)
{
    if (!swap_start) return -1;
    unsigned slot = VM_SWAP_SLOTS;
    unsigned free_count = 0;
    for (unsigned i = 0; i < VM_SWAP_SLOTS; ++i) {
        if (!swap_used[i]) {
            if (!free_count) slot = i;
            ++free_count;
        }
    }
    if (free_count < (refault ? 1U : 2U)) return -1;
    PTE *p = walk(r->space, r->va, 0);
    assert(p && (*p & PTE_VALID) && get_pa(*p) == kva2pa(r->frame));
    if (sd_write(kva2pa(r->frame), PAGE_SIZE / 512, swap_sector(slot)) < 0) return -1;
    swap_used[slot] = 1;
    *p = ((PTE)slot << _PAGE_PFN_SHIFT) | PTE_SWAPPED;
    local_flush_tlb_page(r->va);
    return 0;
}

static int anon_fault(vm_space_t *space, ptr_t va, PTE *p)
{
    struct resident *r = &residents[0];
    for (unsigned i = 0; i < VM_RESIDENT_LIMIT; ++i) {
        if (!residents[i].space) { r = &residents[i]; break; }
        if (residents[i].age < r->age) r = &residents[i];
    }
    int refault = (*p & PTE_SWAPPED) != 0;
    if (r->space) {
        if (pageout(r, refault)) return -1;
        r->space = NULL;
    } else {
        r->frame = allocKernelPage(1);
        if (!r->frame) return -1;
    }
    if (refault) {
        unsigned slot = *p >> _PAGE_PFN_SHIFT;
        assert(slot < VM_SWAP_SLOTS && swap_used[slot]);
        if (sd_read(kva2pa(r->frame), PAGE_SIZE / 512, swap_sector(slot)) < 0) {
            freeKernelPage(r->frame);
            r->frame = 0;
            return -1;
        }
        swap_used[slot] = 0;
    } else {
        bzero((void *)r->frame, PAGE_SIZE);
    }
    r->space = space;
    r->va = va;
    r->age = ++fifo_clock;
    *p = make_pte(kva2pa(r->frame), USER_FLAGS | VM_R | VM_W);
    local_flush_tlb_page(va);
    return 0;
}

int vm_fault(vm_space_t *s, ptr_t va, unsigned scause)
{
    unsigned perm;
    switch (scause) {
    case EXCC_INST_PAGE_FAULT: perm = VM_X; break;
    case EXCC_LOAD_PAGE_FAULT: perm = VM_R; break;
    case EXCC_STORE_PAGE_FAULT: perm = VM_W; break;
    default: return -1;
    }
    va = ROUNDDOWN(va, PAGE_SIZE);
    PTE *p = walk(s, va, 0);
    if (p && (*p & PTE_VALID)) {
        if (!(*p & _PAGE_USER) || !(*p & perm)) return -1;
        PTE needed = _PAGE_ACCESSED | (perm == VM_W ? _PAGE_DIRTY : 0);
        if ((*p & needed) == needed) return -1;
        *p |= needed;
        local_flush_tlb_page(va);
        return 0;
    }
    /* Image holes and the guarded stack reservation are never demand-filled.
     * Detached shared VAs outside this area can become private anonymous pages. */
    if (perm == VM_X || (va >= VM_USER_ENTRY && va < VM_USER_ENTRY + TASK_SIZE) ||
        (va >= VM_STACK_TOP - 0x100000 && va < VM_STACK_TOP + PAGE_SIZE)) return -1;
    if (!p) p = walk(s, va, 1);
    return p ? anon_fault(s, va, p) : -1;
}

static void release_leaf(PTE value)
{
    if (value & PTE_SWAPPED) {
        unsigned slot = value >> _PAGE_PFN_SHIFT;
        assert(slot < VM_SWAP_SLOTS && swap_used[slot]);
        swap_used[slot] = 0;
        return;
    }
    assert((value & (PTE_VALID | _PAGE_USER)) == (PTE_VALID | _PAGE_USER));
    ptr_t frame = pa2kva(get_pa(value));
    if (value & PTE_SHARED) {
        for (unsigned i = 0; i < SHM_KEYS; ++i) {
            if (shared[i].mappings && shared[i].frame == frame) {
                if (!--shared[i].mappings) freeKernelPage(frame);
                return;
            }
        }
        assert(0);
    }
    for (unsigned i = 0; i < VM_RESIDENT_LIMIT; ++i) {
        if (residents[i].space && residents[i].frame == frame) {
            residents[i].space = NULL;
            break;
        }
    }
    freeKernelPage(frame);
}

int vm_unmap_page(vm_space_t *s, ptr_t va)
{
    if (va & (PAGE_SIZE - 1)) return -1;
    PTE *p = walk(s, va, 0);
    if (!p || !*p) return -1;
    PTE old = *p;
    *p = 0;
    local_flush_tlb_page(va);
    release_leaf(old);
    return 0;
}

static void release_tree(PTE *table, int level)
{
    for (unsigned i = 0; i < NUM_PTE_ENTRY; ++i) {
        PTE entry = table[i];
        if (!entry || (level == 2 && entry == kernel_root()[i])) continue;
        if (!level) release_leaf(entry);
        /* A copied low RAM directory may include supervisor huge-page leaves. */
        else if (!(entry & (VM_R | VM_W | VM_X)))
            release_tree((PTE *)pa2kva(get_pa(entry)), level - 1);
    }
    freeKernelPage((ptr_t)table);
}

void vm_put(vm_space_t *s)
{
    assert(s && s->refs);
    if (--s->refs) return;
    release_tree(s->root, 2);
    s->root = NULL;
}

ptr_t vm_shm_get(vm_space_t *s, int key)
{
    struct shared_page *object = NULL;
    for (unsigned i = 0; i < SHM_KEYS; ++i) {
        if (shared[i].mappings && shared[i].key == key) { object = &shared[i]; break; }
        if (!object && !shared[i].mappings) object = &shared[i];
    }
    if (!object || !s) return 0;
    ptr_t available = 0;
    for (unsigned i = 0; i < SHM_VAS; ++i) {
        ptr_t va = SHM_BASE + i * PAGE_SIZE;
        PTE *p = walk(s, va, 0);
        if ((!p || !*p) && !available) available = va;
        if (p && (*p & PTE_SHARED) && object->mappings &&
            get_pa(*p) == kva2pa(object->frame)) return va;
    }
    if (!available) return 0;
    PTE *p = walk(s, available, 1);
    if (!p) return 0;
    if (!object->mappings) {
        object->frame = allocKernelPage(1);
        if (!object->frame) return 0;
        object->key = key;
    }
    ++object->mappings;
    *p = make_pte(kva2pa(object->frame), USER_FLAGS | VM_R | VM_W | PTE_SHARED);
    local_flush_tlb_page(available);
    return available;
}

int vm_shm_detach(vm_space_t *s, ptr_t va)
{
    PTE *p = walk(s, va, 0);
    if (!p || !(*p & PTE_SHARED)) return -1;
    return vm_unmap_page(s, va);
}

/* Kernel copies traverse user PTEs page by page via the supervisor direct map.
 * Swapped anonymous pages are paged in; unallocated syscall pointers fail. */
static ptr_t translate(vm_space_t *s, ptr_t va, unsigned perms)
{
    PTE *p = walk(s, va, 0);
    if (p && (*p & PTE_SWAPPED) && !(perms & VM_X)) {
        if (anon_fault(s, ROUNDDOWN(va, PAGE_SIZE), p)) return 0;
    }
    unsigned need = perms | _PAGE_USER | PTE_VALID;
    if (!p || (*p & need) != need) return 0;
    return pa2kva(get_pa(*p)) + (va & (PAGE_SIZE - 1));
}

static int transfer(vm_space_t *s, ptr_t va, void *buffer, size_t n,
                    unsigned perms, int copy)
{
    if (!s || va >= USER_LIMIT || n > USER_LIMIT - va) return -1;
    uint8_t *bytes = buffer;
    while (n) {
        ptr_t kva = translate(s, va, perms);
        if (!kva) return -1;
        size_t count = PAGE_SIZE - (va & (PAGE_SIZE - 1));
        if (count > n) count = n;
        if (copy) {
            if (perms == VM_W) memcpy((void *)kva, bytes, count);
            else memcpy(bytes, (void *)kva, count);
            bytes += count;
        }
        va += count;
        n -= count;
    }
    return 0;
}

int vm_check(vm_space_t *s, ptr_t va, size_t n, unsigned perms)
{
    return transfer(s, va, NULL, n, perms, 0);
}
int vm_copyin(vm_space_t *s, void *kernel, ptr_t user, size_t n)
{
    return transfer(s, user, kernel, n, VM_R, 1);
}
int vm_copyout(vm_space_t *s, ptr_t user, const void *kernel, size_t n)
{
    return transfer(s, user, (void *)kernel, n, VM_W, 1);
}
