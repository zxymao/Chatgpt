#include <os/list.h>
#include <os/sched.h>
#include <os/time.h>
#include <os/mm.h>
#include <os/irq.h>
#include <os/lock.h>
#include <os/task.h>
#include <os/loader.h>
#include <os/string.h>
#include <os/config.h>
#include <os/ipc.h>
#include <printk.h>
#include <csr.h>
#include <assert.h>

extern int task_num;
extern void ret_from_exception(void);

pcb_t pcb[NUM_MAX_TASK];
const ptr_t pid0_stack = INIT_KERNEL_STACK + PAGE_SIZE;
pcb_t pid0_pcb = { .pid = 0, .kernel_sp = INIT_KERNEL_STACK + PAGE_SIZE,
                   .user_sp = INIT_KERNEL_STACK + PAGE_SIZE };
LIST_HEAD(ready_queue);
LIST_HEAD(sleep_queue);
pid_t process_id = 1;

/* Process IDs grow upwards. Thread IDs grow downwards so a joined thread
 * never looks like an already-completed PID to the Project 3 waitpid ABI. */
static pid_t next_tid = INT32_MAX;

static void release_slot(pcb_t *task)
{
    if (task->vm) {
        vm_unmap_page(task->vm, task->user_stack_base);
        vm_put(task->vm);
        task->vm = NULL;
    }
    if (task->kernel_stack_base) {
        freeKernelPage(task->kernel_stack_base);
        task->kernel_stack_base = 0;
    }
    if (!task->joinable) task->used = 0;
}

/* An exited task can still be executing on its kernel stack and page table. */
static void reap_exited(void)
{
    for (int i = 0; i < NUM_MAX_TASK; ++i)
        if (&pcb[i] != current_running && pcb[i].used &&
            pcb[i].status == TASK_EXITED)
            release_slot(&pcb[i]);
}

static pcb_t *empty_slot(void)
{
    reap_exited();
    for (int i = 0; i < NUM_MAX_TASK; ++i)
        if (!pcb[i].used) return &pcb[i];
    return NULL;
}

void init_process_table(void)
{
    list_init(&ready_queue);
    list_init(&sleep_queue);
    bzero(pcb, sizeof(pcb));
    for (int i = 0; i < NUM_MAX_TASK; ++i) {
        pcb[i].status = TASK_EXITED;
        pcb[i].task_id = -1;
        pcb[i].barrier_idx = -1;
        list_init(&pcb[i].list);
        list_init(&pcb[i].wait_list);
    }
    list_init(&pid0_pcb.list);
    list_init(&pid0_pcb.wait_list);
    pid0_pcb.status = TASK_RUNNING;
    pid0_pcb.used = 1;
    pid0_pcb.task_id = -1;
    pid0_pcb.barrier_idx = -1;
    current_running = &pid0_pcb;
    process_id = 1;
    next_tid = INT32_MAX;
    __asm__ volatile ("csrw sscratch, %0" :: "r"(current_running) : "memory");
}

void init_pcb_stack(ptr_t ktop, ptr_t utop, ptr_t entry, pcb_t *task,
                    int argc, uint64_t arg0, uint64_t arg1, uint64_t arg2)
{
    regs_context_t *regs = (regs_context_t *)(ktop - sizeof(*regs));
    switchto_context_t *sw = (switchto_context_t *)((ptr_t)regs - sizeof(*sw));
    bzero(regs, sizeof(*regs));
    bzero(sw, sizeof(*sw));
    regs->regs[2] = utop;
    regs->regs[10] = argc;
    regs->regs[11] = arg0;
    regs->regs[12] = arg1;
    regs->regs[13] = arg2;
    regs->sepc = entry;
    regs->sstatus = SR_SPIE; /* sret enters U-mode with interrupts enabled */
    sw->regs[0] = (ptr_t)ret_from_exception;
    sw->regs[1] = (ptr_t)sw;
    task->kernel_sp = (ptr_t)sw;
    task->user_sp = utop;
}

void do_scheduler(void)
{
    uint64_t flags = irq_save();
    reap_exited();
    check_sleeping();
    pcb_t *prev = current_running;
    if (prev->status == TASK_RUNNING && prev != &pid0_pcb) {
        prev->status = TASK_READY;
        list_add_tail(&prev->list, &ready_queue);
    }
    list_node_t *node = list_pop_front(&ready_queue);
    pcb_t *next = node ? list_entry(node, pcb_t, list) : &pid0_pcb;
    if (prev == &pid0_pcb && next != prev) prev->status = TASK_READY;
    next->status = TASK_RUNNING;
    if (prev != next) {
        if (prev->vm != next->vm) vm_switch(next->vm);
        switch_to(prev, next);
        reap_exited();
    }
    irq_restore(flags);
}

void do_sleep(uint32_t seconds)
{
    uint64_t flags = irq_save();
    if (!seconds) do_scheduler();
    else {
        current_running->wakeup_time = get_ticks() + (uint64_t)seconds * time_base;
        do_block(&current_running->list, &sleep_queue);
    }
    irq_restore(flags);
}

void do_block(list_node_t *node, list_head *queue)
{
    uint64_t flags = irq_save();
    assert(node == &current_running->list && current_running != &pid0_pcb);
    assert(list_empty(node));
    current_running->status = TASK_BLOCKED;
    list_add_tail(node, queue);
    do_scheduler();
    irq_restore(flags);
}

void do_unblock(list_node_t *node)
{
    uint64_t flags = irq_save();
    pcb_t *task = list_entry(node, pcb_t, list);
    assert(task->status == TASK_BLOCKED);
    list_del(node);
    task->status = TASK_READY;
    list_add_tail(node, &ready_queue);
    irq_restore(flags);
}

/* Reserve a private kernel stack and one mapped user stack. The caller
 * holds a VM reference and transfers it to the PCB only on success. */
static int setup_stacks(pcb_t *task, vm_space_t *space, ptr_t user_top)
{
    ptr_t kernel_stack = allocKernelPage(1);
    if (!kernel_stack) return -1;
    ptr_t user_stack = user_top - PAGE_SIZE;
    if (!vm_map_page(space, user_stack, VM_R | VM_W)) {
        freeKernelPage(kernel_stack);
        return -1;
    }
    bzero(task, sizeof(*task));
    list_init(&task->list);
    list_init(&task->wait_list);
    task->barrier_idx = -1;
    task->vm = space;
    task->user_stack_base = user_stack;
    task->kernel_stack_base = kernel_stack;
    return 0;
}

static void enqueue_new(pcb_t *task)
{
    task->used = 1;
    task->status = TASK_READY;
    list_add_tail(&task->list, &ready_queue);
}

/* argv[] is first copied into the new address space. Pointers visible to
 * main() are all user VAs, including argv itself and its trailing NULL. */
static int install_arguments(pcb_t *task, int argc, const char *const argv[],
                             ptr_t *stack, ptr_t *user_argv)
{
    ptr_t pointers[EXEC_MAX_ARGS + 1];
    for (int i = 0; i < argc; ++i) {
        size_t length = 0;
        while (length < EXEC_ARG_SIZE && argv[i][length]) ++length;
        if (length == EXEC_ARG_SIZE) return -1;
        *stack -= length + 1;
        if (vm_copyout(task->vm, *stack, argv[i], length + 1)) return -1;
        pointers[i] = *stack;
    }
    pointers[argc] = 0;
    size_t bytes = (argc + 1) * sizeof(ptr_t);
    *stack = ROUNDDOWN(*stack - bytes, 16);
    *user_argv = *stack;
    return vm_copyout(task->vm, *stack, pointers, bytes);
}

static pid_t create_process(int id, int argc, uint64_t arg0, uint64_t arg1,
                            uint64_t arg2, const char *const argv[])
{
    if (id < 0 || id >= task_num || argc < 0 ||
        argc > (argv ? EXEC_MAX_ARGS : 3) || process_id >= next_tid)
        return -1;
    pcb_t *task = empty_slot();
    if (!task) return -1;
    vm_space_t *space = vm_create();
    if (!space) return -1;
    if (load_task_image(id, space) || setup_stacks(task, space, VM_STACK_TOP)) {
        vm_put(space);
        return -1;
    }
    ptr_t stack = VM_STACK_TOP;
    if (argv && install_arguments(task, argc, argv, &stack, &arg0)) {
        release_slot(task);
        return -1;
    }
    task->task_id = id;
    init_pcb_stack(task->kernel_stack_base + PAGE_SIZE, stack,
                   tasks[id].entrypoint, task, argc, arg0, arg1, arg2);
    task->pid = task->group_pid = process_id++;
    enqueue_new(task);
    return task->pid;
}

pid_t do_exec(int id, int argc, uint64_t arg0, uint64_t arg1, uint64_t arg2)
{
    uint64_t flags = irq_save();
    pid_t pid = create_process(id, argc, arg0, arg1, arg2, NULL);
    irq_restore(flags);
    return pid;
}

pid_t do_exec_argv(int id, int argc, const char *const argv[])
{
    uint64_t flags = irq_save();
    pid_t pid = argv ? create_process(id, argc, 0, 0, 0, argv) : -1;
    irq_restore(flags);
    return pid;
}

pid_t do_thread_create(uintptr_t entry, uintptr_t arg, uintptr_t return_pc)
{
    uint64_t flags = irq_save();
    pcb_t *task = empty_slot();
    vm_space_t *space = current_running->vm;
    /* Each slot has a different stack VA and an unmapped guard page. */
    if (!task || !space || next_tid <= process_id || (entry & 1) ||
        (return_pc & 1) || vm_check(space, entry, 2, VM_X) ||
        vm_check(space, return_pc, 2, VM_X)) {
        irq_restore(flags);
        return -1;
    }
    ptr_t stack = VM_STACK_TOP - (task - pcb + 1) * 2 * PAGE_SIZE;
    if (setup_stacks(task, space, stack)) {
        irq_restore(flags);
        return -1;
    }
    vm_get(space);
    task->task_id = current_running->task_id;
    task->group_pid = current_running->group_pid;
    task->pid = next_tid--;
    task->joinable = 1;
    ptr_t top = task->kernel_stack_base + PAGE_SIZE;
    init_pcb_stack(top, stack, entry, task, 0, 0, 0, 0);
    regs_context_t *regs = (regs_context_t *)(top - sizeof(*regs));
    regs->regs[1] = return_pc;
    regs->regs[10] = arg;
    enqueue_new(task);
    irq_restore(flags);
    return task->pid;
}

static pcb_t *find_process(pid_t pid)
{
    for (int i = 0; i < NUM_MAX_TASK; ++i)
        if (pcb[i].used && pcb[i].pid == pid) return &pcb[i];
    return NULL;
}

/* The common queue/mutex/barrier cleanup applies independently to every
 * schedulable thread. Address-space lifetime is reference counted. */
static void finish_task(pcb_t *task)
{
    if (task->status != TASK_EXITED) {
        barrier_cancel_wait(task);
        if (!list_empty(&task->list)) list_del(&task->list);
        task->status = TASK_EXITED;
        mutex_release_all(task->pid);
        while (!list_empty(&task->wait_list)) do_unblock(task->wait_list.next);
    }
    if (task != current_running) release_slot(task);
}

static void finish_group(pcb_t *leader)
{
    /* Keep the leader's VM reference through final mailbox cleanup. */
    for (int i = 0; i < NUM_MAX_TASK; ++i) {
        pcb_t *task = &pcb[i];
        if (task != leader && task->used && task->group_pid == leader->pid) {
            task->joinable = 0;
            finish_task(task);
        }
    }
    ipc_drop_space(leader->vm);
    finish_task(leader);
}

void do_exit(void)
{
    irq_save();
    pcb_t *leader = find_process(current_running->group_pid);
    assert(leader && current_running != &pid0_pcb);
    finish_group(leader);
    do_scheduler();
    assert(0);
}

void do_thread_exit(void)
{
    irq_save();
    if (current_running->pid == current_running->group_pid) do_exit();
    finish_task(current_running);
    do_scheduler();
    assert(0);
}

int do_thread_join(pid_t tid)
{
    uint64_t flags = irq_save();
    pcb_t *task = find_process(tid);
    if (!task || !task->joinable || task == current_running ||
        task->group_pid != current_running->group_pid || task->joiner) {
        irq_restore(flags);
        return -1;
    }
    task->joiner = current_running->pid;
    if (task->status != TASK_EXITED)
        do_block(&current_running->list, &task->wait_list);
    task->joinable = 0;
    release_slot(task);
    irq_restore(flags);
    return 0;
}

int do_kill(pid_t pid)
{
    uint64_t flags = irq_save();
    pcb_t *task = find_process(pid);
    if (!task || task->group_pid != pid || task->status == TASK_EXITED) {
        irq_restore(flags);
        return -1;
    }
    int self = current_running->group_pid == pid;
    finish_group(task);
    if (self) {
        do_scheduler();
        assert(0);
    }
    irq_restore(flags);
    return pid;
}

int do_waitpid(pid_t pid)
{
    uint64_t flags = irq_save();
    if (pid <= 0 || pid >= process_id || pid == current_running->group_pid) {
        irq_restore(flags);
        return -1;
    }
    pcb_t *task = find_process(pid);
    /* Every earlier PID was created; PIDs are monotonic and never reused.
     * A completed PID can still be waited on after its PCB slot is recycled. */
    if (task && task->status != TASK_EXITED)
        do_block(&current_running->list, &task->wait_list);
    irq_restore(flags);
    return pid;
}

pid_t do_getpid(void)
{
    return current_running->group_pid;
}

void do_process_show(void)
{
    static const char *states[] = {"BLOCKED", "RUNNING", "READY", "EXITED"};
    uint64_t flags = irq_save();
    printk("PID  STATUS   PROGRAM\n");
    printk("0    %s idle\n", states[pid0_pcb.status]);
    for (int i = 0; i < NUM_MAX_TASK; ++i) {
        pcb_t *task = &pcb[i];
        if (task->used && task->status != TASK_EXITED)
            printk("%d    %s %s\n", task->pid, states[task->status],
                   tasks[task->task_id].task_name);
    }
    irq_restore(flags);
}
