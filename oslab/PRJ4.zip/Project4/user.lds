OUTPUT_ARCH("riscv")
ENTRY(_start)
PHDRS {
    code  PT_LOAD FLAGS(5);  /* R X */
    data  PT_LOAD FLAGS(6);  /* R W */
}
SECTIONS {
    . = 0x200000;
    .text : { *(.entry_function) *(.text .text.*) } :code
    .rodata : { *(.rodata .rodata.* .srodata .srodata.*) } :code
    . = ALIGN(4096);
    .data : { *(.data .data.* .sdata .sdata.* .got .got.*) } :data
    .bss (NOLOAD) : {
        __bss_start = .;
        *(.bss .bss.* .sbss .sbss.* COMMON)
        __BSS_END__ = .;
    } :data
    /DISCARD/ : { *(.eh_frame .eh_frame.* .comment .note.GNU-stack) }
}
