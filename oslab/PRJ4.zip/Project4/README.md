# Project 4 · RISC-V Sv39 虚拟内存

本项目以仓库的 `oslab/Project3-SCore-complete.tar.gz` 为底稿，保留用户态 shell、时钟抢占、进程管理、互斥锁和屏障，并实现《Lecture 4 · Virtual Memory》的 Task 1–5。代码按单核调度设计，进程和线程共享同一套就绪队列。

## 构建与运行

解压后进入含 Makefile 的 Project4 目录。需要 GNU Make、宿主 GCC、RV64 交叉 GCC 和 binutils。自动测试还需要 Python 3.9+ 和 qemu-system-riscv64。在本次 Codex 云环境先运行 `source /workspace/.chatgpt-toolchain/activate`。

```sh
make
make check
make run-virt
```

`make` 生成课程地址布局的 `build/image`。`make check` 检查镜像格式，并在临时目录重新构建通用 QEMU virt 地址布局，用真实串口命令验证各项功能。`make run-virt` 启动同一内核的交互式 shell，按 Ctrl+A，松开后按 X 退出 QEMU。课程定制 QEMU 和 U-Boot 可通过 `make run DIR_OSLAB=/你的/OSLab-RISC-V` 启动。

在内核 shell 中可以输入以下命令。带 `&` 的任务在后台运行，`kill PID` 接受启动时打印的进程号。`make list-tasks` 在 Linux 构建终端中列出程序编号。

```text
ps
exec fly &
exec rw 0x10000000 0x10003000
exec swapcheck
exec mboxring
exec consensus
```

## 五项任务的源码入口

| 任务 | 实现和验证 |
|---|---|
| 1 · 静态页表 | `arch/riscv/kernel/head.S` 启用 Sv39 后跳到高地址。内核使用 2 MiB 映射，用户程序使用三级页表、4 KiB 页和独立栈。所有程序链接到 0x200000。镜像保存各程序的段权限和 BSS 长度。`kernel/sched/sched.c` 在切换地址空间时设置 satp，退出时延迟回收当前栈。 |
| 2 · 按需分页 | `kernel/irq/irq.c` 通过 scause 和 stval 识别用户缺页。`kernel/mm/mm.c` 检查权限、分配或恢复页框并刷新 TLB，再返回原指令。`rw` 接收十进制或十六进制虚拟地址。 |
| 3 · 换页 | 全系统 8 个匿名页可同时驻留，FIFO 选择最早进入的页。每个换出页在课程镜像末尾的交换区占 8 个扇区，读写经过 BIOS。代码、栈、页表及共享页常驻。`swapcheck` 在 24 页上逐字校验写入、换入和再次修改后的数据。 |
| 4 · 多线程邮箱 | `tiny_libc/pthread.c`、`kernel/sched/sched.c` 和 `kernel/ipc/mailbox.c` 实现线程创建、返回、join 和阻塞式邮箱。线程共享进程页表，每个线程有自己的用户栈和内核栈。`mboxring` 让三个进程各用两个线程接收并转发数据，检查 12 轮消息内容。另有课程 `mailbox a/b/c` 演示。 |
| 5 · 共享内存 | `sys_shmpageget(key)` 将同键对应的物理页映射进调用进程，`sys_shmpagedt(addr)` 解除映射，最后一个引用消失时释放页框。`consensus` 覆盖九个进程的共享、解除映射后的私有写入、重新映射和共识轮次。 |

## 模板依据和验证范围

对 GitHub 模板执行大小写不敏感的 `p4-task` 搜索，共找到 25 处标记。页表辅助函数 8 处，内核启动 1 处，内存管理头文件和实现 9 处，pthread 头文件和实现 4 处，用户态共享页声明与系统调用 3 处。模板在不同文件中将共享页标为 task4 或 task5，本项目按讲义第 28 页归入 Task 5。按需分页和换页依据讲义第 25–26 页。[GitHub 原始模板](https://github.com/zxymao/Chatgpt/blob/4ab3310db0d0f73dbebe472436ebe6c4c77c0042/oslab/zhangxiyuan24-Project4.zip)

`validation/results.json` 保存实测结果。课程地址布局完成交叉构建。运行验证使用单核通用 QEMU、测试 BIOS 和内存模拟的 SD 卡，检查了换页时的 BIOS 读写计数，以及 48 次子进程正常退出或被终止后的页框、交换槽回收。课程专用 U-Boot 和实体板尚待实机验收。
