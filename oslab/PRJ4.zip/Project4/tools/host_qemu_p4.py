#!/usr/bin/env python3
"""Build the upstream virt layout and exercise Project 4 via its real serial shell."""
import argparse
from collections import deque
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import socket
import struct
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
PROMPT = '> root@UCAS_OS:'
DISK_BYTES = 16 * 1024 * 1024
BOOT = r'CPU #0 has entered kernel with VM!'
ANSI = re.compile(r'\x1b\[([0-9;?]*)([A-Za-z])')


class Screen:
    """Reconstruct visible lines from the kernel's VT100 changed-cell writes."""

    def __init__(self):
        self.lines = [[' '] * 160 for _ in range(80)]
        self.at_prompt = [False] * 80
        self.prompts = 0
        self.row = self.col = 0
        self.pending = ''
        self.last_lines = deque(maxlen=8)
        self.patterns = {}
        self.matches = {}
        self.panic = None

    def watch(self, patterns):
        self.patterns = {key: re.compile(expr) for key, expr in patterns.items()}
        self.matches = {}

    def changed(self):
        line = ''.join(self.lines[self.row]).rstrip()
        prompt = line == PROMPT
        if prompt and not self.at_prompt[self.row]:
            self.prompts += 1
        self.at_prompt[self.row] = prompt
        for key, pattern in self.patterns.items():
            if match := pattern.search(line):
                self.matches[key] = match.group()
        if 'Assertion failed' in line or 'Kernel panic' in line or 'scause:' in line:
            self.panic = line
        if line:
            self.last_lines.append(line)

    def feed(self, data):
        self.pending += data.decode('ascii', errors='replace')
        i = 0
        while i < len(self.pending):
            ch = self.pending[i]
            if ch == '\x1b':
                match = ANSI.match(self.pending, i)
                if not match:
                    break
                args, op = match.groups()
                if op == 'H':
                    coords = (args + ';1').split(';')
                    self.row = max(0, min(79, int(coords[0] or 1) - 1))
                    self.col = max(0, min(159, int(coords[1] or 1) - 1))
                elif op == 'J' and args == '2':
                    self.lines = [[' '] * 160 for _ in range(80)]
                    self.at_prompt = [False] * 80
                i = match.end()
                continue
            if ch == '\n':
                self.row = min(79, self.row + 1)
                self.col = 0
            elif ch == '\r':
                self.col = 0
            elif ' ' <= ch <= '~':
                self.lines[self.row][self.col] = ch
                self.col = min(159, self.col + 1)
                self.changed()
            i += 1
        self.pending = self.pending[i:]


class Guest:
    def __init__(self, command, logdir, timeout):
        self.logdir = logdir
        self.timeout = timeout
        self.screen = Screen()
        self.uart = (logdir / 'uart.log').open('wb')
        self.proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT)
        self.selector = selectors.DefaultSelector()
        self.selector.register(self.proc.stdout, selectors.EVENT_READ)

    def wait(self, predicate):
        until = time.monotonic() + self.timeout
        while time.monotonic() < until:
            if self.screen.panic:
                raise RuntimeError('guest reported: ' + self.screen.panic)
            if predicate():
                return
            if self.proc.poll() is not None:
                raise RuntimeError(f'QEMU exited with {self.proc.returncode}')
            if self.selector.select(0.1):
                data = os.read(self.proc.stdout.fileno(), 8192)
                self.uart.write(data)
                self.uart.flush()
                self.screen.feed(data)
        missing = set(self.screen.patterns) - self.screen.matches.keys()
        raise TimeoutError(f'missing evidence {missing}, prompts={self.screen.prompts}, '
                           f'last screen updates={list(self.screen.last_lines)}')

    def command(self, line, patterns):
        print('guest>', line, flush=True)
        self.screen.watch(patterns)
        previous = self.screen.prompts
        self.proc.stdin.write(line.encode() + b'\n')
        self.proc.stdin.flush()
        self.wait(lambda: self.screen.prompts > previous
                  and self.screen.matches.keys() == patterns.keys())
        return dict(self.screen.matches)

    def close(self):
        self.proc.terminate()
        try:
            self.proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait()
        self.selector.close()
        self.uart.close()
        (self.logdir / 'last-screen.txt').write_text(
            '\n'.join(''.join(line).rstrip() for line in self.screen.lines) + '\n')


def read_guest_memory(qmp, address, size, path):
    """Take a physical-memory snapshot using the emulator monitor."""
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
        sock.settimeout(4)
        sock.connect(str(qmp))
        with sock.makefile('rwb', buffering=0) as stream:
            if 'QMP' not in json.loads(stream.readline()):
                raise RuntimeError('QMP greeting missing')
            for request in [{'execute': 'qmp_capabilities'},
                            {'execute': 'pmemsave', 'arguments': {
                                'val': address, 'size': size, 'filename': str(path)}}]:
                stream.write(json.dumps(request).encode() + b'\n')
                while True:
                    reply = json.loads(stream.readline())
                    if 'error' in reply:
                        raise RuntimeError(f'QMP failed: {reply}')
                    if 'return' in reply:
                        break
    return path.read_bytes()


def disk_stats(qmp, address, path):
    return struct.unpack('<3Q', read_guest_memory(qmp, address, 24, path))


def kernel_allocations(tree, prefix):
    symbols = subprocess.check_output([prefix + 'nm', '-S', 'build/main'], cwd=tree, text=True)
    regions = {}
    for name in ('frame_used', 'swap_used'):
        match = re.search(rf'(?m)^([0-9a-f]+) ([0-9a-f]+) [bB] {name}$', symbols)
        address, length = (int(value, 16) for value in match.groups())
        regions[name] = (address - 0xffffffc000000000, length)
    return regions


def allocation_counts(qmp, regions, directory):
    # Both allocation tables use one byte per slot. Query between commands
    # when only the shell is alive and compare with its initial working set.
    return {name: sum(read_guest_memory(qmp, addr, size, directory / (name + '.bin')))
            for name, (addr, size) in regions.items()}


def build(tree, prefix, logdir):
    make = ['make', '--no-print-directory', f'CROSS_PREFIX={prefix}', 'RAM_BASE=0x80000000']
    fw = ROOT / 'test/host-qemu'
    with (logdir / 'build.log').open('w') as logfile:
        subprocess.run(make + ['image'], cwd=tree, stdout=logfile, stderr=subprocess.STDOUT,
                       check=True)
        subprocess.run([prefix + 'gcc', '-nostdlib', '-static', '-fno-pie', '-no-pie',
                        '-march=rv64imac_zicsr_zifencei', '-mabi=lp64', '-Wl,--build-id=none',
                        '-Wl,--no-relax', '-T', str(fw / 'firmware.lds'), str(fw / 'firmware.S'),
                        '-o', 'firmware.elf'], cwd=tree, stdout=logfile, stderr=subprocess.STDOUT,
                       check=True)
    listing = subprocess.check_output(make + ['list-tasks'], cwd=tree, text=True)
    programs = {name: int(index) for index, name in re.findall(r'(?m)^(\d+)\s+(\w+)$', listing)}
    nm = subprocess.check_output([prefix + 'nm', 'firmware.elf'], cwd=tree, text=True)
    stats = int(re.search(r'(?m)^([0-9a-f]+) B disk_stats$', nm)[1], 16)
    disk = tree / 'build/image'
    if disk.stat().st_size > DISK_BYTES:
        raise RuntimeError('course image exceeds test BIOS disk capacity')
    with disk.open('ab') as handle:
        handle.truncate(DISK_BYTES)
    return programs, stats


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cross-prefix', default='riscv64-linux-gnu-')
    parser.add_argument('--qemu', default='qemu-system-riscv64')
    parser.add_argument('--log-dir', type=Path, default=ROOT / 'build/host-p4')
    parser.add_argument('--timeout', type=int, default=35, help='seconds per shell operation')
    parser.add_argument('--interactive', action='store_true',
                        help='use the serial shell directly; exit QEMU with Ctrl-A then X')
    args = parser.parse_args()
    logdir = args.log_dir.resolve()
    logdir.mkdir(parents=True, exist_ok=True)
    result = {'passed': False, 'checks': [], 'platform': 'upstream QEMU virt, one hart, RAM-backed SD'}
    results_file = logdir / 'results.json'
    if not args.interactive:
        results_file.write_text(json.dumps(result, indent=2) + '\n')
    with tempfile.TemporaryDirectory(prefix='p4-uart-') as temp:
        tree = Path(temp) / 'Project4'
        shutil.copytree(ROOT, tree, ignore=shutil.ignore_patterns('build', '.git', '__pycache__'))
        programs, stats_address = build(tree, args.cross_prefix, logdir)
        qmp = tree / 'monitor.sock'
        cmd = [args.qemu, '-machine', 'virt', '-smp', '1', '-m', '256M', '-display', 'none',
               '-bios', str(tree / 'firmware.elf'), '-device',
               f'loader,file={tree}/build/image,addr=0x84000000,force-raw=on']
        if args.interactive:
            subprocess.run(cmd + ['-serial', 'mon:stdio'], check=True)
            return
        regions = kernel_allocations(tree, args.cross_prefix)
        cmd += ['-serial', 'stdio', '-monitor', 'none', '-qmp', f'unix:{qmp},server=on,wait=off']
        guest = Guest(cmd, logdir, args.timeout)
        try:
            guest.screen.watch({'vm': BOOT})
            guest.wait(lambda: guest.screen.prompts and 'vm' in guest.screen.matches)
            result['checks'].append('Sv39 kernel boot and interactive user shell')
            guest.command('ps', {'shell': r'\b1\s+RUNNING\s+shell\b'})
            baseline = allocation_counts(qmp, regions, tree)
            launch = guest.command('exec fly &', {'pid': r'\[shell\] started pid=\d+',
                                                  'art': r'~~~~~/ /~~'})
            pid = int(launch['pid'].split('=')[-1])
            guest.command(f'kill {pid}', {'killed': rf'\[shell\] killed pid={pid}\b'})
            result['checks'].append('fly renders in a separate process while shell runs; kill')
            guest.command('exec rw 0x10000000 0x10003000', {'rw': r'\[P4\] rw PASS'})
            result['checks'].append('rw touches the two supplied demand-page addresses')
            before = disk_stats(qmp, stats_address, tree / 'before.bin')
            guest.command('exec swapcheck', {'swap': r'\[P4\] swap PASS'})
            after = disk_stats(qmp, stats_address, tree / 'after.bin')
            delta = tuple(b - a for a, b in zip(before, after))
            if delta[1] < 1 or delta[2] < 1:
                raise RuntimeError(f'expected swap writes and reads of written sectors: {delta}')
            result['swap_bios_delta'] = dict(zip(('read', 'write', 'read_previously_written'), delta))
            result['checks'].append('over-quota swap data integrity, BIOS writes and readback')
            for program, marker in [('mboxring', 'mailbox'), ('consensus', 'shared')]:
                guest.command('clear', {})
                guest.command('exec ' + program, {program: rf'\[P4\] {marker} PASS'})
                result['checks'].append(program + ' completed with checked guest marker')
            guest.command('clear', {})
            demo_pids = []
            for role in 'abc':
                started = guest.command(f'exec mailbox {role} &', {'pid': r'\[shell\] started pid=\d+'})
                demo_pids.append(int(started['pid'].split('=')[-1]))
            # The original course demonstration sends indefinitely to random peers.
            # Observe successful traffic, then stop its three process groups.
            guest.screen.watch({'send': r'\[[abc]-send\] to .*:[ ]*[1-9]',
                                'recv': r'\[[abc]-recv\] from .*:[ ]*[1-9]'})
            guest.wait(lambda: len(guest.screen.matches) == 2)
            for pid in demo_pids:
                guest.command(f'kill {pid}', {'killed': rf'\[shell\] killed pid={pid}\b'})
            result['checks'].append('three concurrent course mailbox instances send and receive data')
            guest.command('clear', {})
            life = programs['p4_lifecycle']
            guest.command(f'exec {life} {life}', {'lifecycle': r'\[P4-CHECK\] lifecycle PASS'})
            result['checks'].append('private image data and BSS, exit/kill and PCB reuse')
            guest.command('ps', {'shell': r'\b1\s+RUNNING\s+shell\b'})
            final = allocation_counts(qmp, regions, tree)
            result['allocations'] = {'initial': baseline, 'final': final}
            if baseline != final or baseline['frame_used'] == 0 or final['swap_used'] != 0:
                raise RuntimeError(f'page-frame or swap-slot reclamation failed: {baseline} -> {final}')
            result['checks'].append('after exit/kill, frame and swap allocations return to shell-only baseline')
            result['passed'] = True
        finally:
            guest.close()
            results_file.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
