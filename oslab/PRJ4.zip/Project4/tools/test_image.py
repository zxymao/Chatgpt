#!/usr/bin/env python3
"""Check the P4 image format using small RV64 ELF fixtures, without running a guest."""
import argparse
import struct
import subprocess
import tempfile
from pathlib import Path

USER = 0x200000
PAGE = 4096
RX, RW = 5, 6
METADATA = struct.Struct('<32sIIQIHHHH4x')


def elf(path, base, segments, entry=None):
    ident = b'\x7fELF' + bytes([2, 1, 1]) + bytes(9)
    header = struct.pack('<16sHHIQQQIHHHHHH', ident, 2, 243, 1,
                         base if entry is None else entry, 64, 0, 0,
                         64, 56, len(segments), 0, 0, 0)
    offset = len(header) + 56 * len(segments)
    descriptions = []
    data = bytearray()
    for delta, blob, memsz, flags in segments:
        descriptions.append(struct.pack('<IIQQQQQQ', 1, flags, offset, base + delta,
                                        base + delta, len(blob), memsz, 1))
        data.extend(blob)
        offset += len(blob)
    path.write_bytes(header + b''.join(descriptions) + data)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('tool', type=Path)
    parser.add_argument('--ram-base', type=lambda arg: int(arg, 0), default=0x50000000)
    args = parser.parse_args()
    boot = args.ram_base + 0x200000
    kernel = 0xffffffc000000000 + args.ram_base + 0x202000
    tool = args.tool.resolve()
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        tests = []

        def run(name, change=None, error=None):
            work = root / name
            work.mkdir()
            tasks = ['app']
            elf(work / 'bootblock', boot, [(0, b'B' * 100, 100, RX)])
            elf(work / 'main', kernel, [(0, b'K' * 513, 1024, RX)])
            elf(work / 'app', USER, [(0, b'CODE', 4, RX), (PAGE, b'DATA', PAGE+1, RW)])
            if change:
                change(work, tasks)
            result = subprocess.run([str(tool), 'bootblock', 'main', *tasks], cwd=work,
                                    capture_output=True, text=True)
            if error:
                assert result.returncode != 0 and error in result.stderr, (name, result)
            else:
                assert result.returncode == 0, (name, result)
            tests.append(name)
            return work

        disk = (run('layout') / 'image').read_bytes()
        assert disk[:100] == b'B' * 100 and disk[510:512] == b'\x55\xaa'
        count, table, kernel_size = struct.unpack_from('<HIH', disk, 0x1f6)
        assert count == 1 and kernel_size == 513
        name, start, size, entry, memsz, read, write, execute, _ = METADATA.unpack_from(disk, table)
        assert name.rstrip(b'\0') == b'app' and entry == USER
        assert (memsz, read, write, execute) == (2 * PAGE + 1, 7, 6, 1)
        assert start == 512 + 513 and size == PAGE + 4 and table == start + size
        assert disk[start:table] == b'CODE' + bytes(PAGE - 4) + b'DATA'
        swap = ((table + METADATA.size + 511) // 512) * 512
        assert disk[swap:] == bytes(256 * PAGE)
        run('two-private-images', lambda w, ts: (
            elf(w / 'second', USER, [(0, b'OTHER', 32, RX)]), ts.append('second')))
        run('kernel-overflow', lambda w, _: elf(w / 'main', kernel, [(0, bytes(65536), 65536, RX)]),
            '16-bit byte-count')
        run('boot-overlap', lambda w, _: elf(w / 'bootblock', boot, [(0, bytes(503), 503, RX)]),
            'outside its reserved memory')
        run('app-overflow', lambda w, _: elf(w / 'app', USER, [(0, b'X', 65537, RX)]),
            'outside its reserved memory')
        run('bad-entry', lambda w, _: elf(w / 'app', USER, [(0, b'X', 1, RX)], USER + 4),
            'unexpected entry')
        run('truncated', lambda w, _: (w / 'app').write_bytes(b'\x7fELF'), 'truncated ELF')
        run('no-tasks', lambda _, ts: ts.clear(), '1..16 apps')
        run('too-many-tasks', lambda _, ts: ts.extend(['app'] * 16), '1..16 apps')
        run('duplicate-tasks', lambda _, ts: ts.append('app'), 'duplicate task')
        run('writable-code-page', lambda w, _: elf(w / 'app', USER,
            [(0, b'TEXT', 4, RX), (16, b'DATA', 4, RW)]), 'page permissions')
        run('entry-not-executable', lambda w, _: elf(w / 'app', USER, [(0, b'X', 1, RW)]),
            'page permissions')

        def wrong_endian(work, _):
            path = work / 'app'
            contents = bytearray(path.read_bytes())
            contents[5] = 2
            path.write_bytes(contents)

        run('wrong-endian', wrong_endian, 'little-endian')
        print(f'PASS: {len(tests)} image format and input checks')


if __name__ == '__main__':
    main()
