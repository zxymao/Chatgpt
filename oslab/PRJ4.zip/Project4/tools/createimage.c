/* ELF -> flat course disk image. Boot-sector fields retain the Project 1 layout.
 * PT_LOAD segments retain their relative virtual-address offsets; holes
 * are zero-filled. Per-program metadata records page permissions and BSS span. */
#include <elf.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <limits.h>

#include <os/image.h>
#include <layout.h>
#define KERNEL_BASE (HIGH_KERNEL_BASE + PLATFORM_KERNEL_PA)
#define BOOT_BASE PLATFORM_BOOT_PA
#define SECTOR 512
#define TASK_NUM_LOC 0x1f6
#define APP_INFO_LOC 0x1f8
#define OS_SIZE_LOC 0x1fc

static int extended;

static void die(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}
static void read_at(FILE *fp, uint64_t offset, void *data, size_t size)
{
    if (offset > LONG_MAX || fseek(fp, (long)offset, SEEK_SET) ||
        fread(data, 1, size, fp) != size) die("invalid/truncated ELF");
}
static void write_at(FILE *fp, uint64_t offset, const void *data, size_t size)
{
    if (offset > LONG_MAX || fseek(fp, (long)offset, SEEK_SET) ||
        fwrite(data, 1, size, fp) != size) die("image write failed");
}
static uint32_t append_elf(FILE *img, const char *path, uint64_t expected,
                           uint64_t max_mem, task_info_t *task)
{
    FILE *fp = fopen(path, "rb");
    if (!fp) die("cannot open %s", path);
    Elf64_Ehdr eh;
    read_at(fp, 0, &eh, sizeof(eh));
    if (memcmp(eh.e_ident, ELFMAG, SELFMAG) ||
        eh.e_ident[EI_CLASS] != ELFCLASS64 || eh.e_ident[EI_DATA] != ELFDATA2LSB ||
        eh.e_machine != EM_RISCV || eh.e_type != ET_EXEC ||
        eh.e_phentsize != sizeof(Elf64_Phdr) || !eh.e_phnum)
        die("%s: expected a static little-endian RISC-V ELF64 executable", path);
    if (eh.e_entry != expected) die("%s: unexpected entry 0x%lx", path, eh.e_entry);
    unsigned char *flat = calloc(1, max_mem);
    if (!flat) die("out of memory");
    uint64_t span = 0;
    int loaded = 0;
    for (unsigned i = 0; i < eh.e_phnum; ++i) {
        Elf64_Phdr ph;
        read_at(fp, eh.e_phoff + (uint64_t)i * sizeof(ph), &ph, sizeof(ph));
        if (ph.p_type != PT_LOAD || !ph.p_memsz) continue;
        if (ph.p_vaddr < expected || ph.p_filesz > ph.p_memsz ||
            ph.p_vaddr - expected > max_mem ||
            ph.p_memsz > max_mem - (ph.p_vaddr - expected))
            die("%s: PT_LOAD outside its reserved memory", path);
        uint64_t delta = ph.p_vaddr - expected;
        if (task) {
            uint64_t end = delta + ph.p_memsz;
            if (end > task->memsz) task->memsz = (uint32_t)end;
            for (unsigned page = delta / 4096; page <= (end - 1) / 4096; ++page) {
                unsigned bit = 1U << page;
                if (ph.p_flags & PF_R) task->read_pages |= bit;
                if (ph.p_flags & PF_W) task->write_pages |= bit;
                if (ph.p_flags & PF_X) task->exec_pages |= bit;
            }
        }
        if (ph.p_filesz) {
            read_at(fp, ph.p_offset, flat + delta, ph.p_filesz);
            uint64_t end = delta + ph.p_filesz;
            if (end > span) span = end;
            loaded = 1;
        }
    }
    if (!loaded || !span || span > UINT32_MAX) die("%s: no loadable data", path);
    if (fwrite(flat, 1, span, img) != span) die("image write failed");
    free(flat);
    fclose(fp);
    if (task) {
        task->entrypoint = eh.e_entry;
        if (!(task->exec_pages & 1) || (task->write_pages & task->exec_pages) ||
            (task->write_pages & ~task->read_pages))
            die("%s: invalid user ELF page permissions", path);
    }
    if (extended) printf("%s: entry=0x%lx, file span=%lu bytes\n", path, eh.e_entry, span);
    return (uint32_t)span;
}
int main(int argc, char **argv)
{
    const char *word_apps[TASK_MAXNUM];
    int nword = 0;
    while (argc > 1 && !strncmp(argv[1], "--", 2)) {
        if (!strcmp(argv[1], "--extended"))
            extended = 1;
        else if (!strncmp(argv[1], "--words=", 8) && argv[1][8] && nword < TASK_MAXNUM)
            word_apps[nword++] = argv[1] + 8;
        else
            die("unknown or invalid option: %s", argv[1]);
        ++argv;
        --argc;
    }
    int count = argc - 3;
    if (count < 1 || count > TASK_MAXNUM)
        die("usage: createimage [--extended] [--words=app] bootblock main app... (1..16 apps)");
    FILE *img = fopen("image", "wb+");
    if (!img) die("cannot create image");
    uint32_t boot_size = append_elf(img, argv[1], BOOT_BASE, TASK_NUM_LOC, NULL);
    for (uint32_t i = boot_size; i < SECTOR; ++i)
        if (fputc(0, img) == EOF) die("image write failed");
    /* Boot size field is still bytes, not sectors, matching Project 1. */
    uint32_t kernel_size = append_elf(img, argv[2], KERNEL_BASE,
                                     (RAM_BASE + 0x500000UL) - PLATFORM_KERNEL_PA, NULL);
    if (kernel_size > UINT16_MAX)
        die("kernel exceeds the 16-bit byte-count field (%u bytes)", kernel_size);
    task_info_t tasks[TASK_MAXNUM] = {0};
    for (int i = 0; i < count; ++i) {
        const char *path = argv[i + 3];
        const char *base = strrchr(path, '/');
        base = base ? base + 1 : path;
        if (!*base || strlen(base) >= TASK_NAME_LEN) die("invalid task name");
        for (int j = 0; j < i; ++j)
            if (!strcmp(tasks[j].task_name, base)) die("duplicate task name");
        strcpy(tasks[i].task_name, base);
        for (int j = 0; j < nword; ++j)
            if (!strcmp(word_apps[j], base)) tasks[i].word_args = 1;
        long pos = ftell(img);
        if (pos < 0 || (unsigned long)pos > UINT32_MAX) die("image too large");
        tasks[i].offset = (uint32_t)pos;
        tasks[i].size = append_elf(img, path, TASK_MEM_BASE, TASK_SIZE, &tasks[i]);
    }
    long pos = ftell(img);
    if (pos < 0 || (unsigned long)pos > UINT32_MAX) die("image too large");
    uint32_t app_offset = (uint32_t)pos;
    if (fwrite(tasks, sizeof(*tasks), count, img) != (size_t)count)
        die("metadata write failed");
    /* Pad the image tail so the BIOS can safely read its final sector. */
    long end = ftell(img);
    if (end < 0) die("image offset failed");
    while (end++ % SECTOR) if (fputc(0, img) == EOF) die("image write failed");
    /* The SD-backed pager owns the 4 KiB slots following application metadata. */
    if (fseek(img, IMAGE_SWAP_PAGES * 4096L - 1, SEEK_CUR) || fputc(0, img) == EOF)
        die("cannot reserve swap area");
    uint16_t n = count, bytes = kernel_size;
    uint8_t signature[] = {0x55, 0xaa};
    write_at(img, TASK_NUM_LOC, &n, sizeof(n));
    write_at(img, APP_INFO_LOC, &app_offset, sizeof(app_offset));
    write_at(img, OS_SIZE_LOC, &bytes, sizeof(bytes));
    write_at(img, 0x1fe, signature, sizeof(signature));
    if (fclose(img)) die("image close failed");
    printf("image: kernel=%u bytes, tasks=%d, app-info=%u\n", kernel_size, count, app_offset);
    return 0;
}
