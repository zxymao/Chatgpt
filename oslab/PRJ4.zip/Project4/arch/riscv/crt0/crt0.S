#include <asm.h>
.section ".entry_function","ax"
ENTRY(_start)
    /* exec installs a private, zero-filled BSS and the initial arguments. */
    call main
    /* main's return value is not an exit status in this course interface. */
    call sys_exit
3:  call sys_yield
    j 3b
    /************************************************************/
    /* Do not touch this comment. Reserved for future projects. */
    /************************************************************/
ENDPROC(_start)
