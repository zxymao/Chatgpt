#include <asm.h>
#include <csr.h>
#include <layout.h>
.section ".entry_function","ax"
ENTRY(_start)
    csrw CSR_SIE, zero
    csrc CSR_SSTATUS, 2
    mv s0, a0                 /* Disk program count and metadata offset. */
    mv s1, a1
    mv s2, a2
    /* lla is PC-relative: until the jump below it produces physical addresses. */
    lla t0, __bss_start
    lla t1, __BSS_END__
1:  bgeu t0, t1, 2f
    sb zero, 0(t0)
    addi t0, t0, 1
    j 1b
2:  li sp, PLATFORM_STACK_TOP_PA
    call vm_boot_root
    srli a0, a0, 12
    li t0, (8 << 60)
    or a0, a0, t0
    sfence.vma
    csrw satp, a0
    sfence.vma
    /* The boot root maps this instruction stream at both PA and high VA. */
    lla t0, .Lhigh
    li t1, HIGH_KERNEL_BASE
    add t0, t0, t1
    jr t0
.Lhigh:
    add sp, sp, t1
    mv a0, s0
    mv a1, s1
    mv a2, s2
    call main
3:  wfi
    j 3b
ENDPROC(_start)
