#include <asm.h>
#include <csr.h>
#include <asm/regs.h>

/* sscratch always points to the current PCB, in both U and S mode.
 * Interrupts remain masked throughout kernel handlers. Only idle runs
 * with SIE set in S mode, so a suspended handler cannot nest traps. */
.macro SAVE_CONTEXT
    csrrw tp, CSR_SSCRATCH, tp
    sd t0, PCB_TRAP_T0(tp)
    csrr t0, CSR_SSTATUS
    andi t0, t0, SR_SPP
    bnez t0, 1f
    sd sp, PCB_USER_SP(tp)
    ld sp, PCB_KERNEL_SP(tp)
1:  addi sp, sp, -OFFSET_SIZE
    sd zero, 0(sp)
    sd ra, 8(sp)
    sd gp, 24(sp)
    sd t1, 48(sp)
    sd t2, 56(sp)
    sd s0, 64(sp)
    sd s1, 72(sp)
    sd a0, 80(sp)
    sd a1, 88(sp)
    sd a2, 96(sp)
    sd a3, 104(sp)
    sd a4, 112(sp)
    sd a5, 120(sp)
    sd a6, 128(sp)
    sd a7, 136(sp)
    sd s2, 144(sp)
    sd s3, 152(sp)
    sd s4, 160(sp)
    sd s5, 168(sp)
    sd s6, 176(sp)
    sd s7, 184(sp)
    sd s8, 192(sp)
    sd s9, 200(sp)
    sd s10, 208(sp)
    sd s11, 216(sp)
    sd t3, 224(sp)
    sd t4, 232(sp)
    sd t5, 240(sp)
    sd t6, 248(sp)
    ld t0, PCB_TRAP_T0(tp)
    sd t0, OFFSET_REG_T0(sp)
    csrr t0, CSR_SSCRATCH
    sd t0, OFFSET_REG_TP(sp)
    csrw CSR_SSCRATCH, tp
    csrr t0, CSR_SSTATUS
    sd t0, OFFSET_REG_SSTATUS(sp)
    andi t0, t0, SR_SPP
    beqz t0, 2f
    addi t0, sp, OFFSET_SIZE
    j 3f
2:  ld t0, PCB_USER_SP(tp)
3:  sd t0, OFFSET_REG_SP(sp)
    csrr t0, CSR_SEPC
    sd t0, OFFSET_REG_SEPC(sp)
    csrr t0, CSR_STVAL
    sd t0, OFFSET_REG_SBADADDR(sp)
    csrr t0, CSR_SCAUSE
    sd t0, OFFSET_REG_SCAUSE(sp)
    /* No FPU instructions in kernel or user binaries. */
    li t0, SR_SUM | SR_FS
    csrc CSR_SSTATUS, t0
.endm

.macro RESTORE_CONTEXT
    ld t0, OFFSET_REG_SSTATUS(sp)
    csrw CSR_SSTATUS, t0
    ld t0, OFFSET_REG_SEPC(sp)
    csrw CSR_SEPC, t0
    addi t0, sp, OFFSET_SIZE
    sd t0, PCB_KERNEL_SP(tp)
    csrw CSR_SSCRATCH, tp
    ld ra, 8(sp)
    ld gp, 24(sp)
    ld t1, 48(sp)
    ld t2, 56(sp)
    ld s0, 64(sp)
    ld s1, 72(sp)
    ld a0, 80(sp)
    ld a1, 88(sp)
    ld a2, 96(sp)
    ld a3, 104(sp)
    ld a4, 112(sp)
    ld a5, 120(sp)
    ld a6, 128(sp)
    ld a7, 136(sp)
    ld s2, 144(sp)
    ld s3, 152(sp)
    ld s4, 160(sp)
    ld s5, 168(sp)
    ld s6, 176(sp)
    ld s7, 184(sp)
    ld s8, 192(sp)
    ld s9, 200(sp)
    ld s10, 208(sp)
    ld s11, 216(sp)
    ld t3, 224(sp)
    ld t4, 232(sp)
    ld t5, 240(sp)
    ld t6, 248(sp)
    ld t0, OFFSET_REG_T0(sp)
    ld tp, OFFSET_REG_TP(sp)
    ld sp, OFFSET_REG_SP(sp)
.endm

ENTRY(enable_preempt)
    li t0, SIE_STIE
    csrs CSR_SIE, t0
    ret
ENDPROC(enable_preempt)
ENTRY(disable_preempt)
    li t0, SIE_STIE
    csrc CSR_SIE, t0
    ret
ENDPROC(disable_preempt)
ENTRY(enable_interrupt)
    csrsi CSR_SSTATUS, 2
    ret
ENDPROC(enable_interrupt)
ENTRY(disable_interrupt)
    csrci CSR_SSTATUS, 2
    ret
ENDPROC(disable_interrupt)

ENTRY(switch_to)
    addi sp, sp, -SWITCH_TO_SIZE
    sd ra, 0(sp)
    sd sp, 8(sp)
    sd s0, 16(sp)
    sd s1, 24(sp)
    sd s2, 32(sp)
    sd s3, 40(sp)
    sd s4, 48(sp)
    sd s5, 56(sp)
    sd s6, 64(sp)
    sd s7, 72(sp)
    sd s8, 80(sp)
    sd s9, 88(sp)
    sd s10, 96(sp)
    sd s11, 104(sp)
    sd sp, PCB_KERNEL_SP(a0)
    mv tp, a1
    csrw CSR_SSCRATCH, tp
    ld sp, PCB_KERNEL_SP(tp)
    ld ra, 0(sp)
    ld s0, 16(sp)
    ld s1, 24(sp)
    ld s2, 32(sp)
    ld s3, 40(sp)
    ld s4, 48(sp)
    ld s5, 56(sp)
    ld s6, 64(sp)
    ld s7, 72(sp)
    ld s8, 80(sp)
    ld s9, 88(sp)
    ld s10, 96(sp)
    ld s11, 104(sp)
    ld sp, SWITCH_TO_SP(sp)
    addi sp, sp, SWITCH_TO_SIZE
    ret
ENDPROC(switch_to)
ENTRY(ret_from_exception)
    RESTORE_CONTEXT
    sret
ENDPROC(ret_from_exception)
ENTRY(exception_handler_entry)
    SAVE_CONTEXT
    mv a0, sp
    ld a1, OFFSET_REG_SBADADDR(sp)
    ld a2, OFFSET_REG_SCAUSE(sp)
    call interrupt_helper
    j ret_from_exception
ENDPROC(exception_handler_entry)
