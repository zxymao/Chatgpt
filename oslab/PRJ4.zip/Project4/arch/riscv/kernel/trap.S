#include <asm.h>
#include <csr.h>
ENTRY(setup_exception)
    la t0, exception_handler_entry
    csrw CSR_STVEC, t0
    csrw CSR_SSCRATCH, tp
    li t0, 2 /* permit user rdtime when M-mode also permits it */
    csrs CSR_SCOUNTEREN, t0
    /* Enable only after all tables, queues and the timer are ready. */
    ret
ENDPROC(setup_exception)
