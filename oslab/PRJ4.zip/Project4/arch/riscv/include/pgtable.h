#ifndef PGTABLE_H
#define PGTABLE_H

#include <type.h>
#include <layout.h>

#define SATP_MODE_SV39 8
#define SATP_MODE_SV48 9

#define SATP_ASID_SHIFT 44lu
#define SATP_MODE_SHIFT 60lu

#define NORMAL_PAGE_SHIFT 12lu
#define NORMAL_PAGE_SIZE (1lu << NORMAL_PAGE_SHIFT)
#define LARGE_PAGE_SHIFT 21lu
#define LARGE_PAGE_SIZE (1lu << LARGE_PAGE_SHIFT)

/*
 * Flush the local address translation cache.
 */
static inline void local_flush_tlb_all(void)
{
    __asm__ __volatile__ ("sfence.vma" : : : "memory");
}

/* Flush one page from local TLB */
static inline void local_flush_tlb_page(unsigned long addr)
{
    __asm__ __volatile__ ("sfence.vma %0" : : "r" (addr) : "memory");
}

static inline void local_flush_icache_all(void)
{
    asm volatile ("fence.i" ::: "memory");
}

static inline void set_satp(
    unsigned mode, unsigned asid, unsigned long ppn)
{
    unsigned long __v =
        (unsigned long)(((unsigned long)mode << SATP_MODE_SHIFT) | ((unsigned long)asid << SATP_ASID_SHIFT) | ppn);
    __asm__ __volatile__("csrw satp, %0\nsfence.vma" : : "rK"(__v) : "memory");
}

#define PGDIR_PA (RAM_BASE + 0x01000000UL)

/*
 * PTE format:
 * | XLEN-1  10 | 9             8 | 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0
 *       PFN      reserved for SW   D   A   G   U   X   W   R   V
 */

#define _PAGE_ACCESSED_OFFSET 6

#define _PAGE_PRESENT (1 << 0)
#define _PAGE_READ (1 << 1)     /* Readable */
#define _PAGE_WRITE (1 << 2)    /* Writable */
#define _PAGE_EXEC (1 << 3)     /* Executable */
#define _PAGE_USER (1 << 4)     /* User */
#define _PAGE_GLOBAL (1 << 5)   /* Global */
#define _PAGE_ACCESSED (1 << 6) /* Set by hardware on any access \
                                 */
#define _PAGE_DIRTY (1 << 7)    /* Set by hardware on any write */
#define _PAGE_SOFT (1 << 8)     /* Reserved for software */

#define _PAGE_PFN_SHIFT 10lu

#define VA_MASK ((1lu << 39) - 1)

#define PPN_BITS 9lu
#define NUM_PTE_ENTRY (1 << PPN_BITS)

typedef uint64_t PTE;

#define VM_DIRECT_BASE HIGH_KERNEL_BASE

static inline uintptr_t kva2pa(uintptr_t kva)
{
    return kva >= VM_DIRECT_BASE ? kva - VM_DIRECT_BASE : kva;
}
static inline uintptr_t pa2kva(uintptr_t pa)
{
    return pa + VM_DIRECT_BASE;
}
static inline uint64_t get_pfn(PTE entry)
{
    return (entry >> _PAGE_PFN_SHIFT) & ((1UL << 44) - 1);
}
static inline uint64_t get_pa(PTE entry)
{
    return get_pfn(entry) << NORMAL_PAGE_SHIFT;
}
static inline void set_pfn(PTE *entry, uint64_t pfn)
{
    *entry = (pfn << _PAGE_PFN_SHIFT) | (*entry & 0x3ffUL);
}
static inline uint64_t get_attribute(PTE entry, uint64_t mask)
{
    return entry & mask;
}
static inline void set_attribute(PTE *entry, uint64_t bits)
{
    *entry |= bits;
}
static inline void clear_pgdir(uintptr_t address)
{
    PTE *table = (PTE *)address;
    for (unsigned i = 0; i < NUM_PTE_ENTRY; ++i) table[i] = 0;
}
#endif
