#include <asm/biosdef.h>
#include <layout.h>
.equ BIOS_ENTRY, PLATFORM_BIOS_PA
.equ KERNEL_ENTRY, PLATFORM_KERNEL_PA
.equ TASK_NUM, PLATFORM_BOOT_PA + 0x1f6
.equ APP_INFO, PLATFORM_BOOT_PA + 0x1f8
.equ KERNEL_BYTES, PLATFORM_BOOT_PA + 0x1fc
.text
.global main
main:
    bnez a0, .Lpark          /* PRJ3 substrate uses one scheduler hart. */
    mv s0, a0               /* Boot firmware passes the hart ID in a0. */
    fence
    la a0, message
    li a7, BIOS_PUTSTR
    li t0, BIOS_ENTRY
    jalr t0
    li a0, KERNEL_ENTRY
    li t0, KERNEL_BYTES
    lhu a1, 0(t0)
    addi a1, a1, 511
    srli a1, a1, 9
    li a2, 1
    li a7, BIOS_SDREAD
    li t0, BIOS_ENTRY
    jalr t0
    fence.i
    li t0, TASK_NUM
    lhu a0, 0(t0)
    li t0, APP_INFO
    lwu a1, 0(t0)
    mv a2, s0
    li t0, KERNEL_ENTRY
    jr t0
.Lpark:
    wfi
    j .Lpark
    /************************************************************/
    /* Do not touch this comment. Reserved for future projects. */
    /************************************************************/
message:
    .asciz "It's bootblock!\n\r"
