#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

/* Course rw example: each argument is a virtual address in this process. */
int main(int argc, char *argv[])
{
    if (argc < 2) {
        printf("Usage: exec rw ADDRESS [ADDRESS ...]\n");
        return 1;
    }
    srand(clock());
    sys_move_cursor(2, 2);
    for (int i = 1; i < argc; ++i) {
        uintptr_t address = atol(argv[i]);
        if (!address || address % sizeof(long)) {
            printf("rw: expected a nonzero word-aligned address\n");
            return 1;
        }
        volatile long *word = (volatile long *)address;
        long value = rand();
        *word = value;
        assert(*word == value);
        printf("0x%lx = %ld\n", address, value);
    }
    printf("[P4] rw PASS\n");
    sys_reflush();
    return 0;
}
