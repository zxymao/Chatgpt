#include <assert.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

enum { MEMBERS = 3, ROUNDS = 12 };
static char *inboxes[] = {"p4-ring-a", "p4-ring-b", "p4-ring-c"};

struct token { uint32_t origin, hops; uint64_t stamp; };
struct channel {
    int rank, mailbox, handoff;
    pid_t group;
    struct token received;   /* private to this process, shared by both threads */
};

static uint64_t stamp(uint32_t origin, uint32_t hops)
{
    return 0x5356340000000000UL + ((uint64_t)origin << 32) + hops;
}

static void receiver(void *arg)
{
    struct channel *ch = arg;
    assert(sys_getpid() == ch->group);
    for (int i = 0; i < ROUNDS; ++i) {
        assert(sys_mbox_recv(ch->mailbox, &ch->received, sizeof(ch->received)) >= 0);
        sys_barrier_wait(ch->handoff);   /* publish the complete message */
        sys_barrier_wait(ch->handoff);   /* sender has copied it */
    }
}

int main(int argc, char *argv[])
{
    int rank = argc == 1 ? 0 : atoi(argv[1]);
    assert(rank >= 0 && rank < MEMBERS);
    pid_t children[MEMBERS-1];
    if (!rank) {
        char *child_args[] = {argv[0], "1", 0};
        for (int i = 0; i < MEMBERS-1; ++i) {
            child_args[1] = i == 0 ? "1" : "2";
            children[i] = sys_exec_name(argv[0], 2, child_args);
            assert(children[i] > 0);
        }
    }
    struct channel ch = { .rank = rank, .group = sys_getpid() };
    ch.mailbox = sys_mbox_open(inboxes[rank]);
    int next = sys_mbox_open(inboxes[(rank + 1) % MEMBERS]);
    int everyone = sys_barrier_init(0x4400, MEMBERS);
    ch.handoff = sys_barrier_init(0x4401 + rank, 2);
    assert(ch.mailbox >= 0 && next >= 0 && ch.handoff >= 0 && everyone >= 0);
    pthread_t thread;
    pthread_create(&thread, receiver, &ch);
    assert(thread > 0);
    sys_barrier_wait(everyone);

    struct token outgoing = { rank, 0, stamp(rank, 0) };
    for (int i = 0; i < ROUNDS; ++i) {
        assert(sys_mbox_send(next, &outgoing, sizeof(outgoing)) >= 0);
        sys_barrier_wait(ch.handoff);
        outgoing = ch.received;
        sys_barrier_wait(ch.handoff);
        unsigned expected_origin = (rank + MEMBERS - (i + 1) % MEMBERS) % MEMBERS;
        assert(outgoing.origin == expected_origin && outgoing.hops == (unsigned)i);
        assert(outgoing.stamp == stamp(outgoing.origin, outgoing.hops));
        ++outgoing.hops;
        outgoing.stamp = stamp(outgoing.origin, outgoing.hops);
    }
    assert(pthread_join(thread) == 0);
    assert(pthread_join(thread) < 0);
    sys_barrier_destroy(ch.handoff);
    sys_barrier_wait(everyone);  /* all three processes validated every transfer */
    sys_mbox_close(next);
    sys_mbox_close(ch.mailbox);
    if (!rank) {
        for (int i = 0; i < MEMBERS-1; ++i)
            assert(sys_waitpid(children[i]) == children[i]);
        sys_barrier_destroy(everyone);
        sys_move_cursor(0, 10);
        printf("[P4] mailbox PASS\n");
        sys_reflush();
    }
    return 0;
}
