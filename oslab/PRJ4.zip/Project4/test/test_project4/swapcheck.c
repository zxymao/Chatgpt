#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>

/* Three times the kernel's eight anonymous frames. Check every word, so a
 * page restored to the wrong VA, zero-filled on swap-in or only partly copied
 * cannot satisfy the test. Two sweeps also check changes after first swap-in. */
enum { PAGES = 24, WORDS = 4096 / sizeof(uint64_t) };
static uint64_t pattern(unsigned page, unsigned word)
{
    return 0xd1ce000000000000UL + ((uint64_t)page << 32) + word;
}

int main(void)
{
    volatile uint64_t *base = (volatile uint64_t *)0x18000000UL;
    for (unsigned i = 0; i < PAGES; ++i) {
        for (unsigned j = 0; j < WORDS; ++j) {
            assert(base[i * WORDS + j] == 0);
            base[i * WORDS + j] = pattern(i, j);
        }
    }
    for (unsigned i = 0; i < PAGES; ++i)
        for (unsigned j = 0; j < WORDS; ++j) {
            assert(base[i * WORDS + j] == pattern(i, j));
            base[i * WORDS + j] = ~pattern(i, j);
        }
    for (unsigned i = PAGES; i-- > 0;)
        for (unsigned j = 0; j < WORDS; ++j)
            assert(base[i * WORDS + j] == ~pattern(i, j));
    sys_move_cursor(0, 10);
    printf("[P4] swap PASS\n");
    sys_reflush();
    return 0;
}
