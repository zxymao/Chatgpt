#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>

enum { CHILD_RETURN = 1, CHILD_SLEEP, PAGE_WORDS = 4096 / sizeof(uint64_t) };
static volatile uint64_t initialized = 0x12345678;
static volatile uint64_t bss[2 * PAGE_WORDS + 1] __attribute__((aligned(4096)));

static void check_image(uint64_t data_value, uint64_t bss_value)
{
    assert(initialized == data_value);
    for (int i = 0; i < 3; ++i)
        assert(bss[i * PAGE_WORDS] == bss_value);
}

static void mark_image(uint64_t value)
{
    initialized = value;
    for (int i = 0; i < 3; ++i)
        bss[i * PAGE_WORDS] = value;
}

int main(int argc, uint64_t arg0, uint64_t arg1, uint64_t arg2)
{
    /* Parent and children execute the same ELF concurrently. */
    check_image(0x12345678, 0);
    if (argc == 3) {
        int mode = (int)arg0;
        int rendezvous = (int)arg1;
        assert((uintptr_t)bss == arg2);
        assert(mode == CHILD_RETURN || mode == CHILD_SLEEP);
        mark_image((uint64_t)sys_getpid());
        sys_barrier_wait(rendezvous);
        if (mode == CHILD_SLEEP)
            for (;;) sys_sleep(60);
        return 0;
    }

    assert(argc == 1);
    int program = (int)arg0;
    int rendezvous = sys_barrier_init(sys_getpid(), 2);
    assert(rendezvous >= 0);
    pid_t previous = sys_getpid();
    /* Each termination path runs more times than there are PCB slots. */
    for (int round = 0; round < 24; ++round) {
        for (int mode = CHILD_RETURN; mode <= CHILD_SLEEP; ++mode) {
            uint64_t parent_value = 0xdead0000UL + (unsigned)round * 2 + mode;
            mark_image(parent_value);
            pid_t child = sys_exec(program, 3, mode, rendezvous, (uintptr_t)bss);
            assert(child > previous);
            previous = child;
            sys_barrier_wait(rendezvous);
            check_image(parent_value, parent_value);
            if (mode == CHILD_SLEEP)
                assert(sys_kill(child) == child);
            assert(sys_waitpid(child) == child);
            check_image(parent_value, parent_value);
        }
    }
    sys_barrier_destroy(rendezvous);
    sys_move_cursor(0, 10);
    printf("[P4-CHECK] lifecycle PASS\n");
    sys_reflush();
    return 0;
}
