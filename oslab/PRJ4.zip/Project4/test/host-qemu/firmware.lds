OUTPUT_ARCH(riscv)
ENTRY(_start)
SECTIONS {
  . = 0x80000000;
  .text : { *(.text) }
  .bss (NOLOAD) : { *(.bss) }
  . = 0x80150000;
  .bios : { *(.bios) }
  /DISCARD/ : { *(.comment) *(.riscv.attributes) *(.note*) }
}
