#ifndef OS_LOADER_H
#define OS_LOADER_H
#include <type.h>
#include <os/mm.h>
int load_img_bytes(uint32_t offset, uint32_t size, void *dst);
int load_task_image(int id, vm_space_t *space);
#endif
