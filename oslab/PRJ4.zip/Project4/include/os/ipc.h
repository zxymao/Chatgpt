#ifndef OS_IPC_H
#define OS_IPC_H

#include <os/mm.h>

int do_mbox_open(ptr_t user_name);
int do_mbox_close(int id);
int do_mbox_send(int id, ptr_t user_data, int length);
int do_mbox_recv(int id, ptr_t user_data, int length);
void ipc_drop_space(vm_space_t *space);

#endif
