/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 *            Copyright (C) 2018 Institute of Computing Technology, CAS
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 *                                   Memory Management
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * */
#ifndef MM_H
#define MM_H

#include <pgtable.h>
#include <os/image.h>

#define PAGE_SIZE NORMAL_PAGE_SIZE
#define ROUND(a,n) (((a) + (n) - 1) & ~((ptr_t)(n) - 1))
#define ROUNDDOWN(a,n) ((a) & ~((ptr_t)(n) - 1))
#define INIT_KERNEL_STACK (VM_DIRECT_BASE + RAM_BASE + 0x00500000UL)
#define VM_USER_ENTRY TASK_MEM_BASE
#define VM_STACK_TOP 0xf00010000UL
#define VM_R _PAGE_READ
#define VM_W _PAGE_WRITE
#define VM_X _PAGE_EXEC
#define VM_SWAP_SLOTS IMAGE_SWAP_PAGES
#define VM_RESIDENT_LIMIT 8

typedef struct vm_space vm_space_t;
static inline ptr_t vm_pa(ptr_t kva) { return kva2pa(kva); }

/* Called with translation disabled from the physical bootstrap stub. */
ptr_t vm_boot_root(void);
ptr_t allocKernelPage(int pages);
void freeKernelPage(ptr_t page);

vm_space_t *vm_create(void);
void vm_get(vm_space_t *space);
void vm_put(vm_space_t *space);
void vm_switch(vm_space_t *space);
void *vm_map_page(vm_space_t *space, ptr_t va, unsigned permissions);
int vm_unmap_page(vm_space_t *space, ptr_t va);
int vm_fault(vm_space_t *space, ptr_t va, unsigned scause);
void vm_set_swap_start(unsigned first_sector);
ptr_t vm_shm_get(vm_space_t *space, int key);
int vm_shm_detach(vm_space_t *space, ptr_t va);

int vm_check(vm_space_t *space, ptr_t va, size_t n, unsigned permissions);
int vm_copyin(vm_space_t *space, void *kernel, ptr_t user, size_t n);
int vm_copyout(vm_space_t *space, ptr_t user, const void *kernel, size_t n);
#endif
