#ifndef OS_TASK_H
#define OS_TASK_H
#include <os/image.h>
#define NBYTES2SEC(n) (((n) / SECTOR_SIZE) + ((n) % SECTOR_SIZE != 0))
extern task_info_t tasks[TASK_MAXNUM];
#endif
