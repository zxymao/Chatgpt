#ifndef OS_IMAGE_H
#define OS_IMAGE_H

/* On-disk metadata, shared with the native image builder. */
#if __STDC_HOSTED__
#include <stdint.h>
#else
#include <type.h>
#endif

#define TASK_MEM_BASE  0x200000UL
#define TASK_SIZE      0x10000U
#define TASK_MAXNUM    16
#define TASK_NAME_LEN  32
#define TASK_INFO_SIZE 64
#define SECTOR_SIZE    512U
#define IMAGE_SWAP_PAGES 256U

typedef struct {
    char task_name[TASK_NAME_LEN];
    uint32_t offset;
    uint32_t size;            /* Bytes to copy from the disk. */
    uint64_t entrypoint;
    uint32_t memsz;           /* Includes the zero-filled tail. */
    uint16_t read_pages;      /* One bit per 4 KiB page in TASK_SIZE. */
    uint16_t write_pages;
    uint16_t exec_pages;
    uint16_t word_args;       /* Project 3 numeric ABI; zero selects argc/argv. */
} task_info_t;

_Static_assert(sizeof(task_info_t) == TASK_INFO_SIZE, "task metadata ABI");
#endif
