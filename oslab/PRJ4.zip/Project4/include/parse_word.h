#ifndef PARSE_WORD_H
#define PARSE_WORD_H

/* RISC-V LP64 command arguments (signed or unsigned decimal/hex). */
static inline int parse_word(const char *s, unsigned long *out)
{
    int negative = 0, base = 10, digits = 0;
    unsigned long value = 0;
    if (*s == '+' || *s == '-') { negative = *s == '-'; ++s; }
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) {
        base = 16;
        s += 2;
    }
    unsigned long limit = negative ? (1UL << 63) : ~0UL;
    for (; *s; ++s) {
        unsigned digit;
        if (*s >= '0' && *s <= '9') digit = *s - '0';
        else if (*s >= 'a' && *s <= 'f') digit = *s - 'a' + 10;
        else if (*s >= 'A' && *s <= 'F') digit = *s - 'A' + 10;
        else return 0;
        if (digit >= (unsigned)base || value > (limit - digit) / base) return 0;
        value = value * base + digit;
        ++digits;
    }
    if (!digits) return 0;
    *out = negative ? 0 - value : value;
    return 1;
}

#endif
