#include <stdlib.h>

static uint32_t state;

void srand(uint32_t seed)
{
    __atomic_store_n(&state, seed, __ATOMIC_RELAXED);
}

int rand(void)
{
    uint32_t old = __atomic_load_n(&state, __ATOMIC_RELAXED);
    uint32_t next;
    do {
        next = (0x5deece66dULL * old + 0xb) & RAND_MAX;
    } while (!__atomic_compare_exchange_n(&state, &old, next, 0,
                                          __ATOMIC_RELAXED, __ATOMIC_RELAXED));
    return (int)next;
}
