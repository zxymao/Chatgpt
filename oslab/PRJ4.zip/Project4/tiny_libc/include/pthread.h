#ifndef PTHREAD_H
#define PTHREAD_H
#include <unistd.h>

/* The course API stores the new thread ID (or -1) through thread. */
void pthread_create(pthread_t *thread, void (*start_routine)(void *), void *arg);
int pthread_join(pthread_t thread);
#endif
