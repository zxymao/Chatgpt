#include <pthread.h>
#include <syscall.h>

/* A worker returns here through its initial ra. Its caller is the kernel. */
static void thread_return(void)
{
    invoke_syscall(SYSCALL_THREAD_EXIT, 0, 0, 0, 0, 0);
    __builtin_unreachable();
}

void pthread_create(pthread_t *thread, void (*start_routine)(void *), void *arg)
{
    if (thread)
        *thread = invoke_syscall(SYSCALL_THREAD_CREATE, (long)start_routine,
                                 (long)arg, (long)thread_return, 0, 0);
}

int pthread_join(pthread_t thread)
{
    return invoke_syscall(SYSCALL_THREAD_JOIN, thread, 0, 0, 0, 0);
}
