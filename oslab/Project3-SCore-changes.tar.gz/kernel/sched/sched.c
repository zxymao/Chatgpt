#include <os/list.h>
#include <os/sched.h>
#include <os/time.h>
#include <os/mm.h>
#include <os/irq.h>
#include <os/lock.h>
#include <os/task.h>
#include <os/loader.h>
#include <os/string.h>
#include <os/config.h>
#include <printk.h>
#include <csr.h>
#include <assert.h>

extern int task_num;
extern void ret_from_exception(void);

pcb_t pcb[NUM_MAX_TASK];
const ptr_t pid0_stack = INIT_KERNEL_STACK + PAGE_SIZE;
pcb_t pid0_pcb = { .pid = 0, .kernel_sp = INIT_KERNEL_STACK + PAGE_SIZE,
                   .user_sp = INIT_KERNEL_STACK + PAGE_SIZE };
LIST_HEAD(ready_queue);
LIST_HEAD(sleep_queue);
pid_t process_id = 1;

/* Interrupts are masked. Never recycle the currently executing stack. */
static void reap_exited(void)
{
    for (int i = 0; i < NUM_MAX_TASK; ++i)
        if (&pcb[i] != current_running && pcb[i].used &&
            pcb[i].status == TASK_EXITED)
            pcb[i].used = 0;
}

void init_process_table(void)
{
    list_init(&ready_queue);
    list_init(&sleep_queue);
    bzero(pcb, sizeof(pcb));
    for (int i = 0; i < NUM_MAX_TASK; ++i) {
        pcb[i].status = TASK_EXITED;
        pcb[i].task_id = -1;
        pcb[i].barrier_idx = -1;
        list_init(&pcb[i].list);
        list_init(&pcb[i].wait_list);
    }
    list_init(&pid0_pcb.list);
    list_init(&pid0_pcb.wait_list);
    pid0_pcb.status = TASK_RUNNING;
    pid0_pcb.used = 1;
    pid0_pcb.task_id = -1;
    pid0_pcb.barrier_idx = -1;
    current_running = &pid0_pcb;
    process_id = 1;
    __asm__ volatile ("csrw sscratch, %0" :: "r"(current_running) : "memory");
}

void init_pcb_stack(ptr_t ktop, ptr_t utop, ptr_t entry, pcb_t *task,
                    int argc, uint64_t arg0, uint64_t arg1, uint64_t arg2)
{
    regs_context_t *regs = (regs_context_t *)(ktop - sizeof(*regs));
    switchto_context_t *sw = (switchto_context_t *)((ptr_t)regs - sizeof(*sw));
    bzero(regs, sizeof(*regs));
    bzero(sw, sizeof(*sw));
    regs->regs[2] = utop;
    regs->regs[10] = argc;
    regs->regs[11] = arg0;
    regs->regs[12] = arg1;
    regs->regs[13] = arg2;
    regs->sepc = entry;
#if LAB_STAGE >= 3
    regs->sstatus = SR_SPIE;
#else
    regs->regs[4] = (ptr_t)task;
    regs->sstatus = SR_SPP;
#endif
    sw->regs[0] = (ptr_t)ret_from_exception;
    sw->regs[1] = (ptr_t)sw;
    task->kernel_sp = (ptr_t)sw;
    task->user_sp = utop;
}

void do_scheduler(void)
{
    uint64_t flags = irq_save();
    reap_exited();
    check_sleeping();
    pcb_t *prev = current_running;
    if (prev->status == TASK_RUNNING && prev != &pid0_pcb) {
        prev->status = TASK_READY;
        list_add_tail(&prev->list, &ready_queue);
    }
    list_node_t *node = list_pop_front(&ready_queue);
    pcb_t *next = node ? list_entry(node, pcb_t, list) : &pid0_pcb;
    if (prev == &pid0_pcb && next != prev) prev->status = TASK_READY;
    next->status = TASK_RUNNING;
    if (prev != next) switch_to(prev, next);
    irq_restore(flags);
}

void do_sleep(uint32_t seconds)
{
    uint64_t flags = irq_save();
    if (!seconds) do_scheduler();
    else {
        current_running->wakeup_time = get_ticks() + (uint64_t)seconds * time_base;
        do_block(&current_running->list, &sleep_queue);
    }
    irq_restore(flags);
}

void do_block(list_node_t *node, list_head *queue)
{
    uint64_t flags = irq_save();
    assert(node == &current_running->list && current_running != &pid0_pcb);
    assert(list_empty(node));
    current_running->status = TASK_BLOCKED;
    list_add_tail(node, queue);
    do_scheduler();
    irq_restore(flags);
}

void do_unblock(list_node_t *node)
{
    uint64_t flags = irq_save();
    pcb_t *task = list_entry(node, pcb_t, list);
    assert(task->status == TASK_BLOCKED);
    list_del(node);
    task->status = TASK_READY;
    list_add_tail(node, &ready_queue);
    irq_restore(flags);
}

pid_t do_exec(int id, int argc, uint64_t arg0, uint64_t arg1, uint64_t arg2)
{
    uint64_t flags = irq_save();
    if (id < 0 || id >= task_num || argc < 0 || argc > 3 ||
        process_id == INT32_MAX) {
        irq_restore(flags);
        return -1;
    }
    reap_exited();
    pcb_t *task = NULL;
    int image_in_use = 0;
    for (int i = 0; i < NUM_MAX_TASK; ++i) {
        if (!pcb[i].used && !task) task = &pcb[i];
        if (pcb[i].used && pcb[i].status != TASK_EXITED && pcb[i].task_id == id)
            image_in_use = 1;
    }
    if (!task) {
        irq_restore(flags);
        return -1;
    }
    /* Flat shared images: do not overwrite another live instance's data. */
    ptr_t entry = image_in_use ? tasks[id].entrypoint :
                                load_task_img(tasks[id].task_name);
    if (!entry) {
        irq_restore(flags);
        return -1;
    }
    ptr_t kbase = task->kernel_stack_base;
    ptr_t ubase = task->user_stack_base;
    if (!kbase) kbase = allocKernelPage(1);
    if (!ubase) ubase = allocUserPage(1);
    bzero(task, sizeof(*task));
    task->kernel_stack_base = kbase;
    task->user_stack_base = ubase;
    task->task_id = id;
    task->barrier_idx = -1;
    list_init(&task->list);
    list_init(&task->wait_list);
    init_pcb_stack(kbase + PAGE_SIZE, ubase + PAGE_SIZE, entry,
                   task, argc, arg0, arg1, arg2);
    task->pid = process_id++;
    task->used = 1;
    task->status = TASK_READY;
    list_add_tail(&task->list, &ready_queue);
    pid_t pid = task->pid;
    irq_restore(flags);
    return pid;
}

static pcb_t *find_process(pid_t pid)
{
    for (int i = 0; i < NUM_MAX_TASK; ++i)
        if (pcb[i].used && pcb[i].pid == pid) return &pcb[i];
    return NULL;
}

/* One termination protocol for exit and kill; caller masks interrupts. */
static void finish_process(pcb_t *task)
{
    barrier_cancel_wait(task);
    if (!list_empty(&task->list)) list_del(&task->list);
    task->status = TASK_EXITED;
    mutex_release_all(task->pid);
    while (!list_empty(&task->wait_list)) do_unblock(task->wait_list.next);
    /* Reuse the slot's stacks only when no CPU is executing on them. */
    if (task != current_running) task->used = 0;
}

void do_exit(void)
{
    irq_save();
    assert(current_running != &pid0_pcb);
    finish_process(current_running);
    do_scheduler();
    assert(0);
}

int do_kill(pid_t pid)
{
    uint64_t flags = irq_save();
    pcb_t *task = find_process(pid);
    if (pid <= 0 || !task || task->status == TASK_EXITED) {
        irq_restore(flags);
        return -1;
    }
    int self = task == current_running;
    finish_process(task);
    if (self) {
        do_scheduler();
        assert(0);
    }
    irq_restore(flags);
    return pid;
}

int do_waitpid(pid_t pid)
{
    uint64_t flags = irq_save();
    if (pid <= 0 || pid >= process_id || pid == current_running->pid) {
        irq_restore(flags);
        return -1;
    }
    pcb_t *task = find_process(pid);
    /* Every earlier PID was created; PIDs are monotonic and never reused.
     * A completed PID can still be waited on after its PCB slot is recycled. */
    if (task && task->status != TASK_EXITED)
        do_block(&current_running->list, &task->wait_list);
    irq_restore(flags);
    return pid;
}

pid_t do_getpid(void)
{
    return current_running->pid;
}

void do_process_show(void)
{
    static const char *states[] = {"BLOCKED", "RUNNING", "READY", "EXITED"};
    uint64_t flags = irq_save();
    printk("PID  STATUS   PROGRAM\n");
    printk("0    %s idle\n", states[pid0_pcb.status]);
    for (int i = 0; i < NUM_MAX_TASK; ++i) {
        pcb_t *task = &pcb[i];
        if (task->used && task->status != TASK_EXITED)
            printk("%d    %s %s\n", task->pid, states[task->status],
                   tasks[task->task_id].task_name);
    }
    irq_restore(flags);
}
