#include <os/lock.h>
#include <os/sched.h>
#include <os/irq.h>
#include <atomic.h>
#include <assert.h>

mutex_lock_t mlocks[LOCK_NUM];
void spin_lock_init(spin_lock_t *lock) { lock->status = UNLOCKED; }
int spin_lock_try_acquire(spin_lock_t *lock)
{
    return atomic_swap(LOCKED, (ptr_t)&lock->status) == UNLOCKED;
}
void spin_lock_acquire(spin_lock_t *lock)
{
    while (!spin_lock_try_acquire(lock)) __asm__ volatile ("nop");
}
void spin_lock_release(spin_lock_t *lock)
{
    atomic_swap(UNLOCKED, (ptr_t)&lock->status);
}
void init_locks(void)
{
    for (int i = 0; i < LOCK_NUM; ++i) {
        spin_lock_init(&mlocks[i].lock);
        list_init(&mlocks[i].block_queue);
        mlocks[i].used = 0;
        mlocks[i].owner = 0;
    }
}
int do_mutex_lock_init(int key)
{
    uint64_t flags = irq_save();
    int free_slot = -1;
    for (int i = 0; i < LOCK_NUM; ++i) {
        if (mlocks[i].used && mlocks[i].key == key) {
            irq_restore(flags);
            return i;
        }
        if (!mlocks[i].used && free_slot < 0) free_slot = i;
    }
    if (free_slot >= 0) {
        mlocks[free_slot].used = 1;
        mlocks[free_slot].key = key;
    }
    irq_restore(flags);
    return free_slot;
}
static mutex_lock_t *get_lock(int id)
{
    assert(id >= 0 && id < LOCK_NUM && mlocks[id].used);
    return &mlocks[id];
}
void do_mutex_lock_acquire(int id)
{
    uint64_t flags = irq_save();
    mutex_lock_t *lock = get_lock(id);
    assert(lock->owner != current_running->pid); /* non-recursive */
    if (spin_lock_try_acquire(&lock->lock)) {
        lock->owner = current_running->pid;
    } else {
        do_block(&current_running->list, &lock->block_queue);
        /* release handed ownership to us; no stealing by a new arrival. */
        assert(lock->owner == current_running->pid);
    }
    irq_restore(flags);
}
/* The owner has already been checked by the caller. */
static void release_owned_lock(mutex_lock_t *lock)
{
    if (!list_empty(&lock->block_queue)) {
        list_node_t *node = lock->block_queue.next;
        lock->owner = list_entry(node, pcb_t, list)->pid;
        do_unblock(node); /* lock remains LOCKED until this owner releases */
    } else {
        lock->owner = 0;
        spin_lock_release(&lock->lock);
    }
}

void do_mutex_lock_release(int id)
{
    uint64_t flags = irq_save();
    mutex_lock_t *lock = get_lock(id);
    assert(lock->owner == current_running->pid);
    release_owned_lock(lock);
    irq_restore(flags);
}

void mutex_release_all(pid_t owner)
{
    uint64_t flags = irq_save();
    for (int i = 0; i < LOCK_NUM; ++i)
        if (mlocks[i].used && mlocks[i].owner == owner)
            release_owned_lock(&mlocks[i]);
    irq_restore(flags);
}

static barrier_t barriers[BARRIER_NUM];

void init_barriers(void)
{
    for (int i = 0; i < BARRIER_NUM; ++i) {
        barriers[i].used = 0;
        barriers[i].arrived = 0;
        barriers[i].generation = 0;
        list_init(&barriers[i].wait_queue);
    }
}

int do_barrier_init(int key, int goal)
{
    uint64_t flags = irq_save();
    if (goal < 1 || goal > NUM_MAX_TASK) {
        irq_restore(flags);
        return -1;
    }
    int free_slot = -1;
    for (int i = 0; i < BARRIER_NUM; ++i) {
        if (barriers[i].used && barriers[i].key == key) {
            int result = barriers[i].goal == goal ? i : -1;
            irq_restore(flags);
            return result;
        }
        if (!barriers[i].used && free_slot < 0) free_slot = i;
    }
    if (free_slot >= 0) {
        barrier_t *bar = &barriers[free_slot];
        bar->used = 1;
        bar->key = key;
        bar->goal = goal;
        bar->arrived = 0;
        ++bar->generation;
        list_init(&bar->wait_queue);
    }
    irq_restore(flags);
    return free_slot;
}

static void wake_barrier_waiters(barrier_t *bar)
{
    while (!list_empty(&bar->wait_queue)) {
        list_node_t *node = bar->wait_queue.next;
        list_entry(node, pcb_t, list)->barrier_idx = -1;
        do_unblock(node);
    }
}

void do_barrier_wait(int id)
{
    uint64_t flags = irq_save();
    if (id < 0 || id >= BARRIER_NUM || !barriers[id].used) {
        irq_restore(flags);
        return;
    }
    barrier_t *bar = &barriers[id];
    if (++bar->arrived == bar->goal) {
        bar->arrived = 0;
        ++bar->generation;
        wake_barrier_waiters(bar);
    } else {
        current_running->barrier_idx = id;
        do_block(&current_running->list, &bar->wait_queue);
        current_running->barrier_idx = -1;
    }
    irq_restore(flags);
}

void do_barrier_destroy(int id)
{
    uint64_t flags = irq_save();
    if (id >= 0 && id < BARRIER_NUM && barriers[id].used) {
        barrier_t *bar = &barriers[id];
        bar->used = 0;
        bar->arrived = 0;
        ++bar->generation;
        wake_barrier_waiters(bar); /* Destroy cancels outstanding waits. */
    }
    irq_restore(flags);
}

/* Termination removes a waiting participant; it does not silently count that
 * participant as an arrival. The application can destroy/cancel the barrier. */
void barrier_cancel_wait(pcb_t *task)
{
    int id = task->barrier_idx;
    if (id >= 0 && id < BARRIER_NUM && barriers[id].used &&
        barriers[id].arrived > 0)
        --barriers[id].arrived;
    task->barrier_idx = -1;
}
