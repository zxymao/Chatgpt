# P3 S-Core 验证记录

本版本以已完成的 P2 A-Core 为基础，整合老师 Project3 框架。范围为单核进程管理、shell、可复用 barrier。S-Core 的 exec 按程序 ID 创建新进程，最多传三个整数参数。

## 已执行

1. 原课程地址布局交叉编译：`make CROSS_PREFIX=riscv64-linux-gnu-` 成功；内核文件跨度 15452 字节，低于镜像格式的 65535 字节上限；默认六个程序全部生成。
2. `python3 tools/host_qemu_p3.py --log-dir docs/p3-validation` 成功，通过真实串口输入执行以下检查：
   - shell 的 ps、clear、退格、未知命令、非法程序编号、非数字参数、超长输入、CR/LF/CRLF；
   - 后台 exec 与 shell kill 命令；
   - 老师的 waitpid、ready_to_exit、wait_locks 测试，正常返回及前台等待；
   - 老师的三进程 barrier 测试，每个参与者完成十轮；
   - 参数寄存器传递、动态 PID 下的字符串输出、40 次创建/退出及已退出 PID 等待；
   - 杀死睡眠且持有两把锁的进程，唤醒锁等待者和 waitpid 等待者；
   - PCB 数量耗尽后恢复复用，销毁有等待者的屏障，终止屏障参与者后取消屏障；
   - 测试结束后 shell 仍响应，已结束进程不再出现在 ps。
3. `python3 tools/host_qemu_smoke.py --stage 4 --seconds 8 --log docs/p3-validation/p2-regression.log` 成功：P2 两个 probe 均 PASS，包括用户寄存器、无系统调用循环中的异步抢占、睡眠与锁所有权移交。

机器可读结果见 `p3-validation/results.json`；原始串口和还原后的屏幕记录均在同目录。`p3_probe`、`p3_worker` 是新增验证程序，默认镜像不包含它们。老师测试中只配置了三个原有的 `-1` 程序编号占位符。

## 验证环境与范围

通用 QEMU 的 RAM 从 0x80000000 开始。运行脚本仅在临时副本中将课程的 0x50000000–0x52ffffff 地址整体加 0x30000000，并使用 test/host-qemu 的测试 BIOS 提供镜像读取、定时器和串口服务。测试执行实际的内核、用户程序、异常入口和切换汇编；源码包中的课程地址不变。

没有运行课程专用 QEMU、课程 U-Boot、loadbootd/DASIC 或 Pynq 板。通用 QEMU 通过不等于完成课程硬件验收；请在老师的 SSH 环境执行 `make run` 和课程规定的检查。

## 明确的接口约定

- PID 从 1 单调递增，不复用；空闲 PCB 槽位及其两页栈可以复用。目标存在时 waitpid 阻塞，目标已经结束时立即返回该 PID；0、自身、未来或非法 PID 返回 -1。没有增加 POSIX 的父子权限和退出状态接口。
- 退出和 kill 复用同一清理流程。当前进程正在使用的内核栈，在切换出去之前不回收。
- barrier 销毁会取消并唤醒已有等待者。被 kill 的等待者从到达数中扣除，目标人数不自动减少；应用应补足参与者或销毁该屏障。
- 本课程采用固定地址、共享程序映像；不同实例使用独立 PCB/栈。活着的同程序实例不被重新装载覆盖，但没有增加每进程独立地址空间或私有全局变量。
- mutex 沿用 P2 的非递归锁及参数断言。条件变量、信号量、邮箱、SMP 不属于本 S-Core 实现。

## C23 默认标准兼容性修复

用户的新编译器默认按 C23 处理源码，出现 typedef int bool 与空参数函数指针的错误。Makefile 现显式加入 -std=gnu11，主机镜像工具也使用同一 C 标准。

使用 GCC 14 的 -std=gnu2x 对 init/main.c、kernel/syscall/syscall.c 做语法检查，已复现 bool 以及函数指针类型/参数数量错误。随后完整构建时让 CC、HOST_CC 先传 -std=gnu2x，再由 Makefile 后置的 -std=gnu11 覆盖，内核与六个默认程序全部构建成功。

修复后再次执行 tools/host_qemu_p3.py --basic-only，shell 输入、ps/clear/退格、后台 exec/kill、课程 waitpid 和正常退出均通过。详细结果位于 docs/p3-gnu11-validation；原先完整十轮屏障及 P2 回归记录仍保留。未在用户 SSH 环境直接执行。
