#ifndef P3_SHARED_H
#define P3_SHARED_H
#include <stdint.h>
#define P3_RETURN 1
#define P3_HOLD 2
#define P3_WAIT_LOCKS 3
#define P3_SLEEP 4
#define P3_BARRIER 5
#define P3_MAGIC 0x12345678UL
struct p3_shared {
    volatile int holding;
    volatile int waiting;
    volatile int finished;
    volatile int unexpected;
    volatile uint64_t result;
    int lock1;
    int lock2;
    int barrier;
};
#endif
