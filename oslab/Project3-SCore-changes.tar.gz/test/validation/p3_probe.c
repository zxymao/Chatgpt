#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <assert.h>
#include "p3_shared.h"
static void report(const char *message)
{
    sys_move_cursor(0, 10);
    printf("[P3-CHECK] %s                                      \n", message);
    sys_reflush();
}
static void await(volatile int *flag)
{
    long start = sys_get_tick();
    while (!*flag) {
        assert(sys_get_tick() - start < 3 * sys_get_timebase());
        sys_yield();
    }
}
int main(int argc, int worker_id)
{
    assert(argc == 1);
    assert(sys_exec(-1, 0, 0, 0, 0) == -1);
    assert(sys_exec(worker_id, 4, 0, 0, 0) == -1);
    assert(sys_waitpid(sys_getpid()) == -1);
    assert(sys_waitpid(0) == -1);
    assert(sys_waitpid(1000000) == -1);
    assert(sys_kill(0) == -1);
    assert(sys_kill(1000000) == -1);
    pid_t first = 0;
    for (int i = 0; i < 40; ++i) {
        struct p3_shared value = {0};
        pid_t child = sys_exec(worker_id, 3, P3_RETURN, (uint64_t)&value, P3_MAGIC);
        assert(child > 0);
        if (!first) first = child;
        assert(sys_waitpid(child) == child);
        assert(value.result == P3_MAGIC);
    }
    assert(sys_waitpid(first) == first);
    report("args/reuse PASS");

    struct p3_shared locks = {0};
    locks.lock1 = sys_mutex_init(71);
    locks.lock2 = sys_mutex_init(72);
    assert(locks.lock1 >= 0 && locks.lock2 >= 0);
    pid_t holder = sys_exec(worker_id, 3, P3_HOLD, (uint64_t)&locks, 0);
    assert(holder > 0);
    await(&locks.holding);
    pid_t waiter = sys_exec(worker_id, 3, P3_WAIT_LOCKS, (uint64_t)&locks, 0);
    assert(waiter > 0);
    await(&locks.waiting);
    sys_sleep(1);
    assert(!locks.finished);
    assert(sys_kill(holder) == holder);
    assert(sys_waitpid(holder) == holder);
    assert(sys_waitpid(waiter) == waiter);
    assert(locks.finished && !locks.unexpected);
    report("kill-locks PASS");

    pid_t children[20];
    int count = 0;
    for (; count < 20; ++count) {
        children[count] = sys_exec(worker_id, 3, P3_SLEEP, 0, 0);
        if (children[count] < 0) break;
    }
    assert(count > 0 && count < 16);
    assert(sys_exec(worker_id, 3, P3_SLEEP, 0, 0) == -1);
    for (int i = 0; i < count; ++i) {
        assert(sys_kill(children[i]) == children[i]);
        assert(sys_waitpid(children[i]) == children[i]);
    }
    report("capacity PASS");

    struct p3_shared barrier = {0};
    barrier.barrier = sys_barrier_init(777, 2);
    assert(barrier.barrier >= 0);
    assert(sys_barrier_init(777, 2) == barrier.barrier);
    assert(sys_barrier_init(777, 3) == -1);
    pid_t blocked = sys_exec(worker_id, 3, P3_BARRIER, (uint64_t)&barrier, 0);
    assert(blocked > 0);
    await(&barrier.waiting);
    sys_sleep(1);
    assert(!barrier.finished);
    sys_barrier_destroy(barrier.barrier);
    assert(sys_waitpid(blocked) == blocked && barrier.finished);
    barrier.waiting = barrier.finished = 0;
    barrier.barrier = sys_barrier_init(777, 2);
    blocked = sys_exec(worker_id, 3, P3_BARRIER, (uint64_t)&barrier, 0);
    assert(blocked > 0);
    await(&barrier.waiting);
    sys_sleep(1);
    assert(sys_kill(blocked) == blocked);
    assert(sys_waitpid(blocked) == blocked);
    sys_barrier_destroy(barrier.barrier);
    int one = sys_barrier_init(777, 1);
    assert(one >= 0);
    sys_barrier_wait(one);
    sys_barrier_destroy(one);
    report("barrier-cancel PASS");
    report("all PASS");
    return 0;
}
