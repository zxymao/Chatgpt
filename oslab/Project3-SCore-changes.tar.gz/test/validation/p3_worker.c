#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <assert.h>
#include "p3_shared.h"
static long raw_write(const char *s)
{
    register long a0 asm("a0") = (long)s;
    register long a7 asm("a7") = 20;
    asm volatile("ecall" : "+r"(a0) : "r"(a7) : "memory");
    return a0;
}
int main(int argc, uint64_t mode, uint64_t address, uint64_t value)
{
    assert(argc == 3);
    if (mode == P3_SLEEP) {
        sys_sleep(30);
        return 0;
    }
    struct p3_shared *shared = (struct p3_shared *)address;
    assert(shared != 0);
    if (mode == P3_RETURN) {
        assert(value == P3_MAGIC);
        assert(sys_getpid() > 1);
        sys_move_cursor(0, 12);
        /* A new PID must retain access to its own image's constant strings. */
        assert(raw_write("[P3-WORKER] image/args checked") == 0);
        assert(raw_write((const char *)1) == -14);
        shared->result = value;
        return 0;
    }
    if (mode == P3_HOLD) {
        sys_mutex_acquire(shared->lock1);
        sys_mutex_acquire(shared->lock2);
        shared->holding = 1;
        sys_sleep(30);
        shared->unexpected = 1;
    } else if (mode == P3_WAIT_LOCKS) {
        shared->waiting = 1;
        sys_mutex_acquire(shared->lock1);
        sys_mutex_acquire(shared->lock2);
        shared->finished = 1;
        sys_mutex_release(shared->lock2);
        sys_mutex_release(shared->lock1);
    } else if (mode == P3_BARRIER) {
        shared->waiting = 1;
        sys_barrier_wait(shared->barrier);
        shared->finished = 1;
    } else assert(0);
    return 0;
}
