/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 *            Copyright (C) 2018 Institute of Computing Technology, CAS
 *               Author : Han Shukai (email : hanshukai@ict.ac.cn)
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 *                  The shell acts as a task running in user mode.
 *       The main function is to make system calls through the user's output.
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * */

/* Project3 S-Core shell implementation. */
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>

#define SHELL_BEGIN 20
#define LINE_SIZE 128
#define MAX_WORDS 8

static int number(const char *s, uint64_t *out)
{
    int negative = 0, base = 10, digits = 0;
    uint64_t value = 0;
    if (*s == '+' || *s == '-') { negative = *s == '-'; ++s; }
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) {
        base = 16;
        s += 2;
    }
    uint64_t limit = negative ? (1ULL << 63) : ~0ULL;
    for (; *s; ++s) {
        unsigned digit;
        if (*s >= '0' && *s <= '9') digit = *s - '0';
        else if (*s >= 'a' && *s <= 'f') digit = *s - 'a' + 10;
        else if (*s >= 'A' && *s <= 'F') digit = *s - 'A' + 10;
        else return 0;
        if (digit >= (unsigned)base || value > (limit - digit) / base) return 0;
        value = value * base + digit;
        ++digits;
    }
    if (!digits) return 0;
    *out = negative ? 0 - value : value;
    return 1;
}

static int split(char *line, char **words)
{
    int count = 0;
    while (*line) {
        while (*line == ' ' || *line == '\t') ++line;
        if (!*line) break;
        if (count == MAX_WORDS) return -1;
        words[count++] = line;
        while (*line && *line != ' ' && *line != '\t') ++line;
        if (*line) *line++ = '\0';
    }
    return count;
}

static void banner(void)
{
    sys_move_cursor(0, SHELL_BEGIN);
    printf("------------------- COMMAND -------------------\n");
}

static void command(char *line)
{
    char *words[MAX_WORDS];
    int count = split(line, words);
    if (!count) return;
    if (count < 0) { printf("Too many arguments\n"); return; }
    if (!strcmp(words[0], "ps") && count == 1) sys_ps();
    else if (!strcmp(words[0], "clear") && count == 1) {
        sys_clear();
        banner();
    } else if (!strcmp(words[0], "help") && count == 1) {
        printf("ps | clear | exec ID [arg0 arg1 arg2] [&] | kill PID\n");
        printf("Use 'make list-tasks' in the Linux terminal to see program IDs.\n");
    } else if (!strcmp(words[0], "exec")) {
        int background = !strcmp(words[count - 1], "&");
        if (background) --count;
        uint64_t id, args[3] = {0};
        if (count < 2 || count > 5 || !number(words[1], &id) || id > INT32_MAX) {
            printf("Usage: exec ID [arg0 arg1 arg2] [&]\n");
            return;
        }
        for (int i = 2; i < count; ++i) {
            if (!number(words[i], &args[i - 2])) {
                printf("Invalid numeric argument\n");
                return;
            }
        }
        pid_t pid = sys_exec((int)id, count - 2, args[0], args[1], args[2]);
        if (pid < 0) printf("exec failed\n");
        else if (background) printf("[shell] started pid=%d\n", pid);
        else sys_waitpid(pid);
    } else if (!strcmp(words[0], "kill")) {
        uint64_t pid;
        if (count != 2 || !number(words[1], &pid) || pid == 0 || pid > INT32_MAX) {
            printf("Usage: kill PID\n");
            return;
        }
        if (sys_kill((pid_t)pid) < 0) printf("kill failed\n");
        else printf("[shell] killed pid=%d\n", (int)pid);
    } else printf("Unknown command\n");
}

int main(void)
{
    char line[LINE_SIZE];
    int length = 0, skip_lf = 0;
    banner();
    printf("> root@UCAS_OS: ");
    for (;;) {
        int ch = sys_getchar();
        if (ch < 0) { sys_yield(); continue; }
        if (skip_lf && ch == '\n') { skip_lf = 0; continue; }
        skip_lf = 0;
        if (ch == '\r' || ch == '\n') {
            skip_lf = ch == '\r';
            line[length] = '\0';
            printf("\n");
            command(line);
            length = 0;
            printf("> root@UCAS_OS: ");
        } else if (ch == '\b' || ch == 127) {
            if (length > 0) { --length; printf("\b"); }
        } else {
            if (ch == '\t') ch = ' ';
            if (ch >= 32 && ch <= 126 && length < LINE_SIZE - 1) {
                line[length++] = ch;
                printf("%c", ch);
            }
        }
    }
}
