#!/usr/bin/env python3
"""Exercise the real S-Core kernel through QEMU UART input.
Only a temporary copy is relocated to upstream virt RAM. The test BIOS is
not course U-Boot/SD/DASIC and cannot substitute for course-board acceptance.
"""
import argparse
import os
from pathlib import Path
import re
import selectors
import shutil
import subprocess
import tempfile
import time
import json

ROOT = Path(__file__).resolve().parents[1]
TASKS = 'shell waitpid ready_to_exit wait_locks barrier test_barrier p3_probe p3_worker'
PROMPT = '> root@UCAS_OS:'

class Screen:
    def __init__(self):
        self.lines = [[' '] * 160 for _ in range(80)]
        self.row = self.col = 0
        self.pending = ''
        self.prompt_active = [False] * 80
        self.prompts = 0
        self.events = []
        self.barrier_rows = set()
        self.fault = False
        self.markers = set()

    def observe(self):
        line = ''.join(self.lines[self.row]).rstrip()
        active = line == PROMPT
        if active and not self.prompt_active[self.row]: self.prompts += 1
        self.prompt_active[self.row] = active
        if not self.events or self.events[-1] != line:
            self.events.append(line)
        if 'Exited barrier (9)' in line and self.row in (0, 1, 2):
            self.barrier_rows.add(self.row)
        for marker in ['Unknown command', 'exec failed', 'Invalid numeric argument',
                       'PID  STATUS   PROGRAM', '[P3-CHECK] args/reuse PASS',
                       '[P3-CHECK] kill-locks PASS', '[P3-CHECK] capacity PASS',
                       '[P3-CHECK] barrier-cancel PASS', '[P3-CHECK] all PASS']:
            if marker in line: self.markers.add(marker)
        if 'Assertion failed' in line or 'scause:' in line: self.fault = True

    def feed(self, data):
        self.pending += data.decode(errors='replace')
        i = 0
        while i < len(self.pending):
            ch = self.pending[i]
            if ch == '\x1b':
                match = re.match(r'\x1b\[[0-9;?]*[A-Za-z]', self.pending[i:])
                if not match: break
                self.observe()
                token = match[0]
                if token.endswith('H'):
                    coords = token[2:-1].split(';')
                    self.row = max(0, min(79, int(coords[0] or 1) - 1))
                    self.col = max(0, min(159, int(coords[1] or 1) - 1)) if len(coords) > 1 else 0
                elif token == '\x1b[2J':
                    self.lines = [[' '] * 160 for _ in range(80)]
                    self.prompt_active = [False] * 80
                i += len(token)
                continue
            if ch == '\n': self.observe(); self.row = min(79, self.row + 1)
            elif ch == '\r': self.observe(); self.col = 0
            elif ch.isprintable():
                self.lines[self.row][self.col] = ch
                self.col = min(159, self.col + 1)
            i += 1
            self.observe()
        self.pending = self.pending[i:]

class Guest:
    def __init__(self, cmd, logdir):
        self.process = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=subprocess.STDOUT)
        self.select = selectors.DefaultSelector()
        self.select.register(self.process.stdout, selectors.EVENT_READ)
        self.screen = Screen()
        self.raw = bytearray()
        self.logdir = logdir

    def wait(self, condition, seconds=8):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if self.screen.fault: raise RuntimeError('guest exception/assertion')
            if condition(): return
            if self.process.poll() is not None: raise RuntimeError('QEMU exited unexpectedly')
            for key, _ in self.select.select(0.1):
                data = os.read(key.fileobj.fileno(), 65536)
                if data: self.raw.extend(data); self.screen.feed(data)
        raise RuntimeError('guest evidence timeout; last lines: ' + repr(self.screen.events[-8:]))

    def command(self, text, seconds=8):
        before = self.screen.prompts
        self.process.stdin.write(text.encode()); self.process.stdin.flush()
        self.wait(lambda: self.screen.prompts > before, seconds)

    def close(self):
        self.process.terminate()
        try: self.process.wait(timeout=3)
        except subprocess.TimeoutExpired: self.process.kill(); self.process.wait()
        self.select.close()
        (self.logdir / 'uart.raw.log').write_bytes(self.raw)
        (self.logdir / 'screen-events.txt').write_text('\n'.join(self.screen.events))
        (self.logdir / 'last-screen.txt').write_text('\n'.join(''.join(row).rstrip() for row in self.screen.lines))

parser = argparse.ArgumentParser()
parser.add_argument('--qemu', default='qemu-system-riscv64')
parser.add_argument('--cross-prefix', default='riscv64-linux-gnu-')
parser.add_argument('--log-dir', type=Path, default=Path('p3-host-validation'))
parser.add_argument('--basic-only', action='store_true')
args = parser.parse_args()
logdir = args.log_dir.resolve(); logdir.mkdir(parents=True, exist_ok=True)
checks = []
with tempfile.TemporaryDirectory(prefix='p3-uart-check-') as tmp:
    tree = Path(tmp) / 'Project3'
    shutil.copytree(ROOT, tree, ignore=shutil.ignore_patterns('build', '.git', '*.log', '__pycache__'))
    for path in tree.rglob('*'):
        if not path.is_file() or 'host-qemu' in path.parts: continue
        if path.suffix in ('.c', '.h', '.S') or path.name == 'Makefile':
            def relocate(match):
                value = int(match[0], 16)
                return hex(value + 0x30000000) if 0x50000000 <= value < 0x53000000 else match[0]
            path.write_text(re.sub(r'0[xX][0-9a-fA-F]+', relocate, path.read_text()))
    with (logdir / 'build-relocated.log').open('w') as buildlog:
        subprocess.run(['make', 'image', 'CROSS_PREFIX=' + args.cross_prefix,
                        'LAB_STAGE=4', 'TASKS=' + TASKS], cwd=tree,
                       stdout=buildlog, stderr=subprocess.STDOUT, check=True)
        fw = ROOT / 'test/host-qemu'
        subprocess.run([args.cross_prefix + 'gcc', '-nostdlib', '-static', '-fno-pie',
                        '-no-pie', '-march=rv64imac_zicsr_zifencei', '-mabi=lp64',
                        '-Wl,--build-id=none', '-Wl,--no-relax', '-T', str(fw / 'firmware.lds'),
                        str(fw / 'firmware.S'), '-o', str(tree / 'firmware.elf')],
                       stdout=buildlog, stderr=subprocess.STDOUT, check=True)
    command = [args.qemu, '-machine', 'virt', '-m', '256M', '-nographic', '-monitor', 'none',
               '-bios', str(tree / 'firmware.elf'), '-device',
               'loader,file=' + str(tree / 'build/image') + ',addr=0x84000000,force-raw=on']
    guest = Guest(command, logdir)
    try:
        guest.wait(lambda: guest.screen.prompts > 0)
        guest.command('ps\n')
        assert 'PID  STATUS   PROGRAM' in guest.screen.markers
        assert any(re.search(r'\b0\s+READY\s+idle', row) for row in guest.screen.events)
        assert any(re.search(r'\b1\s+RUNNING\s+shell', row) for row in guest.screen.events)
        guest.command('\bpss\b\n')
        assert 'Unknown command' not in guest.screen.markers
        guest.command('not-a-command\n')
        assert 'Unknown command' in guest.screen.markers
        guest.command('exec 99\n')
        assert 'exec failed' in guest.screen.markers
        guest.command('exec 1 invalid\n')
        assert 'Invalid numeric argument' in guest.screen.markers
        guest.command('clear\n')
        guest.command('x' * 200 + '\n')
        guest.command('clear\r\n')
        event_start = len(guest.screen.events)
        guest.command('exec 7 4 0 0 &\n')
        starts = [re.search(r'\[shell\] started pid=(\d+)', row)
                  for row in guest.screen.events[event_start:]]
        starts = [match for match in starts if match]
        assert starts, 'background exec did not return a PID'
        background_pid = int(starts[-1][1])
        guest.command('ps\n')
        assert any(re.search(r'\b' + str(background_pid) + r'\s+(?:READY|BLOCKED)\s+p3_worker', row)
                   for row in guest.screen.events[event_start:])
        event_start = len(guest.screen.events)
        guest.command('kill ' + str(background_pid) + '\n')
        assert any('[shell] killed pid=' + str(background_pid) in row
                   for row in guest.screen.events[event_start:])
        guest.command('clear\n')
        checks.append('UART, ps, unknown command, backspace, numeric validation, long input, clear/CRLF')
        checks.append('shell background exec and kill commands')
        print('Verified shell UART/editor/commands', flush=True)
        guest.command('exec 1\n', 15)
        assert any('Task (pid=' in row and 'has exited.' in row for row in guest.screen.events)
        checks.append('course waitpid, normal exit and foreground wait')
        print('Verified course waitpid/normal exit', flush=True)
        if not args.basic_only:
            guest.command('exec 4\n', 45)
            assert guest.screen.barrier_rows == {0, 1, 2}, guest.screen.barrier_rows
            checks.append('course three-process barrier, ten rounds, waitpid and destroy')
            print('Verified course barrier: all three tasks completed round 9', flush=True)
            guest.command('exec 6 7\n', 20)
            for mark in ['args/reuse PASS', 'kill-locks PASS', 'capacity PASS', 'barrier-cancel PASS', 'all PASS']:
                assert '[P3-CHECK] ' + mark in guest.screen.markers, mark
            checks.append('argument registers, PID-based image access, 40 exec/exit cycles, completed-PID wait')
            checks.append('kill sleeping two-lock owner, wake lock waiter and waitpid')
            checks.append('PCB capacity/reuse, barrier destroy/cancel and killed participant')
            print('Verified lifecycle, lock cleanup, capacity and barrier cancellation probes', flush=True)
        before = len(guest.screen.events)
        guest.command('ps\n')
        recent = guest.screen.events[before:]
        assert any(re.search(r'\b1\s+RUNNING\s+shell', row) for row in recent)
        assert not any(re.search(r'\b(?:READY|RUNNING|BLOCKED)\s+(?:waitpid|ready_to_exit|wait_locks|barrier|test_barrier|p3_probe|p3_worker)\s*$', row) for row in recent)
        checks.append('shell remains responsive; completed test processes absent from ps')
        result = {'passed': True, 'checks': checks, 'tasks': TASKS,
                  'scope': 'real kernel in upstream QEMU with temporary relocation and a test BIOS; course hardware/firmware not validated'}
        (logdir / 'results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps(result, ensure_ascii=False), flush=True)
    finally:
        guest.close()
