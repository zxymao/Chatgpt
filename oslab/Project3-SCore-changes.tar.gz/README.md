# Project3 S-Core：进程管理、shell 与屏障

这是基于本次对话中的 Project2-Acore 底稿及老师 Project3 框架的参考实现。保留 P2 的 U 态、ecall 和时钟抢占，在其上实现按 ID 创建进程、exit/kill/waitpid/ps/getpid、shell 和可复用 barrier。

## 在现有仓库中使用

先提交已经解决的合并：

```bash
git commit -m "Merge Project3 S-Core framework"
```

merge_p3_score.py 只是辅助脚本，可以留作未跟踪文件。之后按说明修改现有 Project3-work 工作树，或者先在独立目录阅读完整源码包。改动包只包含列明的文件，不包含 .git。

```bash
make list-tasks
make
make run
```

默认沿用老师环境中的 riscv64-unknown-linux-gnu-gcc、~/OSLab-RISC-V/qemu 和 ~/OSLab-RISC-V/u-boot。可按实际环境指定 `CROSS_PREFIX=riscv64-linux-gnu-`、`DIR_OSLAB=/实际路径/OSLab-RISC-V`；make 和 make run 使用一致的参数。旧编译器若不认识拆分的 Zicsr/Zifencei 扩展，且其 rv64imac 已包含这些指令，可加 `RISCV_ARCH=rv64imac`。

`LAB_STAGE=4` 保留 P2 抢占机制；全局 `-DS_CORE` 选择 P3 的整数参数接口，这两个设置作用不同。

Makefile 显式使用 `-std=gnu11`。部分新编译器默认采用 C23，该标准将 bool 设为关键字，并把空参数列表解释为无参数，和课程代码的 typedef int bool、旧式函数指针声明不兼容。已有工程只需将 `CFLAGS = -O1` 改为 `CFLAGS = -std=gnu11 -O1`，再重新构建。

## 默认程序编号与 shell

| 程序 ID | 名称 |
|---|---|
| 0 | shell |
| 1 | waitpid |
| 2 | ready_to_exit |
| 3 | wait_locks |
| 4 | barrier |
| 5 | test_barrier |

shell 支持 `ps`、`clear`、`help`、`exec ID [arg0 arg1 arg2] [&]`、`kill PID`。不带 & 时等待新进程结束，带 & 时立即返回提示符。程序 ID 由 TASKS 的顺序决定；PID 是执行时返回的进程号，两者不能混用。

```text
ps
exec 1
clear
exec 4
exec 1 &
ps
```

执行 `exec 1 &` 后，可根据 ps 找出正在运行的 ready_to_exit 的 PID，再输入 `kill 实际PID`，观察 wait_locks 获得两把锁继续执行。最后一行是说明，不要把“实际PID”当成数字输入。

更改 TASKS 顺序时，必须同步调整 waitpid.c 的 rte_id/wl_id 和 barrier.c 的 tb_id；当前分别为 2、3、5。

## 代码入口

- `include/os/sched.h`：PCB、上下文、进程接口。
- `kernel/sched/sched.c`：初始栈、调度、创建、终止和等待。
- `include/os/lock.h`、`kernel/locking/lock.c`：退出时按 owner 释放互斥锁，及屏障实现。
- `init/main.c`：只启动 shell、登记系统调用，以及按 task_id 校验字符串地址。
- `arch/riscv/crt0/crt0.S`：main 返回后 sys_exit。
- `tiny_libc/syscall.c`：用户态 ecall 包装；内核、用户接口保持一致。
- `test/shell.c`、`drivers/screen.c`：命令解析、输入编辑、退格和清屏。

固定 PCB 槽位各保存一页内核栈和一页用户栈并重复使用，避免不断 exec/exit 后递增分配耗尽。PID 单调递增，避免旧 waitpid 误等复用槽位的新进程。正在使用的内核栈必须等进程切走后才可复用。

## 验证

原课程地址布局编译通过；通用 QEMU 中的真实内核串口测试和 P2 stage4 回归通过，完整命令、结果和限制见 [验证记录](docs/P3-VALIDATION.md)。

```bash
python3 tools/host_qemu_p3.py --log-dir docs/p3-validation
python3 tools/host_qemu_smoke.py --stage 4 --seconds 8 --log docs/p3-validation/p2-regression.log
```

通用 QEMU 脚本只临时重定位副本并使用测试 BIOS。课程专用 QEMU、U-Boot、DASIC/loadbootd 和板端仍需在老师环境验收。本版本采用课程固定地址的共享映像，没有增加页表隔离；未实现条件变量、信号量、邮箱或 SMP。

`docs/P2-README-history.md` 及旧 VALIDATION.md 是 P2 历史记录；当前用法以本 README 为准。
