#include <syscall.h>
#include <stdint.h>
#include <kernel.h>
#include <unistd.h>

static long invoke_syscall(long number, long p0, long p1, long p2, long p3, long p4)
{
    register long a0 asm("a0") = p0;
    register long a1 asm("a1") = p1;
    register long a2 asm("a2") = p2;
    register long a3 asm("a3") = p3;
    register long a4 asm("a4") = p4;
    register long a7 asm("a7") = number;
    asm volatile ("ecall" : "+r"(a0) : "r"(a1), "r"(a2), "r"(a3),
                  "r"(a4), "r"(a7) : "memory");
    return a0;
}
void sys_yield(void)
{
#if LAB_STAGE < 3
    call_jmptab(YIELD, 0, 0, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_YIELD, 0, 0, 0, 0, 0);
#endif
}
void sys_move_cursor(int x, int y)
{
#if LAB_STAGE < 3
    call_jmptab(MOVE_CURSOR, x, y, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_CURSOR, x, y, 0, 0, 0);
#endif
}
void sys_write(char *buff)
{
#if LAB_STAGE < 3
    call_jmptab(PRINT, (long)buff, 0, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_WRITE, (long)buff, 0, 0, 0, 0);
#endif
}
void sys_reflush(void)
{
#if LAB_STAGE < 3
    call_jmptab(REFLUSH, 0, 0, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_REFLUSH, 0, 0, 0, 0, 0);
#endif
}
int sys_mutex_init(int key)
{
#if LAB_STAGE < 3
    return call_jmptab(MUTEX_INIT, key, 0, 0, 0, 0);
#else
    return invoke_syscall(SYSCALL_LOCK_INIT, key, 0, 0, 0, 0);
#endif
}
void sys_mutex_acquire(int id)
{
#if LAB_STAGE < 3
    call_jmptab(MUTEX_ACQ, id, 0, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_LOCK_ACQ, id, 0, 0, 0, 0);
#endif
}
void sys_mutex_release(int id)
{
#if LAB_STAGE < 3
    call_jmptab(MUTEX_RELEASE, id, 0, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_LOCK_RELEASE, id, 0, 0, 0, 0);
#endif
}
long sys_get_timebase(void)
{
    return invoke_syscall(SYSCALL_GET_TIMEBASE, 0, 0, 0, 0, 0);
}
long sys_get_tick(void)
{
    return invoke_syscall(SYSCALL_GET_TICK, 0, 0, 0, 0, 0);
}
void sys_sleep(uint32_t seconds)
{
    invoke_syscall(SYSCALL_SLEEP, seconds, 0, 0, 0, 0);
}
/************************************************************/
/* Do not touch this comment. Reserved for future projects. */
/************************************************************/

/* P3 user wrappers. S-Core handlers are registered by init_syscall(). */
#ifdef S_CORE
pid_t sys_exec(int id, int argc, uint64_t arg0, uint64_t arg1, uint64_t arg2)
{
    return invoke_syscall(SYSCALL_EXEC, id, argc, arg0, arg1, arg2);
}
#else
pid_t sys_exec(char *name, int argc, char **argv)
{
    return invoke_syscall(SYSCALL_EXEC, (long)name, argc, (long)argv, 0, 0);
}
#endif

void sys_exit(void)
{
    invoke_syscall(SYSCALL_EXIT, 0, 0, 0, 0, 0);
}

int sys_kill(pid_t pid)
{
    return invoke_syscall(SYSCALL_KILL, pid, 0, 0, 0, 0);
}

int sys_waitpid(pid_t pid)
{
    return invoke_syscall(SYSCALL_WAITPID, pid, 0, 0, 0, 0);
}

void sys_ps(void)
{
    invoke_syscall(SYSCALL_PS, 0, 0, 0, 0, 0);
}

pid_t sys_getpid(void)
{
    return invoke_syscall(SYSCALL_GETPID, 0, 0, 0, 0, 0);
}

int sys_getchar(void)
{
    return invoke_syscall(SYSCALL_READCH, 0, 0, 0, 0, 0);
}

void sys_clear(void)
{
    invoke_syscall(SYSCALL_CLEAR, 0, 0, 0, 0, 0);
}

int sys_barrier_init(int key, int goal)
{
    return invoke_syscall(SYSCALL_BARR_INIT, key, goal, 0, 0, 0);
}

void sys_barrier_wait(int bar_idx)
{
    invoke_syscall(SYSCALL_BARR_WAIT, bar_idx, 0, 0, 0, 0);
}

void sys_barrier_destroy(int bar_idx)
{
    invoke_syscall(SYSCALL_BARR_DESTROY, bar_idx, 0, 0, 0, 0);
}

int sys_condition_init(int key)
{
    return invoke_syscall(SYSCALL_COND_INIT, key, 0, 0, 0, 0);
}

void sys_condition_wait(int cond_idx, int mutex_idx)
{
    invoke_syscall(SYSCALL_COND_WAIT, cond_idx, mutex_idx, 0, 0, 0);
}

void sys_condition_signal(int cond_idx)
{
    invoke_syscall(SYSCALL_COND_SIGNAL, cond_idx, 0, 0, 0, 0);
}

void sys_condition_broadcast(int cond_idx)
{
    invoke_syscall(SYSCALL_COND_BROADCAST, cond_idx, 0, 0, 0, 0);
}

void sys_condition_destroy(int cond_idx)
{
    invoke_syscall(SYSCALL_COND_DESTROY, cond_idx, 0, 0, 0, 0);
}

int sys_semaphore_init(int key, int init)
{
    return invoke_syscall(SYSCALL_SEMA_INIT, key, init, 0, 0, 0);
}

void sys_semaphore_up(int sema_idx)
{
    invoke_syscall(SYSCALL_SEMA_UP, sema_idx, 0, 0, 0, 0);
}

void sys_semaphore_down(int sema_idx)
{
    invoke_syscall(SYSCALL_SEMA_DOWN, sema_idx, 0, 0, 0, 0);
}

void sys_semaphore_destroy(int sema_idx)
{
    invoke_syscall(SYSCALL_SEMA_DESTROY, sema_idx, 0, 0, 0, 0);
}

int sys_mbox_open(char *name)
{
    return invoke_syscall(SYSCALL_MBOX_OPEN, (long)name, 0, 0, 0, 0);
}

void sys_mbox_close(int mbox_id)
{
    invoke_syscall(SYSCALL_MBOX_CLOSE, mbox_id, 0, 0, 0, 0);
}

int sys_mbox_send(int mbox_idx, void *msg, int msg_length)
{
    return invoke_syscall(SYSCALL_MBOX_SEND, mbox_idx, (long)msg, msg_length, 0, 0);
}

int sys_mbox_recv(int mbox_idx, void *msg, int msg_length)
{
    return invoke_syscall(SYSCALL_MBOX_RECV, mbox_idx, (long)msg, msg_length, 0, 0);
}
