# PRJ3：完整源码与逐句讲解

## 先阅读说明

- 彩色PDF（111页）：projects/Project3/关键步骤逐句讲解/Project3-关键步骤与逐句讲解.pdf
- 离线HTML：projects/Project3/关键步骤逐句讲解/Project3-关键步骤与逐句讲解.html
- Markdown正文：projects/Project3/关键步骤逐句讲解/Project3-关键步骤与逐句讲解.md
- 讲义与验证说明：projects/Project3/README.md

## 源码

Project3-SCore/ 是从已核对SHA-256的完成包原样读取的完整工程，含进程管理、shell与barrier。没有修改应用源码。解压到独立目录，避免覆盖原有学生工程。

使用课程已有工具链、QEMU和U-Boot，在 Project3-SCore 目录运行 make list-tasks、make、make run；替代前缀可用 CROSS_PREFIX=riscv64-linux-gnu-，参数须保持一致。不要在没有课程工具和固件时直接把普通QEMU命令当作课程启动。

## 本次验证

原课程地址布局构建、10项镜像检查、完整P3串口测试、P2 stage4回归均通过；日志在 projects/Project3/关键步骤逐句讲解/validation/。通用QEMU使用临时地址重定位与测试BIOS，未验证课程U-Boot、DASIC/loadbootd或Pynq板。

## 重建与校验

projects/ 与 oslab/ 保留讲义构建脚本所需的相对目录及P2/P3对照归档；重建方法见讲义README。PDF/HTML可直接离线阅读，不需要安装开发工具。SHA256SUMS 列出本包每个内容文件的散列（校验表本身除外）。
