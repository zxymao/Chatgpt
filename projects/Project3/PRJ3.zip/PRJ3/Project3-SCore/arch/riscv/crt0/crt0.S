#include <asm.h>
.section ".entry_function","ax"
ENTRY(_start)
    /* The kernel already supplied a private aligned stack. */
    la t0, __bss_start
    la t1, __BSS_END__
1:  bgeu t0, t1, 2f
    sb zero, 0(t0)
    addi t0, t0, 1
    j 1b
2:  call main
    /* main's return value is not an exit status in this course interface. */
    call sys_exit
3:  call sys_yield
    j 3b
    /************************************************************/
    /* Do not touch this comment. Reserved for future projects. */
    /************************************************************/
ENDPROC(_start)
