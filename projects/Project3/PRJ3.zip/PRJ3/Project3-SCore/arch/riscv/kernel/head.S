#include <asm.h>
#include <csr.h>
.section ".entry_function","ax"
ENTRY(_start)
    csrw CSR_SIE, zero
    csrc CSR_SSTATUS, 2
    la t0, __bss_start
    la t1, __BSS_END__
1:  bgeu t0, t1, 2f
    sb zero, 0(t0)
    addi t0, t0, 1
    j 1b
2:  li sp, 0x50501000
    call main
3:  wfi
    j 3b
ENDPROC(_start)
