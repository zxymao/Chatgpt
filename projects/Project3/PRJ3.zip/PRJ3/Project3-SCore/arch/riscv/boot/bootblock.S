#include <asm/biosdef.h>
.equ BIOS_ENTRY, 0x50150000
.equ KERNEL_ENTRY, 0x50201000
.equ TASK_NUM, 0x502001f6
.equ APP_INFO, 0x502001f8
.equ KERNEL_BYTES, 0x502001fc
.text
.global main
main:
    fence
    la a0, message
    li a7, BIOS_PUTSTR
    li t0, BIOS_ENTRY
    jalr t0
    li a0, KERNEL_ENTRY
    li t0, KERNEL_BYTES
    lhu a1, 0(t0)
    addi a1, a1, 511
    srli a1, a1, 9
    li a2, 1
    li a7, BIOS_SDREAD
    li t0, BIOS_ENTRY
    jalr t0
    fence.i
    li t0, TASK_NUM
    lhu a0, 0(t0)
    li t0, APP_INFO
    lwu a1, 0(t0)
    li t0, KERNEL_ENTRY
    jr t0
    /************************************************************/
    /* Do not touch this comment. Reserved for future projects. */
    /************************************************************/
message:
    .asciz "It's bootblock!\n\r"
