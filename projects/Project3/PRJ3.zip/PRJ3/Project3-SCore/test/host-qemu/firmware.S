/* Test-only BIOS adapter for upstream QEMU virt. Not course U-Boot,
 * not loadbootd/DASIC. The runner relocates 0x50..0x52 to 0x80..0x82
 * in a temporary source copy; delivered lab sources keep original addresses. */
.section .text
.global _start
_start:
    la t0, machine_trap
    csrw mtvec, t0
    li t0, 0x80010000
    csrw mscratch, t0
    li t0, -1
    csrw pmpaddr0, t0
    li t0, 0x0f
    csrw pmpcfg0, t0
    li t0, 0xb1ff
    csrw medeleg, t0
    li t0, 0x20
    csrw mideleg, t0
    li t0, 7
    csrw mcounteren, t0
    csrw scounteren, t0
    csrw mie, zero
    /* Copy the disk's initial boot sector, like course U-Boot. */
    li t0, 0x84000000
    li t1, 0x80200000
    li t2, 512
1:  lbu t3, 0(t0)
    sb t3, 0(t1)
    addi t0, t0, 1
    addi t1, t1, 1
    addi t2, t2, -1
    bnez t2, 1b
    fence.i
    li t0, 0x80200000
    csrw mepc, t0
    li t0, 0x800
    csrw mstatus, t0
    li sp, 0x80500000
    mret

.balign 4
machine_trap:
    csrrw sp, mscratch, sp
    addi sp, sp, -64
    sd t0, 0(sp)
    sd t1, 8(sp)
    sd t2, 16(sp)
    sd t3, 24(sp)
    sd t4, 32(sp)
    sd t5, 40(sp)
    csrr t0, mcause
    li t1, 0x8000000000000007
    beq t0, t1, timer_irq
    li t1, 9
    bne t0, t1, fatal
    beqz a7, set_timer
    li t0, 1
    beq a7, t0, putchar
    li t0, 2
    beq a7, t0, getchar
    li t0, 9
    beq a7, t0, putstr
    li t0, 11
    beq a7, t0, sdread
    li t0, 12
    beq a7, t0, fdt
    li t0, 14
    beq a7, t0, putstr
    j fatal
set_timer:
    li t0, 0x2004000
    sd a0, 0(t0)
    li t0, 0x20
    csrc mip, t0
    li t0, 0x80
    csrs mie, t0
    j bios_done
putchar:
    li t0, 0x10000000
    sb a0, 0(t0)
    j bios_done
getchar:
    li t0, 0x10000000
    lbu t1, 5(t0)
    andi t1, t1, 1
    beqz t1, 1f
    lbu a0, 0(t0)
    j bios_done
1:  li a0, -1
    j bios_done
putstr:
    mv t0, a0
    li t1, 0x10000000
1:  lbu t2, 0(t0)
    beqz t2, bios_done
    sb t2, 0(t1)
    addi t0, t0, 1
    j 1b
sdread:
    li t0, 0x84000000
    slli t1, a2, 9
    add t0, t0, t1
    mv t1, a0
    slli t2, a1, 9
1:  beqz t2, bios_done
    lbu t3, 0(t0)
    sb t3, 0(t1)
    addi t0, t0, 1
    addi t1, t1, 1
    addi t2, t2, -1
    j 1b
fdt:
    li a0, 10000000
bios_done:
    csrr t0, mepc
    addi t0, t0, 4
    csrw mepc, t0
    j restore
 timer_irq:
    li t0, 0x80
    csrc mie, t0
    li t0, 0x20
    csrs mip, t0
restore:
    ld t0, 0(sp)
    ld t1, 8(sp)
    ld t2, 16(sp)
    ld t3, 24(sp)
    ld t4, 32(sp)
    ld t5, 40(sp)
    addi sp, sp, 64
    csrrw sp, mscratch, sp
    mret
fatal:
    li t0, 0x10000000
    li t1, 33
    sb t1, 0(t0)
1:  wfi
    j 1b

.section .bios,"ax"
    ecall
    ret
