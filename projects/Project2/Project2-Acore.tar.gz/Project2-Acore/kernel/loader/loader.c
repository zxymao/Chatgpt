#include <os/task.h>
#include <os/string.h>
#include <os/kernel.h>
#include <os/loader.h>
#include <assert.h>

static unsigned char sector_buf[SECTOR_SIZE] __attribute__((aligned(512)));
extern int task_num;

void load_img_bytes(uint32_t offset, uint32_t size, void *dst)
{
    unsigned char *out = dst;
    while (size) {
        uint32_t in_sector = offset % SECTOR_SIZE;
        uint32_t count = SECTOR_SIZE - in_sector;
        if (count > size) count = size;
        /* Course BIOS uses physical addresses below 4 GiB. */
        sd_read((unsigned)(ptr_t)sector_buf, 1, offset / SECTOR_SIZE);
        memcpy(out, sector_buf + in_sector, count);
        out += count;
        offset += count;
        size -= count;
    }
}

uint64_t load_task_img(char *name)
{
    for (int i = 0; i < task_num; ++i) {
        if (!strcmp(name, tasks[i].task_name)) {
            assert(tasks[i].size <= TASK_SIZE);
            load_img_bytes(tasks[i].offset, tasks[i].size,
                           (void *)tasks[i].entrypoint);
            __asm__ volatile ("fence.i" ::: "memory");
            return tasks[i].entrypoint;
        }
    }
    return 0;
}
