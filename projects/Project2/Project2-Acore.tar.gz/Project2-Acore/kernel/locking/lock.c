#include <os/lock.h>
#include <os/sched.h>
#include <os/irq.h>
#include <atomic.h>
#include <assert.h>

mutex_lock_t mlocks[LOCK_NUM];
void spin_lock_init(spin_lock_t *lock) { lock->status = UNLOCKED; }
int spin_lock_try_acquire(spin_lock_t *lock)
{
    return atomic_swap(LOCKED, (ptr_t)&lock->status) == UNLOCKED;
}
void spin_lock_acquire(spin_lock_t *lock)
{
    while (!spin_lock_try_acquire(lock)) __asm__ volatile ("nop");
}
void spin_lock_release(spin_lock_t *lock)
{
    atomic_swap(UNLOCKED, (ptr_t)&lock->status);
}
void init_locks(void)
{
    for (int i = 0; i < LOCK_NUM; ++i) {
        spin_lock_init(&mlocks[i].lock);
        list_init(&mlocks[i].block_queue);
        mlocks[i].used = 0;
        mlocks[i].owner = 0;
    }
}
int do_mutex_lock_init(int key)
{
    uint64_t flags = irq_save();
    int free_slot = -1;
    for (int i = 0; i < LOCK_NUM; ++i) {
        if (mlocks[i].used && mlocks[i].key == key) {
            irq_restore(flags);
            return i;
        }
        if (!mlocks[i].used && free_slot < 0) free_slot = i;
    }
    if (free_slot >= 0) {
        mlocks[free_slot].used = 1;
        mlocks[free_slot].key = key;
    }
    irq_restore(flags);
    return free_slot;
}
static mutex_lock_t *get_lock(int id)
{
    assert(id >= 0 && id < LOCK_NUM && mlocks[id].used);
    return &mlocks[id];
}
void do_mutex_lock_acquire(int id)
{
    uint64_t flags = irq_save();
    mutex_lock_t *lock = get_lock(id);
    assert(lock->owner != current_running->pid); /* non-recursive */
    if (spin_lock_try_acquire(&lock->lock)) {
        lock->owner = current_running->pid;
    } else {
        do_block(&current_running->list, &lock->block_queue);
        /* release handed ownership to us; no stealing by a new arrival. */
        assert(lock->owner == current_running->pid);
    }
    irq_restore(flags);
}
void do_mutex_lock_release(int id)
{
    uint64_t flags = irq_save();
    mutex_lock_t *lock = get_lock(id);
    assert(lock->owner == current_running->pid);
    if (!list_empty(&lock->block_queue)) {
        list_node_t *node = lock->block_queue.next;
        lock->owner = list_entry(node, pcb_t, list)->pid;
        do_unblock(node); /* lock remains LOCKED until this owner releases */
    } else {
        lock->owner = 0;
        spin_lock_release(&lock->lock);
    }
    irq_restore(flags);
}
