#include <os/list.h>
#include <os/sched.h>
#include <os/time.h>
#include <os/mm.h>
#include <os/irq.h>
#include <assert.h>

pcb_t pcb[NUM_MAX_TASK];
const ptr_t pid0_stack = INIT_KERNEL_STACK + PAGE_SIZE;
pcb_t pid0_pcb = { .pid = 0, .kernel_sp = INIT_KERNEL_STACK + PAGE_SIZE,
                   .user_sp = INIT_KERNEL_STACK + PAGE_SIZE };
LIST_HEAD(ready_queue);
LIST_HEAD(sleep_queue);
pid_t process_id = 1;

void do_scheduler(void)
{
    uint64_t flags = irq_save();
    check_sleeping();
    /************************************************************/
    /* Do not touch this comment. Reserved for future projects. */
    /************************************************************/
    pcb_t *prev = current_running;
    if (prev->status == TASK_RUNNING && prev != &pid0_pcb) {
        prev->status = TASK_READY;
        list_add_tail(&prev->list, &ready_queue);
    }
    list_node_t *node = list_pop_front(&ready_queue);
    pcb_t *next = node ? list_entry(node, pcb_t, list) : &pid0_pcb;
    if (prev == &pid0_pcb && next != prev) prev->status = TASK_READY;
    next->status = TASK_RUNNING;
    if (prev != next) {
        /* switch_to installs tp and sscratch atomically with IRQs disabled. */
        switch_to(prev, next);
    }
    irq_restore(flags);
}

void do_sleep(uint32_t seconds)
{
    uint64_t flags = irq_save();
    if (!seconds) {
        do_scheduler();
    } else {
        current_running->wakeup_time = get_ticks() + (uint64_t)seconds * time_base;
        do_block(&current_running->list, &sleep_queue);
    }
    irq_restore(flags);
}

void do_block(list_node_t *node, list_head *queue)
{
    uint64_t flags = irq_save();
    assert(node == &current_running->list && current_running != &pid0_pcb);
    assert(list_empty(node));
    current_running->status = TASK_BLOCKED;
    list_add_tail(node, queue);
    do_scheduler();
    irq_restore(flags);
}

void do_unblock(list_node_t *node)
{
    uint64_t flags = irq_save();
    pcb_t *task = list_entry(node, pcb_t, list);
    assert(task->status == TASK_BLOCKED);
    list_del(node);
    task->status = TASK_READY;
    list_add_tail(node, &ready_queue);
    irq_restore(flags);
}
