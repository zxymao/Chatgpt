#include <os/list.h>
#include <os/sched.h>
#include <type.h>

uint64_t time_elapsed = 0;
uint64_t time_base = 0;

uint64_t get_ticks()
{
    __asm__ __volatile__(
        "rdtime %0"
        : "=r"(time_elapsed));
    return time_elapsed;
}

uint64_t get_timer()
{
    return get_ticks() / time_base;
}

uint64_t get_time_base()
{
    return time_base;
}

void latency(uint64_t time)
{
    uint64_t begin_time = get_timer();

    while (get_timer() - begin_time < time);
    return;
}

void check_sleeping(void)
{
    uint64_t now = get_ticks();
    list_node_t *node = sleep_queue.next;
    while (node != &sleep_queue) {
        list_node_t *next = node->next;
        pcb_t *task = list_entry(node, pcb_t, list);
        if ((int64_t)(now - task->wakeup_time) >= 0) do_unblock(node);
        node = next;
    }
}