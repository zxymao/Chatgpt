#include <sys/syscall.h>
long (*syscall[NUM_SYSCALLS])();
void handle_syscall(regs_context_t *regs, uint64_t stval, uint64_t cause)
{
    (void)stval; (void)cause;
    uint64_t number = regs->regs[17]; /* a7 */
    regs->sepc += 4; /* ecall is always a 32-bit instruction */
    if (number >= NUM_SYSCALLS || !syscall[number]) {
        regs->regs[10] = (reg_t)-38; /* ENOSYS */
        return;
    }
    regs->regs[10] = syscall[number](regs->regs[10], regs->regs[11],
                                    regs->regs[12], regs->regs[13], regs->regs[14]);
}
