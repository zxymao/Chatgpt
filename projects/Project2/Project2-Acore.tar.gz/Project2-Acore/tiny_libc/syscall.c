#include <syscall.h>
#include <stdint.h>
#include <kernel.h>
#include <unistd.h>

static long invoke_syscall(long number, long p0, long p1, long p2, long p3, long p4)
{
    register long a0 asm("a0") = p0;
    register long a1 asm("a1") = p1;
    register long a2 asm("a2") = p2;
    register long a3 asm("a3") = p3;
    register long a4 asm("a4") = p4;
    register long a7 asm("a7") = number;
    asm volatile ("ecall" : "+r"(a0) : "r"(a1), "r"(a2), "r"(a3),
                  "r"(a4), "r"(a7) : "memory");
    return a0;
}
void sys_yield(void)
{
#if LAB_STAGE < 3
    call_jmptab(YIELD, 0, 0, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_YIELD, 0, 0, 0, 0, 0);
#endif
}
void sys_move_cursor(int x, int y)
{
#if LAB_STAGE < 3
    call_jmptab(MOVE_CURSOR, x, y, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_CURSOR, x, y, 0, 0, 0);
#endif
}
void sys_write(char *buff)
{
#if LAB_STAGE < 3
    call_jmptab(PRINT, (long)buff, 0, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_WRITE, (long)buff, 0, 0, 0, 0);
#endif
}
void sys_reflush(void)
{
#if LAB_STAGE < 3
    call_jmptab(REFLUSH, 0, 0, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_REFLUSH, 0, 0, 0, 0, 0);
#endif
}
int sys_mutex_init(int key)
{
#if LAB_STAGE < 3
    return call_jmptab(MUTEX_INIT, key, 0, 0, 0, 0);
#else
    return invoke_syscall(SYSCALL_LOCK_INIT, key, 0, 0, 0, 0);
#endif
}
void sys_mutex_acquire(int id)
{
#if LAB_STAGE < 3
    call_jmptab(MUTEX_ACQ, id, 0, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_LOCK_ACQ, id, 0, 0, 0, 0);
#endif
}
void sys_mutex_release(int id)
{
#if LAB_STAGE < 3
    call_jmptab(MUTEX_RELEASE, id, 0, 0, 0, 0);
#else
    invoke_syscall(SYSCALL_LOCK_RELEASE, id, 0, 0, 0, 0);
#endif
}
long sys_get_timebase(void)
{
    return invoke_syscall(SYSCALL_GET_TIMEBASE, 0, 0, 0, 0, 0);
}
long sys_get_tick(void)
{
    return invoke_syscall(SYSCALL_GET_TICK, 0, 0, 0, 0, 0);
}
void sys_sleep(uint32_t seconds)
{
    invoke_syscall(SYSCALL_SLEEP, seconds, 0, 0, 0, 0);
}
/************************************************************/
/* Do not touch this comment. Reserved for future projects. */
/************************************************************/
