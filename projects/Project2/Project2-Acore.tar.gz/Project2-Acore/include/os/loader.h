#ifndef __INCLUDE_LOADER_H__
#define __INCLUDE_LOADER_H__

#include <type.h>
void load_img_bytes(uint32_t offset, uint32_t size, void *dst);
uint64_t load_task_img(char *taskname);



#endif