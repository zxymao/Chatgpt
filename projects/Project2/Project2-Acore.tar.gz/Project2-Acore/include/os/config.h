#ifndef OS_CONFIG_H
#define OS_CONFIG_H
#ifndef LAB_STAGE
#define LAB_STAGE 4
#endif
#if LAB_STAGE < 1 || LAB_STAGE > 4
#error LAB_STAGE must be in 1..4
#endif
#endif
