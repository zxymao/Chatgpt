#include <common.h>
#include <asm/regs.h>
#include <asm/unistd.h>
#include <os/config.h>
#include <os/irq.h>
#include <os/sched.h>
#include <os/lock.h>
#include <os/kernel.h>
#include <os/task.h>
#include <os/loader.h>
#include <os/string.h>
#include <os/mm.h>
#include <os/time.h>
#include <sys/syscall.h>
#include <screen.h>
#include <printk.h>
#include <assert.h>
#include <csr.h>

extern void ret_from_exception(void);
task_info_t tasks[TASK_MAXNUM];
int task_num;

_Static_assert(sizeof(regs_context_t) == OFFSET_SIZE, "trap ABI size");
_Static_assert(sizeof(switchto_context_t) == SWITCH_TO_SIZE, "switch ABI size");
_Static_assert(__builtin_offsetof(pcb_t, kernel_sp) == PCB_KERNEL_SP, "kernel_sp ABI");
_Static_assert(__builtin_offsetof(pcb_t, user_sp) == PCB_USER_SP, "user_sp ABI");
_Static_assert(__builtin_offsetof(pcb_t, trap_t0) == PCB_TRAP_T0, "trap scratch ABI");
_Static_assert(sizeof(task_info_t) == 48, "disk task metadata ABI");

/* Wrappers provide one uniform syscall ABI, including defined void returns. */
static long k_yield(long a, long b, long c, long d, long e)
{ do_scheduler(); return 0; }
static long k_write(long p, long b, long c, long d, long e)
{
    /* No page tables in P2. Validate the complete string against this task's
     * user image or user stack before dereferencing it, also for loadbootd. */
    uint64_t begin = (uint64_t)p, limit = 0;
    for (int i = 0; i < task_num; ++i) {
        if (current_running->pid == i + 1 && begin >= tasks[i].entrypoint &&
            begin < tasks[i].entrypoint + TASK_SIZE)
            limit = tasks[i].entrypoint + TASK_SIZE;
    }
    if (begin >= current_running->user_stack_base &&
        begin < current_running->user_stack_base + PAGE_SIZE)
        limit = current_running->user_stack_base + PAGE_SIZE;
    if (!limit) return -14;
    char *text = (char *)p;
    uint64_t i = 0;
    while (begin + i < limit && text[i]) ++i;
    if (begin + i == limit) return -14;
    screen_write(text);
#if LAB_STAGE < 4
    screen_reflush();
#endif
    return 0;
}
static long k_cursor(long x, long y, long c, long d, long e)
{ screen_move_cursor(x, y); return 0; }
static long k_refresh(long a, long b, long c, long d, long e)
{ screen_reflush(); return 0; }
static long k_sleep(long s, long b, long c, long d, long e)
{ do_sleep((uint32_t)s); return 0; }
static long k_lock_init(long key, long b, long c, long d, long e)
{ return do_mutex_lock_init((int)key); }
static long k_lock_acq(long id, long b, long c, long d, long e)
{ do_mutex_lock_acquire((int)id); return 0; }
static long k_lock_rel(long id, long b, long c, long d, long e)
{ do_mutex_lock_release((int)id); return 0; }
static long k_timebase(long a, long b, long c, long d, long e)
{ return get_time_base(); }
static long k_ticks(long a, long b, long c, long d, long e)
{ return get_ticks(); }

static long k_putstr(long p, long b, long c, long d, long e)
{ port_write((char *)p); return 0; }
static long k_putchar(long ch, long b, long c, long d, long e)
{ port_write_ch(ch); return 0; }
static long k_getchar(long a, long b, long c, long d, long e)
{ return port_read_ch(); }
static long k_sdread(long p, long n, long block, long d, long e)
{ return sd_read(p, n, block); }
static long k_sdwrite(long p, long n, long block, long d, long e)
{ return sd_write(p, n, block); }
static long k_logging(long p, long b, long c, long d, long e)
{ qemu_logging((char *)p); return 0; }
static long k_settimer(long ticks, long b, long c, long d, long e)
{ set_timer(ticks); return 0; }
static long k_fdt(long type, long b, long c, long d, long e)
{ return read_fdt(type); }

static void init_jmptab(void)
{
    long (**table)() = (long (**)())KERNEL_JMPTAB_BASE;
    table[CONSOLE_PUTSTR] = k_putstr;
    table[CONSOLE_PUTCHAR] = k_putchar;
    table[CONSOLE_GETCHAR] = k_getchar;
    table[SD_READ] = k_sdread;
    table[SD_WRITE] = k_sdwrite;
    table[QEMU_LOGGING] = k_logging;
    table[SET_TIMER] = k_settimer;
    table[READ_FDT] = k_fdt;
    table[MOVE_CURSOR] = k_cursor;
    table[PRINT] = k_write;
    table[YIELD] = k_yield;
    table[MUTEX_INIT] = k_lock_init;
    table[MUTEX_ACQ] = k_lock_acq;
    table[MUTEX_RELEASE] = k_lock_rel;
    table[REFLUSH] = k_refresh;
}

static void init_task_info(int count, uint32_t offset)
{
    assert(count > 0 && count <= TASK_MAXNUM && count <= NUM_MAX_TASK);
    task_num = count;
    load_img_bytes(offset, count * sizeof(task_info_t), tasks);
    for (int i = 0; i < count; ++i) {
        assert(tasks[i].task_name[TASK_NAME_LEN-1] == 0);
        assert(tasks[i].entrypoint == TASK_MEM_BASE + (ptr_t)i * TASK_SIZE);
        assert(tasks[i].size > 0 && tasks[i].size <= TASK_SIZE);
    }
}

static void init_pcb_stack(ptr_t ktop, ptr_t utop, ptr_t entry, pcb_t *task)
{
    regs_context_t *regs = (regs_context_t *)(ktop - sizeof(*regs));
    switchto_context_t *sw = (switchto_context_t *)((ptr_t)regs - sizeof(*sw));
    bzero(regs, sizeof(*regs));
    bzero(sw, sizeof(*sw));
    regs->regs[2] = utop;
    regs->sepc = entry;
#if LAB_STAGE >= 3
    /* SPP=0 returns to U mode; SPIE controls SIE after sret. */
    regs->sstatus = SR_SPIE;
#else
    /* Cooperative tasks share S mode and call the jump table directly. */
    regs->regs[4] = (ptr_t)task;
    regs->sstatus = SR_SPP;
#endif
    sw->regs[0] = (ptr_t)ret_from_exception;
    sw->regs[1] = (ptr_t)sw;
    task->kernel_sp = (ptr_t)sw;
    task->user_sp = utop;
}

static void init_pcb(void)
{
    list_init(&ready_queue);
    list_init(&sleep_queue);
    list_init(&pid0_pcb.list);
    pid0_pcb.status = TASK_RUNNING;
    current_running = &pid0_pcb;
    __asm__ volatile ("csrw sscratch, %0" :: "r"(current_running) : "memory");
    for (int i = 0; i < task_num; ++i) {
        pcb_t *task = &pcb[i];
        bzero(task, sizeof(*task));
        task->pid = process_id++;
        task->status = TASK_READY;
        task->cursor_y = i * 2;
        list_init(&task->list);
        ptr_t ktop = allocKernelPage(1) + PAGE_SIZE;
        task->user_stack_base = allocUserPage(1);
        ptr_t utop = task->user_stack_base + PAGE_SIZE;
        uint64_t entry = load_task_img(tasks[i].task_name);
        assert(entry);
        init_pcb_stack(ktop, utop, entry, task);
        list_add_tail(&task->list, &ready_queue);
        printk("[LOAD] pid=%d task=%s entry=0x%lx\n\r", task->pid,
               tasks[i].task_name, entry);
    }
}

static void init_syscall(void)
{
    bzero(syscall, sizeof(long (*)()) * NUM_SYSCALLS);
    syscall[SYSCALL_YIELD] = k_yield;
    syscall[SYSCALL_WRITE] = k_write;
    syscall[SYSCALL_CURSOR] = k_cursor;
    syscall[SYSCALL_REFLUSH] = k_refresh;
    syscall[SYSCALL_SLEEP] = k_sleep;
    syscall[SYSCALL_LOCK_INIT] = k_lock_init;
    syscall[SYSCALL_LOCK_ACQ] = k_lock_acq;
    syscall[SYSCALL_LOCK_RELEASE] = k_lock_rel;
    syscall[SYSCALL_GET_TIMEBASE] = k_timebase;
    syscall[SYSCALL_GET_TICK] = k_ticks;
}

int main(int count, uint32_t app_offset)
{
    init_jmptab();
    init_task_info(count, app_offset);
    init_pcb();
    time_base = bios_read_fdt(TIMEBASE);
    assert(time_base > 0);
    init_locks();
    init_syscall();
    init_exception();
    init_screen();
    printk("[INIT] A-Core stage %d, %d tasks, timebase=%lu\n\r",
           LAB_STAGE, task_num, time_base);
#if LAB_STAGE >= 4
    bios_set_timer(get_ticks() + TIMER_INTERVAL);
    enable_preempt();
#endif
    /************************************************************/
    /* Do not touch this comment. Reserved for future projects. */
    /************************************************************/
    while (1) {
        disable_interrupt();
        do_scheduler();
#if LAB_STAGE >= 4
        /* WFI may wake on a pending individually enabled interrupt even
         * with global SIE clear. Enable after WFI to service it safely. */
        __asm__ volatile ("wfi");
        enable_interrupt();
#endif
        /* Stage 3 deliberately polls here when every task is asleep. */
    }
}
