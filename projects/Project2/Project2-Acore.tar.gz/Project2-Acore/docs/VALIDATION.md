# 验证记录

本记录区分编译、通用QEMU功能检查及课程环境验收。

## 工具

- 宿主：Debian 13，x86-64。
- 交叉编译器：Debian GCC 14.2.0，riscv64-linux-gnu，rv64imac_zicsr_zifencei/lp64。
- 通用QEMU：10.0.13，virt，256 MiB，单核。
- 工具包通过Debian签名索引与包校验下载至工作区；未更改用户lab环境。

## 已验证

| 检查 | 结果与证据 |
|---|---|
| 原始课程地址布局的LAB_STAGE=1、2、3、4构建 | 四种配置均编译、链接并生成镜像；Task 4默认6个课程任务 |
| 镜像格式及错误输入 | tools/test_image.py：10项通过，覆盖段间空洞、元信息、扇区补齐、内核及任务大小超限、引导区覆盖、入口错误、截断ELF、无任务、过多任务、重复任务、字节序错误 |
| Task 1运行 | coop1/coop2均持续输出计数，主动yield切换 |
| Task 2运行 | mutex1/mutex2均出现获取和释放事件，持锁yield强制另一任务竞争并阻塞 |
| Task 3运行 | 无定时中断，sleep恢复到下一次计数，coop_timer超过2秒 |
| Task 4寄存器和抢占探针 | 两任务均在对方一秒无系统调用计算结束前开始；检测ra/gp/tp、临时、参数及保存寄存器；两任务均打印PASS |
| 系统调用边界 | 两种未注册/越界调用号返回-38，坏字符串指针返回-14，由probe断言检查 |
| 锁与睡眠联合 | probe持锁sleep，另一任务阻塞；持有者唤醒并释放，等待者接管，两任务最终PASS |
| 空就绪队列 | 单probe在全部用户任务睡眠后再次唤醒，最终PASS |
| 原课程测试组合 | print1、print2、lock1、lock2分别在对应屏幕行运行，sleep继续计数，timer输出时间 |
| 原飞机测试组合 | fly显示飞机，print1/print2同时运行 |
| 原课程测试源码保护 | test/test_project2下文件与上传框架逐字节一致 |

## 运行验证的范围

以上运行检查使用tools/host_qemu_smoke.py：在临时副本中将0x50xxxxxx—0x52xxxxxx地址整体平移至通用virt的RAM范围0x80xxxxxx—0x82xxxxxx，保留相对布局；使用独立M模式测试BIOS转接串口、内存镜像读取和定时器。原始工程地址及源码文件不会因此被改动。

测试内核执行真实的用户态异常入口、系统调用、上下文切换、定时中断和队列代码；适配层不模拟这些内核功能。但磁盘读取来自内存镜像，不检验课程SD/virtio硬件路径；也不检验课程QEMU/U-Boot或DASIC。

典型命令（独立机器需先安装对应工具）：

```bash
python3 tools/test_image.py build/createimage
python3 tools/host_qemu_smoke.py --stage 1 --seconds 4 --log stage1.log
python3 tools/host_qemu_smoke.py --stage 2 --seconds 4 --log stage2.log
python3 tools/host_qemu_smoke.py --stage 3 --seconds 4 --log stage3.log
python3 tools/host_qemu_smoke.py --stage 4 --seconds 8 --log stage4.log
python3 tools/host_qemu_smoke.py --stage 4 --tasks 'print1 print2 lock1 lock2 sleep timer' --seconds 4 --log course.log
python3 tools/host_qemu_smoke.py --stage 4 --tasks 'fly print1 print2' --seconds 3 --log fly.log
python3 tools/host_qemu_smoke.py --stage 4 --tasks 'probe1' --seconds 6 --log idle.log
```

默认探针要求与观察到的标记匹配，错误/断言或缺少标记时退出非零。QEMU是持续运行的内核，脚本在限定时间后终止进程，再解析VT100屏幕输出作功能判断；超时本身不是通过依据。

## 尚未执行

- 课程原QEMU与U-Boot的端到端启动和实际块设备读取。
- 课程loadbootd/DASIC检查。
- Pynq板端运行与A-Core正式验收。
- 原lab工具链兼容性；旧版本若不识别拆分指令集扩展，可按README说明确认后覆盖RISCV_ARCH。

未将上述未执行项标为通过。工程需要在用户已有课程lab中继续验证。
