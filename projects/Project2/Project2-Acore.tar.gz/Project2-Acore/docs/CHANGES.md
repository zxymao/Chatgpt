# 修改文件清单

以Project2-source.tar.gz中的课程框架为比较基线。实验1仅用于整合，不改动原上传文件。

## 修改

- `Makefile`
- `README.md`
- `arch/riscv/boot/bootblock.S`
- `arch/riscv/crt0/crt0.S`
- `arch/riscv/include/asm/regs.h`
- `arch/riscv/kernel/entry.S`
- `arch/riscv/kernel/head.S`
- `arch/riscv/kernel/trap.S`
- `drivers/screen.c`
- `include/os/irq.h`
- `include/os/kernel.h`
- `include/os/list.h`
- `include/os/loader.h`
- `include/os/lock.h`
- `include/os/sched.h`
- `include/os/task.h`
- `init/main.c`
- `kernel/irq/irq.c`
- `kernel/loader/loader.c`
- `kernel/locking/lock.c`
- `kernel/sched/sched.c`
- `kernel/sched/time.c`
- `kernel/syscall/syscall.c`
- `libs/printk.c`
- `tiny_libc/include/kernel.h`
- `tiny_libc/printf.c`
- `tiny_libc/syscall.c`
- `tools/createimage.c`

## 新增

- `.gitignore`
- `include/os/config.h`
- `test/host-qemu/firmware.S`
- `test/host-qemu/firmware.lds`
- `test/validation/coop1.c`
- `test/validation/coop2.c`
- `test/validation/coop_timer.c`
- `test/validation/mutex1.c`
- `test/validation/mutex2.c`
- `test/validation/probe1.c`
- `test/validation/probe2.c`
- `test/validation/register_check.h`
- `tools/host_qemu_smoke.py`
- `tools/test_image.py`

## 移除

- 根目录旧的预编译`createimage`，统一由`tools/createimage.c`构建为`build/createimage`。

原课程测试未修改。详细设计见README，已执行与尚未执行的验证见VALIDATION.md；压缩日志在docs/logs。
