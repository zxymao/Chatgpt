#include <stdio.h>
#include <unistd.h>
int main(void)
{
    for (unsigned i = 0; ; ++i) {
        sys_move_cursor(0, 1);
        printf("[COOP 2] count=%u\n", i);
        sys_yield();
    }
}
