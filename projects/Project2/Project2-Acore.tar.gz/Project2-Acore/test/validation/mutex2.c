#include <stdio.h>
#include <unistd.h>
#include <assert.h>
int main(void)
{
    int id = sys_mutex_init(42);
    assert(id >= 0 && id == sys_mutex_init(42));
    for (unsigned n = 0;; ++n) {
        sys_mutex_acquire(id);
        sys_move_cursor(0, 1);
        printf("[MUTEX 2] acquired %u\n", n);
        sys_yield(); /* force the peer to contend while we own the lock */
        sys_move_cursor(0, 1);
        printf("[MUTEX 2] release %u\n", n);
        sys_mutex_release(id);
        sys_yield();
    }
}
