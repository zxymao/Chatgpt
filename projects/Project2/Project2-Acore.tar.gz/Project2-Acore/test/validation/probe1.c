#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <assert.h>
#include "register_check.h"
static long raw_call(long number, long argument)
{
    register long a0 asm("a0") = argument;
    register long a7 asm("a7") = number;
    asm volatile ("ecall" : "+r"(a0) : "r"(a7) : "memory");
    return a0;
}
static void report(const char *s)
{
    sys_move_cursor(0, 0);
    printf("[PROBE 1] %s\n", s);
    sys_reflush();
}
int main(void)
{
    register uintptr_t c0 asm("s2") = 0x12345678UL + 1;
    register uintptr_t c1 asm("s3") = 0x87654321UL + 1;
    report("start");
    assert(raw_call(95, 0) == -38);
    assert(raw_call(1000000, 0) == -38);
    assert(raw_call(20, 1) == -14);
    int lock = sys_mutex_init(99);
    assert(lock >= 0 && lock == sys_mutex_init(99));
    long base = sys_get_timebase();
    assert(base > 0);
    long start = sys_get_tick();
    /* This function never calls a syscall or yields. */
    assert(register_check(base));
    assert(c0 == 0x12345678UL + 1 && c1 == 0x87654321UL + 1);
    report("cpu-loop-ok");
    sys_mutex_acquire(lock);
    report("lock-held");
    sys_sleep(1); /* keep ownership, ensuring the other probe blocks */
    report("lock-release");
    sys_mutex_release(lock);
    start = sys_get_tick();
    sys_sleep(1);
    assert(sys_get_tick() - start >= base);
    report("PASS");
    for (;;) sys_sleep(1);
}
