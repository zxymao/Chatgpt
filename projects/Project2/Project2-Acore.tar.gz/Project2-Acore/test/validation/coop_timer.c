#include <stdio.h>
#include <unistd.h>
int main(void)
{
    long last = -1;
    for (;;) {
        long now = sys_get_tick() / sys_get_timebase();
        if (now != last) {
            last = now;
            sys_move_cursor(0, 6);
            printf("[COOP TIMER] seconds=%ld\n", now);
        }
        sys_yield();
    }
}
