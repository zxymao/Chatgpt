#include <stdio.h>
#include <unistd.h>
int main(void)
{
    for (unsigned i = 0; ; ++i) {
        sys_move_cursor(0, 0);
        printf("[COOP 1] count=%u\n", i);
        sys_yield();
    }
}
