# Project 2 — A Simple Kernel（A-Core）

本工程基于上传的Project 2框架，整合Project 1的启动和按名称加载思路，实现Task 1—4。默认构建完整的用户态系统调用及轮转抢占调度。Task 5不在范围内；原课程测试源码保持不变。

## 在现有lab中使用

请把源码包解压到一个新的目录，不要覆盖原实验1，也不要在原实验1目录切换或合并分支。依赖课程已经安装的RISC-V编译器、QEMU和U-Boot。

```bash
cd ~/Project2-Acore
riscv64-unknown-linux-gnu-gcc --version
make
make run
```

默认使用`~/OSLab-RISC-V/qemu/riscv64-softmmu/qemu-system-riscv64`和`~/OSLab-RISC-V/u-boot/u-boot`。其他位置可以覆盖：

```bash
make run DIR_OSLAB=/你的路径/OSLab-RISC-V
# 如果编译器名称是riscv64-linux-gnu-gcc：
make CROSS_PREFIX=riscv64-linux-gnu-
make run CROSS_PREFIX=riscv64-linux-gnu-
```

`LAB_STAGE`和`TASKS`会影响构建；每次`make run`也应提供相同参数。Makefile会检测阶段及任务列表变化并重新链接，不需要手动改源码。构建不并行，任务按TASKS顺序固定链接到0x52000000起每64 KiB一个槽位。

默认指令集为`rv64imac_zicsr_zifencei`、软浮点ABI `lp64`，禁用PIE和gp松弛。如果课程旧工具链不认识拆分后的Zicsr/Zifencei扩展，可在确认该工具链的rv64imac包含CSR/fence.i后使用：

```bash
make RISCV_ARCH=rv64imac
make run RISCV_ARCH=rv64imac
```

## 分阶段验证

| 阶段 | 命令（构建后启动） | 预期 |
|---|---|---|
| Task 1 | `make run LAB_STAGE=1` | coop1、coop2主动yield，两个计数持续更新 |
| Task 2 | `make run LAB_STAGE=2` | mutex1、mutex2使用相同key，持锁时主动yield，等待者阻塞并按顺序得到锁 |
| Task 3 | `make run LAB_STAGE=3` | sleep与coop_timer通过ecall运行；无时钟中断，调度和idle轮询唤醒睡眠任务 |
| Task 4 | `make run LAB_STAGE=4` | 原print1/2、lock1/2、sleep、timer无需主动yield也能持续运行 |

单独检查飞机或更强的探针：

```bash
make run LAB_STAGE=4 TASKS='fly print1 print2'
make run LAB_STAGE=4 TASKS='probe1 probe2'
make run LAB_STAGE=4 TASKS='probe1'
make run LAB_STAGE=3 TASKS='sleep'
```

probe任务检查无系统调用计算期间的异步抢占、用户寄存器保持、非法系统调用号的ENOSYS返回、坏字符串指针的EFAULT返回、相同key复用、持锁睡眠、释放后的所有权移交及睡眠时间下界。打印PASS后仍会睡眠，内核没有实现Project 3的退出系统调用。单probe用于检查所有用户任务睡眠时idle及唤醒路径。

新增验证程序在`test/validation/`，原测试在`test/test_project2/`。fly1—fly5依赖缺失的Task 5接口，不加入A-Core默认构建，未添加虚假空实现。

`make debug`启动GDB服务，另一终端执行`make gdb`。构建后的ELF、镜像和反汇编均在`build/`；QEMU日志为`build/oslab-log.txt`。

## 设计说明

### 启动、镜像与加载

bootblock调用BIOS读取内核，向内核a0传任务数量、a1传任务信息的镜像字节偏移。head.S保留参数，清零BSS并使用与pid0一致的启动栈。加载器支持不对齐的镜像偏移和跨扇区复制。

镜像引导扇区：0x1f6为16位任务数量；0x1f8为32位任务信息偏移；0x1fc为16位内核字节数；0x1fe为55 aa签名。每条task_info_t固定48字节：32字节名称、32位偏移、32位文件跨度、64位入口。createimage按PT_LOAD相对虚拟地址放置段并填充空洞，不把ELF文件头或调试信息写入任务映像。BSS由启动代码清零。保留内核65535字节上限、任务16个和每槽64 KiB限制，超限明确报错。

### PCB、上下文与调度

PCB最前两个字段仍为kernel_sp与user_sp，与课程汇编偏移一致；新增trap临时寄存器槽和用户栈基址。编译期断言校验PCB关键偏移、112字节switch帧和288字节异常帧。

switch_to保存ra、sp及s0—s11，把内核栈位置写入旧PCB；切换tp和sscratch到新PCB，恢复新任务的寄存器。新任务的初始switch帧返回到ret_from_exception，再由sret进入任务。Task 1/2的任务运行在S模式，Task 3/4运行在U模式。

就绪队列FIFO轮转。正在运行且未阻塞的普通任务回队尾；阻塞任务不回就绪队列；无任务可运行时返回pid0。首次调度使用pid0保存main上下文。睡眠队列到期任务回到就绪队列。

### 异常、系统调用与时钟

sscratch始终指向当前PCB。异常入口先交换tp，保存原t0，根据SPP区分U态和S态来源，选择用户任务对应的内核栈或当前S态栈；保存全部通用寄存器及sstatus/sepc/stval/scause。返回时恢复原tp、sp和其他现场，再执行sret。用户任务可以有与PCB无关的tp值，探针对此有检查。

系统调用号放a7，参数放a0—a4，结果放a0。只给ecall的sepc加4；中断不改变被中断PC。用户接口通过ecall进入内核，不直接调用内核地址。未知系统调用返回-38；字符串输出先验证指针及终止符在当前任务的映像槽或用户栈内，失败返回-14。本实验无页表隔离，完整内存保护仍需课程loadbootd/DASIC验证。

内核处理系统调用时不重新开启SIE；队列和锁操作也保存并关闭本地中断。该设计面向单核，未实现SMP。Task 4只启用STIE，每次时钟中断先重设下一次定时器，再刷新屏幕并调度。Task 3没有时钟中断，通过yield、阻塞后的调度以及pid0循环检查睡眠队列。Task 4的pid0通过WFI等待，避免用户任务全部睡眠后停滞。

### 互斥锁

相同key返回同一个槽位；不存在的key分配空闲槽。竞争失败时进程进入锁等待队列并调度，避免忙等。释放时优先把所有权交给FIFO等待者，锁保持占用状态，防止刚唤醒的任务被新到达者抢走。没有等待者才真正解锁。锁不支持递归获取；无效索引、重复获取或非持有者释放会触发内核断言。未实现任务退出时自动释放锁。

### 其他修改

修正屏幕换行/自动折行时的行边界和恢复光标的1基坐标；修正两个原有格式化库读取`%ld`参数时的signed long类型。链接器仍可能提示裸机ELF的RWX段，这是原链接脚本将代码和数据放在同一可加载段所致，不代表通过了课程内存保护验收。

## 已完成的验证与限制

详细结果见`docs/VALIDATION.md`。当前已完成原始课程地址布局的交叉编译，以及通用QEMU中的临时地址重定位运行验证。通用QEMU测试适配层在`test/host-qemu/`；它不属于内核启动流程，也不是课程U-Boot。

真实课程QEMU、课程U-Boot、loadbootd/DASIC和Pynq板端尚未验证。需在你现有lab运行以上命令，再按课程规定执行loadbootd及板端检查；本工程没有杜撰未知的loadbootd命令。不要把通用QEMU测试通过当作A-Core全部验收通过。
