#!/usr/bin/env python3
"""Host regression tests for the disk ABI and malformed/oversized ELF input."""
import argparse, struct, subprocess, tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('tool',type=Path);a=p.parse_args()
tool=a.tool.resolve();tests=0

def elf(path,base,segments,entry=None):
    ident=b'\x7fELF'+bytes([2,1,1])+bytes(9)
    hdr=struct.pack('<16sHHIQQQIHHHHHH',ident,2,243,1,base if entry is None else entry,64,0,0,64,56,len(segments),0,0,0)
    offset=64+56*len(segments);ph=[];data=b''
    for delta,blob,mem in segments:
        ph.append(struct.pack('<IIQQQQQQ',1,7,offset,base+delta,base+delta,len(blob),mem,1))
        data+=blob;offset+=len(blob)
    path.write_bytes(hdr+b''.join(ph)+data)

def case(root,name,modify=None,success=False):
    global tests
    work=root/name;work.mkdir()
    elf(work/'bootblock',0x50200000,[(0,b'B'*100,100)])
    elf(work/'main',0x50201000,[(0,b'K'*513,1024)])
    elf(work/'app',0x52000000,[(0,b'CODE',4),(256,b'DATA',16)])
    tasks=['app']
    if modify: modify(work,tasks)
    result=subprocess.run([str(tool),'bootblock','main',*tasks],cwd=work,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert (result.returncode==0)==success,(name,result.stdout,result.stderr)
    tests+=1
    return work

with tempfile.TemporaryDirectory() as t:
    root=Path(t)
    work=case(root,'layout',success=True)
    data=(work/'image').read_bytes()
    assert data[:100]==b'B'*100 and data[510:512]==b'\x55\xaa'
    assert struct.unpack_from('<H',data,0x1fc)[0]==513
    assert struct.unpack_from('<H',data,0x1f6)[0]==1
    offset=struct.unpack_from('<I',data,0x1f8)[0]
    name,start,size,entry=struct.unpack_from('<32sIIQ',data,offset)
    assert name.rstrip(b'\0')==b'app' and entry==0x52000000 and size==260
    assert start==512+513 and offset==start+260
    assert data[start:start+4]==b'CODE' and data[start+4:start+256]==bytes(252)
    assert data[start+256:start+260]==b'DATA' and len(data)%512==0
    case(root,'kernel-overflow',lambda w,ts:elf(w/'main',0x50201000,[(0,bytes(65536),65536)]))
    case(root,'boot-overlap',lambda w,ts:elf(w/'bootblock',0x50200000,[(0,bytes(503),503)]))
    case(root,'app-overflow',lambda w,ts:elf(w/'app',0x52000000,[(0,b'X',65537)]))
    case(root,'bad-entry',lambda w,ts:elf(w/'app',0x52000000,[(0,b'X',1)],0x52000004))
    case(root,'truncated',lambda w,ts:(w/'app').write_bytes(b'\x7fELF'))
    case(root,'no-tasks',lambda w,ts:ts.clear())
    case(root,'too-many-tasks',lambda w,ts:ts.extend(['app']*16))
    case(root,'duplicate-tasks',lambda w,ts:ts.append('app'))
    def bad_endian(w,ts):
        b=bytearray((w/'app').read_bytes());b[5]=2;(w/'app').write_bytes(b)
    case(root,'bad-endian',bad_endian)
print(f'PASS: {tests} image layout/error cases')
