#!/usr/bin/env python3
"""Run the real kernel in upstream QEMU using a test-only BIOS adapter.
This does not replace tests with the course QEMU, U-Boot, DASIC or board.
Only a temporary source copy is relocated; the original tree is unchanged.
"""
import argparse, os, re, shutil, subprocess, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--qemu', default='qemu-system-riscv64')
parser.add_argument('--cross-prefix', default='riscv64-linux-gnu-')
parser.add_argument('--stage', type=int, choices=[1,2,3,4], default=4)
parser.add_argument('--tasks', default=None)
parser.add_argument('--seconds', type=float, default=7)
parser.add_argument('--debug-log', type=Path)
parser.add_argument('--log', type=Path, default=Path('host-qemu.log'))
args = parser.parse_args()
def run(cmd, **kw):
    subprocess.run(cmd, check=True, **kw)
with tempfile.TemporaryDirectory(prefix='p2-smoke-') as tmp:
    tree = Path(tmp)/'Project2'
    shutil.copytree(ROOT, tree, ignore=shutil.ignore_patterns('build', '*.log', '__pycache__', '.git'))
    for p in tree.rglob('*'):
        if p.is_file() and (p.suffix in ('.c','.h','.S') or p.name=='Makefile'):
            # Match full address literals, never shorter constants or firmware.
            if 'host-qemu' in p.parts: continue
            s = p.read_text()
            def relocate(m):
                n = int(m[0],16)
                return hex(n+0x30000000) if 0x50000000 <= n < 0x53000000 else m[0]
            p.write_text(re.sub(r'0[xX][0-9a-fA-F]+',relocate,s))
    tasks = args.tasks or {1:'coop1 coop2', 2:'mutex1 mutex2', 3:'sleep coop_timer', 4:'probe1 probe2'}[args.stage]
    run(['make','image',f'CROSS_PREFIX={args.cross_prefix}',f'LAB_STAGE={args.stage}',f'TASKS={tasks}'],cwd=tree,stdout=subprocess.DEVNULL)
    fw = ROOT/'test/host-qemu'
    run([args.cross_prefix+'gcc','-nostdlib','-static','-fno-pie','-no-pie','-march=rv64imac_zicsr_zifencei','-mabi=lp64','-Wl,--build-id=none','-Wl,--no-relax','-T',str(fw/'firmware.lds'),str(fw/'firmware.S'),'-o',str(tree/'firmware.elf')])
    cmd=[args.qemu,'-machine','virt','-m','256M','-nographic','-monitor','none','-bios',str(tree/'firmware.elf'),'-device',f'loader,file={tree}/build/image,addr=0x84000000,force-raw=on']
    if args.debug_log: cmd += ['-d','in_asm,int','-D',str(args.debug_log.resolve())]
    try:
        result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=args.seconds)
        raw=result.stdout
        raise RuntimeError(f'QEMU exited unexpectedly: {result.returncode}\n{raw[-1000:]!r}')
    except subprocess.TimeoutExpired as e:
        raw=e.stdout or b''
    text=raw.decode(errors='replace')
    args.log.write_text(text)
    # VT100 replaces previously drawn characters. Reconstruct the screen
    # after each control sequence to observe actual output, not raw substrings.
    required={1:['[COOP 1] count=','[COOP 2] count='],2:['[MUTEX 1] acquired','[MUTEX 2] acquired','[MUTEX 1] release','[MUTEX 2] release'],3:['This task is to test sleep. (1)','[COOP TIMER] seconds=2'],4:['[PROBE 1] PASS','[PROBE 2] PASS']}[args.stage]
    if args.tasks:
        markers = {
            'print1':'This task is to test scheduler.',
            'print2':'This task is to test scheduler.',
            'lock1':'Has acquired lock and running.',
            'lock2':'Has acquired lock and running.',
            'sleep':'This task is to test sleep. (1)',
            'timer':'This is a thread to timing!', 'fly':'~~~~~',
            'probe1':'[PROBE 1] PASS', 'probe2':'[PROBE 2] PASS',
            'coop1':'[COOP 1] count=', 'coop2':'[COOP 2] count=',
            'mutex1':'[MUTEX 1] acquired', 'mutex2':'[MUTEX 2] acquired',
            'coop_timer':'[COOP TIMER] seconds=2'
        }
        required=[markers[task] for task in args.tasks.split()]
    row_requirements={}
    if args.tasks:
        for task,row_number in [('print1',0),('print2',1),('lock1',2),('lock2',3)]:
            if task in args.tasks.split():
                row_requirements[row_number]=markers[task]
    seen_rows=set()
    found=set(); fault=False; events=[]
    lines=[[' ']*160 for _ in range(80)]
    row=col=0
    def observe(r):
        global fault
        line=''.join(lines[r])
        if r in row_requirements and row_requirements[r] in line: seen_rows.add(r)
        for marker in required:
            if marker in line: found.add(marker)
        for probe in (1,2):
            for event in ('start','cpu-loop-ok','lock-held','lock-release','PASS'):
                marker=f'[PROBE {probe}] {event}'
                if marker in line and marker not in events: events.append(marker)
        if 'Assertion failed' in line or 'scause:' in line: fault=True
    for token in re.split(r'(\x1b\[[0-9;?]*[A-Za-z])',text):
        if token.startswith('\x1b['):
            observe(row)
            if token.endswith('H'):
                vals=token[2:-1].split(';')
                row=max(0,min(79,int(vals[0] or 1)-1))
                col=max(0,min(159,int(vals[1] or 1)-1)) if len(vals)>1 else 0
            elif token=='\x1b[2J': lines=[[' ']*160 for _ in range(80)]
        else:
            for ch in token:
                if ch=='\n': observe(row); row=min(79,row+1)
                elif ch=='\r': observe(row); col=0
                elif ch.isprintable():
                    lines[row][col]=ch;col=min(159,col+1)
            observe(row)
    if fault: raise RuntimeError('guest exception/assertion; inspect log')
    missing=[s for s in required if s not in found]
    if set(row_requirements) != seen_rows: raise RuntimeError('missing per-task row evidence')
    if missing: raise RuntimeError('missing guest evidence: '+repr(missing))
    if args.stage == 4 and not args.tasks:
        first_done=min(events.index(f'[PROBE {i}] cpu-loop-ok') for i in (1,2))
        assert all(events.index(f'[PROBE {i}] start') < first_done for i in (1,2)), 'no evidence of asynchronous preemption'
        print('guest events:', ', '.join(events))
    print(f'PASS: relocated upstream-QEMU smoke stage {args.stage}; log={args.log}')
